# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

NOFX is a Universal AI Trading Operating System - an agentic trading platform that enables AI models (DeepSeek, Qwen, custom OpenAI-compatible) to make autonomous trading decisions across multiple cryptocurrency exchanges (Binance, Hyperliquid, Aster DEX). The system features multi-agent competition, self-learning through historical feedback, and comprehensive risk management.

**Tech Stack:**
- Backend: Go 1.21+ with Gin framework, SQLite database
- Frontend: React 18 + TypeScript + Vite + TailwindCSS + Zustand (state) + SWR (data fetching)
- Dependencies: TA-Lib (technical indicators), go-binance (exchange API), go-hyperliquid, go-ethereum

## Build and Test Commands

### Quick Development with Makefile

```bash
# Run all tests (backend + frontend)
make test

# Backend development
make test-backend          # Run backend tests only
make build                 # Build backend binary
make run                   # Run backend in development mode
make fmt                   # Format Go code

# Frontend development
make test-frontend         # Run frontend tests only
make build-frontend        # Build frontend
make run-frontend          # Start frontend dev server

# Docker operations
make docker-build          # Build Docker images
make docker-up             # Start Docker containers
make docker-down           # Stop Docker containers

# Dependencies
make deps                  # Download Go dependencies
make deps-frontend         # Install frontend dependencies
```

### Backend Development (Manual)

```bash
# Install dependencies
go mod download

# Build the backend
go build -o nofx

# Run the backend (starts on port 8080 by default)
./nofx

# Run tests
go test ./...

# Run tests with coverage
go test -cover ./...

# Run specific package tests
go test ./trader/
go test ./decision/

# Run a single test by name
go test ./trader/ -run TestSpecificFunction -v

# Format code
go fmt ./...

# Vet code
go vet ./...
```

### Frontend Development

```bash
cd web

# Install dependencies
npm install

# Run development server (http://localhost:3000)
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Lint and format
npm run lint
npm run lint:fix
npm run format
npm run format:check

# Run a single test file
npm test -- src/components/MyComponent.test.tsx

# Run tests matching a pattern
npm test -- --testNamePattern="should render"
```

### Docker Deployment

```bash
# Start all services (recommended for testing)
./start.sh start --build

# Or use docker compose directly
docker compose up -d --build

# View logs
./start.sh logs

# Stop services
./start.sh stop

# Other useful commands
./start.sh status              # Check service status
./start.sh restart             # Restart services
./start.sh setup-encryption    # Manual encryption setup
```

### Database Management

```bash
# Default database location: config.db
# View database schema:
sqlite3 config.db ".schema"

# Backup database:
cp config.db config.db.backup
```

## High-Level Architecture

NOFX follows a modular architecture with clear separation of concerns:

### Core Trading Loop (trader/auto_trader.go)
Each trader runs an independent goroutine executing this cycle every 3-5 minutes:
1. Fetch account status and open positions
2. Analyze historical performance (last 20 trades)
3. Fetch candidate coins from pool (AI500 + OI Top or default list)
4. Collect market data and calculate technical indicators
5. Generate AI prompt with full context
6. Call AI API for decision (DeepSeek/Qwen/Custom)
7. Parse and validate decision against risk constraints
8. Execute trades via exchange API
9. Log decision and update performance metrics

### Multi-Exchange Abstraction (trader/interface.go)
The `Trader` interface provides unified abstraction across exchanges:
- `binance_futures.go`: Binance Futures API wrapper
- `hyperliquid_trader.go`: Hyperliquid DEX wrapper (Ethereum-based)
- `aster_trader.go`: Aster DEX wrapper (Binance-compatible API)

All exchange implementations handle:
- Account info retrieval
- Position management
- Order placement with automatic precision handling
- Balance and PnL tracking

### Decision Engine (decision/engine.go)
Handles AI decision-making workflow:
- **Historical Feedback System**: Analyzes last 20 trading cycles, calculates win rate, P/L ratio, identifies best/worst performing assets
- **Prompt Generation**: Constructs comprehensive prompts with account status, positions, market data, technical indicators, and historical performance
- **Decision Parsing**: Extracts structured decisions from AI responses (supports JSON and XML formats)
- **Risk Validation**: Enforces position limits, margin constraints, leverage caps, anti-stacking protection

### Market Data System (market/)
- `data.go`: Fetches K-line data and calculates technical indicators using TA-Lib (EMA, MACD, RSI, ATR)
- `api_client.go`: REST API client for market data
- `websocket_client.go`: WebSocket streams for real-time data
- `combined_streams.go`: Multi-symbol subscription manager
- `monitor.go`: Market data cache with 150-second retention

### Database Layer (config/database.go)
SQLite-based persistence with tables:
- `users`: User accounts with 2FA support
- `ai_models`: AI model configurations (API keys, endpoints)
- `exchanges`: Exchange credentials (encrypted)
- `traders`: Trader instances with status tracking
- `equity_history`: Performance time-series data
- `system_config`: Key-value configuration store
- `performance`: Trade history and analytics

### Authentication (auth/auth.go)
- JWT token-based authentication
- TOTP 2FA support (Google Authenticator compatible)
- Bcrypt password hashing
- Admin mode and multi-user support

### API Server (api/server.go)
RESTful API with endpoints for:
- Trader management (create, start, stop, delete)
- Model/exchange configuration
- Real-time status monitoring
- Position and account queries
- Decision log retrieval
- Performance analytics

## Key Design Patterns

### Strategy Pattern for Exchanges
The `Trader` interface allows pluggable exchange implementations. Adding a new exchange requires:
1. Implement the `Trader` interface in `trader/`
2. Handle exchange-specific precision rules
3. Add configuration fields to `config.Database`
4. Update API server to support new exchange type

### Prompt Template System
Custom trading strategies are implemented via prompts in `prompts/` directory:
- `default.txt`: Default balanced strategy
- `supertrend_frvp.txt`: SuperTrend + FRVP technical analysis strategy
- `Hansen.txt`, `nof1.txt`, `taro_long_prompts.txt`: Community strategies
- Traders reference templates via `system_prompt_template` field
- Templates can be reloaded without restart

### Self-Learning Feedback Loop
The system maintains a performance database tracking:
- Entry/exit prices and timestamps
- Leverage and position size
- Actual PnL in USDT (quantity × price_delta × leverage)
- Win rate, profit factor, Sharpe ratio per trader

This data is fed back into the next decision cycle, enabling AI to learn from mistakes and reinforce successful patterns.

### Concurrent Multi-Trader Management (manager/trader_manager.go)
- Each trader runs in isolated goroutine
- Thread-safe operations with mutex protection
- Graceful shutdown handling
- Database persistence of trader state

## Configuration Architecture

### Legacy config.json (being phased out)
Still required for some settings but traders are now managed via web interface:
- System settings (ports, coin pools, risk limits)
- Leverage configuration
- Default coin lists

### Database-Driven Configuration (primary method)
All trader configuration stored in SQLite:
- AI models with API keys
- Exchange credentials (encrypted with RSA)
- Trader instances with runtime state
- System configuration key-value store

Configuration priority: Environment Variables > Database > config.json > Defaults

### Environment Variables
- `JWT_SECRET`: JWT signing key
- `NOFX_BACKEND_PORT`: API server port (default 8080)
- `DATABASE_PATH`: SQLite database path (default config.db)
- `DATA_ENCRYPTION_KEY`: Database encryption key for sensitive data
- `AI_MAX_TOKENS`: AI response token limit (default 2000)

### AI Model Client Provider (mcp/)
Abstraction layer for multiple AI providers:
- `deepseek_client.go`: DeepSeek API integration
- `qwen_client.go`: Qwen API integration
- `client.go`: Custom OpenAI-compatible API client
- Request builder with context injection and response parsing

## Important Development Notes

### Adding Technical Indicators
Technical indicators are calculated in `market/data.go` using TA-Lib:
```go
import "github.com/markcheno/go-talib"

// Example: Add Bollinger Bands
upper, middle, lower := talib.BBands(closePrices, 20, 2, 2, 0)
```

Indicators must be added to:
1. `market.Data` struct
2. Calculation function in `market/data.go`
3. Prompt template to expose to AI

### Adding New Decision Actions
Decision actions are defined in `decision/engine.go`:
- Current: `open_long`, `open_short`, `close_long`, `close_short`, `hold`, `wait`, `partial_close`, `update_stop_loss`, `update_take_profit`
- To add new action: Update `Decision` struct and handle in `trader/auto_trader.go` execution logic

### Position Tracking
Positions are tracked with `symbol_side` key (e.g., "BTCUSDT_long") to support simultaneous long/short positions in same symbol. Duration tracking is maintained via `OpenTime` field.

### Risk Control Philosophy
The system has multi-layer risk control:
1. **AI Decision Layer**: AI considers risk-reward ratios, account balance, volatility
2. **Validation Layer**: Hard limits on position size, margin usage, leverage
3. **Emergency Stop**: Max daily loss and drawdown triggers (configurable)
4. **Exchange Layer**: Native exchange liquidation protection

Developers should prefer soft constraints (AI guidance) over hard blocks to preserve AI autonomy.

### Logging and Debugging
- Decision logs: `decision_logs/{trader_id}/{timestamp}.json` (includes full CoT reasoning)
- Application logs: Stdout with structured logging
- Database logs: SQLite query logging available via environment variable

### Testing Approach
Current testing is manual + testnet. When adding tests:
- Mock exchange APIs in `trader/*_test.go`
- Use testnet credentials for integration tests
- Frontend tests use Vitest + React Testing Library

## Common Tasks

### Adding a New Exchange
1. Create `trader/newexchange_trader.go` implementing `Trader` interface
2. Add exchange config fields to `config/database.go` schema
3. Update `api/server.go` to handle new exchange type in trader creation
4. Add precision handling for order sizes/prices
5. Test with testnet/sandbox credentials

### Creating a New Trading Strategy
1. Create new prompt file in `prompts/strategy_name.txt`
2. Use existing prompts as templates (include historical feedback section)
3. Set `system_prompt_template` field in trader config via API
4. Strategy can access: account status, positions, market data, technical indicators, historical performance

### Modifying Risk Constraints
Risk parameters in `trader/auto_trader.go`:
- Position size limits: Altcoins ≤1.5x equity, BTC/ETH ≤10x equity
- Margin usage cap: ≤90%
- Leverage limits: Configurable per trader (default 5x)
- Risk-reward ratio: Enforced ≥1:2 stop-loss to take-profit

### Adding Custom Indicators
1. Add calculation to `market/data.go` using TA-Lib
2. Update `market.Data` struct with new fields
3. Include in prompt generation in `decision/engine.go`
4. Document in prompt template for AI understanding

## Security Considerations

- API keys are encrypted at rest using RSA-2048 (crypto/encryption.go)
- JWT tokens should use strong secrets (256-bit minimum)
- 2FA enforcement available for production deployments
- Database should be backed up regularly (contains sensitive credentials)
- Never commit `config.json`, `config.db`, or `secrets/` directory
- Use environment variables for sensitive configuration in production

## Troubleshooting

**Build fails with TA-Lib error:**
```bash
# macOS: brew install ta-lib
# Ubuntu: sudo apt-get install libta-lib0-dev
```

**Port 8080 already in use:**
Set `NOFX_BACKEND_PORT` environment variable or update config.json `api_server_port`

**AI API timeout errors:**
Check network connectivity, API key validity, and API balance. Timeout is 120 seconds.

**Precision errors from exchange:**
System auto-fetches LOT_SIZE from exchange. If errors persist, check exchange symbol status.

**Frontend can't connect to backend:**
Ensure backend is running on correct port. Check CORS settings in `api/server.go`.

## Architecture Evolution

The project is transitioning from JSON config files to database-driven configuration. When working on new features:
- Store configuration in database, not config.json
- Provide API endpoints for configuration management
- Update web interface for user-friendly configuration

Future architectural improvements planned:
- Microservices split for scaling (decision engine, market data, execution)
- PostgreSQL migration for production (>100 traders)
- WebSocket for real-time updates (currently polling-based)
- Event-driven architecture with message queues

## Code Review Guidelines

Use the `/20-code-review` slash command for comprehensive code reviews. Key review dimensions:

### Business Logic Review (BLOCKING)
- Verify requirements source (not reverse-engineered from code)
- Validate 100% requirement coverage
- Check state transitions, data flow, conditional logic
- Evaluate edge case handling

### Contract & Connectivity Checks (BLOCKING)
- Endpoint consistency (frontend ↔ backend paths, HTTP methods)
- Authentication/CORS alignment
- Request/Response schema matching (field names, types, required/optional)
- Error handling and status codes

### Web3 AI Trading Security (CRITICAL)
- **Key Management**: No private keys in logs/errors/frontend/Git; encrypted storage required
- **Transaction Safety**: Signature verification, nonce/replay protection, amount limits, slippage protection
- **AI Decision Safety**: Input sanitization (prevent prompt injection), decision audit logging, large trade confirmation
- **Smart Contract**: No unlimited approvals, contract address whitelisting, call failure handling
- **Fund Protection**: Per-trade and cumulative limits, emergency kill switch, balance monitoring

### E2E User Flow Verification (MANDATORY)
- Trace complete click paths: user click → function call → navigation → display
- Verify URL routing and parameter handling
- Validate state consistency after interactions

## SuperTrend + FRVP Strategy Framework

Reference implementation for system-driven trading with AI assistance. See `SuperTrend + FRVP 交易系统执行框架20251203.md` for full specification.

### Core Signal Logic
```
Long: 4H price > 4H ST + 15M price > 15M ST + 15M price > VAH + MACD golden cross → SL = 15M ST
Short: 4H price < 4H ST + 15M price < 15M ST + 15M price < VAL + MACD death cross → SL = 15M ST
```

### Risk Controls
- Position limit: Max 3 positions, max 8 new opens per day
- Daily loss circuit breaker: Base capital loss ≥6% OR anti-martingale loss ≥30%
- Sector diversification: L1 ≤2, Meme ≤1, DeFi ≤1

### Execution Architecture
```
Layer 1: System pre-calculation (indicators, signals, filters) → candidate list
Layer 2: Risk checks (hard limits, non-negotiable)
Layer 3: AI decision (selection only, no parameter calculation)
Layer 4: Forced execution (system-calculated SL/position/leverage, AI params ignored)
```

### Anti-Martingale Position Management
- Daily reset at UTC 00:00
- Anti-martingale pool = yesterday's pool + 0.9×profit - losses (capped at 50% of total)
- Base capital = total - anti-martingale pool (protected)

## Resources

- Main README: `README.md` (comprehensive user guide)
- Architecture docs: `docs/architecture/README.md`
- Contributing guide: `CONTRIBUTING.md`
- Changelog: `CHANGELOG.md`
- API reference: See `api/server.go` for endpoint definitions
- Code review command: `.claude/commands/20-code-review.md`
- Strategy framework: `SuperTrend + FRVP 交易系统执行框架20251203.md`
# 🤖 NOFX - Agentic Trading OS

[![Go Version](https://img.shields.io/badge/Go-1.21+-00ADD8?style=flat&logo=go)](https://golang.org/)
[![React](https://img.shields.io/badge/React-18+-61DAFB?style=flat&logo=react)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0+-3178C6?style=flat&logo=typescript)](https://www.typescriptlang.org/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Backed by Amber.ac](https://img.shields.io/badge/Backed%20by-Amber.ac-orange.svg)](https://amber.ac)

**言語:** [English](README.md) | [中文](README.zh-CN.md) | [Українська](README.uk.md) | [Русский](README.ru.md) | [日本語](README.ja.md)

**公式Twitter:** [@nofx_official](https://x.com/nofx_official)

---

## 🚀 ユニバーサルAIトレーディングOS

**NOFX**は、統合アーキテクチャに基づいて構築された**ユニバーサルAgenticトレーディングOS**です。暗号通貨市場において **「マルチエージェント判断 → 統一リスク管理 → 低レイテンシ実行 → ライブ/ペーパーアカウントバックテスト」** のループを成功裏に完成させ、現在この技術スタックを **株式、先物、オプション、外国為替、およびすべての金融市場** に拡大しています。

### 🎯 コア機能

- **ユニバーサルデータ＆バックテストレイヤー**: クロスマーケット、クロスタイムフレーム、クロス取引所の統一表現とファクターライブラリにより、転移可能な「戦略メモリ」を蓄積
- **マルチエージェント自己対戦＆自己進化**: 戦略が自動的に競争し、最適なものを選択、アカウントレベルのPnLとリスク制約に基づいて継続的に反復
- **統合実行＆リスク管理**: 低レイテンシルーティング、スリッページ/リスク管理サンドボックス、アカウントレベルの制限、ワンクリック市場切り替え

### 🏢 [Amber.ac](https://amber.ac)の支援

### 👥 コアチーム

- **Tinkle** - [@Web3Tinkle](https://x.com/Web3Tinkle)
- **Zack** - [@0x_ZackH](https://x.com/0x_ZackH)

### 💼 シードラウンド募集中

現在、**シードラウンド**の資金調達を行っています。

**投資に関するお問い合わせ**は、TwitterでTinkleまたはZackにDMをお送りください。

**パートナーシップおよび協業**については、公式Twitter [@nofx_official](https://x.com/nofx_official)にDMをお送りください。

---

> ⚠️ **リスク警告**: このシステムは実験的なものです。AI自動取引には大きなリスクが伴います。学習/研究目的、または少額でのテストのみを強く推奨します！

## 👥 開発者コミュニティ

Telegram開発者コミュニティに参加して、議論、アイデアの共有、サポートを受けましょう：

**💬 [NOFX開発者コミュニティ](https://t.me/nofx_dev_community)**

---

## 🆕 最新情報（最新アップデート）

### 🚀 マルチ取引所対応！

NOFXは現在、**3つの主要取引所**をサポートしています：Binance、Hyperliquid、Aster DEX！

#### **Hyperliquid取引所**

高性能な分散型無期限先物取引所！

**主な機能:**
- ✅ フル取引サポート（ロング/ショート、レバレッジ、ストップロス/テイクプロフィット）
- ✅ 自動精度処理（注文サイズ＆価格）
- ✅ 統一トレーダーインターフェース（シームレスな取引所切り替え）
- ✅ メインネットとテストネットの両方をサポート
- ✅ APIキー不要 - Ethereum秘密鍵のみ

**なぜHyperliquid？**
- 🔥 中央集権型取引所より低い手数料
- 🔒 非カストディアル - 資金を自分で管理
- ⚡ オンチェーン決済による高速実行
- 🌍 KYC不要

**クイックスタート:**
1. MetaMaskの秘密鍵を取得（`0x`プレフィックスを削除）
2. config.jsonで`"exchange": "hyperliquid"`を設定
3. `"hyperliquid_private_key": "your_key"`を追加
4. 取引開始！

詳細は[設定ガイド](#-代替hyperliquid取引所の使用)をご覧ください。

#### **Aster DEX取引所**（NEW! v2.0.2）

Binance互換の分散型無期限先物取引所！

**主な機能:**
- ✅ BinanceスタイルAPI（Binanceからの移行が簡単）
- ✅ Web3ウォレット認証（安全で分散型）
- ✅ 自動精度処理によるフル取引サポート
- ✅ CEXより低い取引手数料
- ✅ EVM互換（Ethereum、BSC、Polygonなど）

**なぜAster？**
- 🎯 **Binance互換API** - 最小限のコード変更で済む
- 🔐 **APIウォレットシステム** - セキュリティのための独立した取引ウォレット
- 💰 **競争力のある手数料** - ほとんどの中央集権型取引所より低い
- 🌐 **マルチチェーンサポート** - お好みのEVMチェーンで取引

**クイックスタート:**
1. [Aster APIウォレット](https://www.asterdex.com/en/api-wallet)にアクセス
2. メインウォレットを接続してAPIウォレットを作成
3. API Signerアドレスと秘密鍵をコピー
4. config.jsonで`"exchange": "aster"`を設定
5. `"aster_user"`、`"aster_signer"`、`"aster_private_key"`を追加

---

## 📸 スクリーンショット

### 🏆 競争モード - リアルタイムAIバトル
![競争ページ](screenshots/competition-page.png)
*QwenとDeepSeekのライブトレーディングバトルを示すリアルタイムパフォーマンス比較チャート付きマルチAIリーダーボード*

### 📊 トレーダー詳細 - 完全なトレーディングダッシュボード
![詳細ページ](screenshots/details-page.png)
*エクイティカーブ、ライブポジション、展開可能な入力プロンプトと思考連鎖推論を持つAI判断ログを備えたプロフェッショナルな取引インターフェース*

---

## ✨ 現在の実装 - 暗号通貨市場

NOFXは現在、以下の実証済み機能で**暗号通貨市場において完全に稼働**しています：

### 🏆 マルチエージェント競争フレームワーク
- **ライブエージェントバトル**: QwenとDeepSeekモデルがリアルタイム取引で競争
- **独立したアカウント管理**: 各エージェントは独自の判断ログとパフォーマンスメトリクスを維持
- **リアルタイムパフォーマンス比較**: ライブROI追跡、勝率統計、一対一分析
- **自己進化ループ**: エージェントは過去のパフォーマンスから学習し、継続的に改善

### 🧠 AI自己学習＆最適化
- **過去フィードバックシステム**: 各判断前に過去20取引サイクルを分析
- **スマートパフォーマンス分析**:
  - 最高/最悪パフォーマンス資産の特定
  - 実際のUSDT建てで勝率、損益比、平均利益を計算
  - 繰り返しミスを回避（連続損失パターン）
  - 成功戦略を強化（高勝率パターン）
- **動的戦略調整**: AIはバックテスト結果に基づいて取引スタイルを自律的に適応

### 📊 ユニバーサルマーケットデータレイヤー（暗号実装）
- **マルチタイムフレーム分析**: 3分リアルタイム + 4時間トレンドデータ
- **テクニカル指標**: EMA20/50、MACD、RSI(7/14)、ATR
- **建玉追跡**: マーケットセンチメント、資金フロー分析
- **流動性フィルタリング**: 低流動性資産（<1500万USD）の自動フィルタリング
- **クロス取引所サポート**: 統一データインターフェースでBinance、Hyperliquid、Aster DEX

### 🎯 統一リスク管理システム
- **ポジション制限**: 資産ごとの制限（アルトコイン≤1.5x エクイティ、BTC/ETH≤10x エクイティ）
- **設定可能なレバレッジ**: 資産クラスとアカウントタイプに基づいて1xから50xまでの動的レバレッジ
- **証拠金管理**: 総使用量≤90%、AI制御配分
- **リスクリワード強制**: 必須≥1:2 ストップロス対テイクプロフィット比率
- **重複防止**: 同じ資産/方向での重複ポジションを防止

### ⚡ 低レイテンシ実行エンジン
- **マルチ取引所API統合**: Binance Futures、Hyperliquid DEX、Aster DEX
- **自動精度処理**: 取引所ごとのスマートな注文サイズと価格フォーマット
- **優先実行**: 既存ポジションを先にクローズし、その後新規を開く
- **スリッページ管理**: 実行前検証、リアルタイム精度チェック

### 🎨 プロフェッショナルモニタリングインターフェース
- **Binanceスタイルダッシュボード**: リアルタイム更新付きプロフェッショナルダークテーマ
- **エクイティカーブ**: 過去のアカウント価値追跡（USD/パーセンテージ切り替え）
- **パフォーマンスチャート**: ライブ更新付きマルチエージェントROI比較
- **完全な判断ログ**: すべての取引の完全な思考連鎖（CoT）推論
- **5秒データ更新**: リアルタイムアカウント、ポジション、損益更新

---

## 🔮 ロードマップ - ユニバーサルマーケット拡大

実証済みの暗号インフラストラクチャを以下に拡張中：

- **📈 株式市場**: 米国株式、A株、香港株
- **📊 先物市場**: 商品先物、指数先物
- **🎯 オプション取引**: 株式オプション、暗号オプション
- **💱 外国為替市場**: 主要通貨ペア、クロスレート

**同じアーキテクチャ。同じエージェントフレームワーク。すべての市場。**

---

## 🏗️ 技術アーキテクチャ

```
nofx/
├── main.go                          # プログラムエントリ（マルチトレーダーマネージャー）
├── config.json                      # 設定ファイル（APIキー、マルチトレーダー設定）
│
├── api/                            # HTTP APIサービス
│   └── server.go                   # Ginフレームワーク、RESTful API
│
├── trader/                         # トレーディングコア
│   ├── auto_trader.go              # 自動取引メインコントローラー（単一トレーダー）
│   └── binance_futures.go          # Binance先物APIラッパー
│
├── manager/                        # マルチトレーダー管理
│   └── trader_manager.go           # 複数のトレーダーインスタンスを管理
│
├── mcp/                            # Model Context Protocol - AI通信
│   └── client.go                   # AIクライアント（DeepSeek/Qwen統合）
│
├── decision/                       # AI判断エンジン
│   └── engine.go                   # 過去フィードバック付き判断ロジック
│
├── market/                         # マーケットデータ取得
│   └── data.go                     # マーケットデータ＆テクニカル指標（K線、RSI、MACD）
│
├── pool/                           # コインプール管理
│   └── coin_pool.go                # AI500 + OI Topマージプール
│
├── logger/                         # ロギングシステム
│   └── decision_logger.go          # 判断記録 + パフォーマンス分析
│
├── decision_logs/                  # 判断ログストレージ
│   ├── qwen_trader/                # Qwenトレーダーログ
│   └── deepseek_trader/            # DeepSeekトレーダーログ
│
└── web/                            # Reactフロントエンド
    ├── src/
    │   ├── components/             # Reactコンポーネント
    │   │   ├── EquityChart.tsx     # エクイティカーブチャート
    │   │   ├── ComparisonChart.tsx # マルチAI比較チャート
    │   │   └── CompetitionPage.tsx # 競争リーダーボード
    │   ├── lib/api.ts              # API呼び出しラッパー
    │   ├── types/index.ts          # TypeScript型
    │   ├── index.css               # BinanceスタイルCSS
    │   └── App.tsx                 # メインアプリ
    └── package.json
```

### コア依存関係

**バックエンド（Go）**
- `github.com/adshao/go-binance/v2` - Binance APIクライアント
- `github.com/markcheno/go-talib` - テクニカル指標計算（TA-Lib）
- `github.com/gin-gonic/gin` - HTTP APIフレームワーク

**フロントエンド（React + TypeScript）**
- `react` + `react-dom` - UIフレームワーク
- `recharts` - チャートライブラリ（エクイティカーブ、比較チャート）
- `swr` - データフェッチングとキャッシング
- `tailwindcss` - CSSフレームワーク

---

## 💰 Binanceアカウント登録（手数料節約！）

このシステムを使用する前に、Binance先物アカウントが必要です。**紹介リンクを使用して取引手数料を節約しましょう：**

**🎁 [Binance登録 - 手数料割引を取得](https://www.binance.com/join?ref=TINKLEVIP)**

### 登録手順：

1. **上記のリンクをクリック**してBinance登録ページにアクセス
2. メール/電話番号で**登録を完了**
3. **KYC認証を完了**（先物取引に必要）
4. **先物アカウントを有効化**：
   - Binanceホームページ → デリバティブ → USDT無期限先物
   - 「今すぐ開設」をクリックして先物取引を有効化
5. **APIキーを作成**：
   - アカウント → API管理
   - 新しいAPIキーを作成、**「先物」権限を有効化**
   - APIキーとシークレットキーを保存（config.jsonに必要）
   - **重要**: セキュリティのためIPアドレスをホワイトリストに追加

### 手数料割引の利点：

- ✅ **現物取引**: 最大30%の手数料割引
- ✅ **先物取引**: 最大30%の手数料割引
- ✅ **生涯有効**: すべての取引で永久割引

---

## 🚀 クイックスタート

### 🐳 オプションA：Dockerワンクリックデプロイ（最も簡単 - 初心者推奨！）

**⚡ Dockerで3つの簡単なステップで取引開始 - インストール不要！**

Dockerはすべての依存関係（Go、Node.js、TA-Lib）と環境設定を自動的に処理します。初心者に最適！

#### ステップ1：設定を準備

```bash
# 設定テンプレートをコピー
cp config.json.example config.json

# 編集してAPIキーを入力
nano config.json  # または任意のエディタを使用
```

#### ステップ2：ワンクリック起動

```bash
# オプション1：便利スクリプトを使用（推奨）
chmod +x scripts/start.sh
./scripts/start.sh start --build

> #### Docker Composeバージョンに関する注意
>
> **このプロジェクトはDocker Compose V2構文（スペース付き）を使用**
>
> 古いスタンドアロン`docker-compose`がインストールされている場合は、Docker DesktopまたはDocker 20.10+にアップグレードしてください

# オプション2：docker composeを直接使用
docker compose up -d --build
```

#### ステップ3：ダッシュボードにアクセス

ブラウザを開いて次にアクセス：**http://localhost:3000**

**これで完了！🎉** AIトレーディングシステムが稼働中です！

#### システム管理

```bash
./scripts/start.sh logs      # ログを表示
./scripts/start.sh status    # ステータスを確認
./scripts/start.sh stop      # サービスを停止
./scripts/start.sh restart   # サービスを再起動
```

**📖 詳細なDockerデプロイガイド、トラブルシューティング、高度な設定について：**
- **English**: See [DOCKER_DEPLOY.en.md](DOCKER_DEPLOY.en.md)
- **中文**: 查看 [DOCKER_DEPLOY.md](DOCKER_DEPLOY.md)
- **日本語**: [DOCKER_DEPLOY.ja.md](DOCKER_DEPLOY.ja.md)を参照

---

### 📦 オプションB：手動インストール（開発者向け）

**注意**: 上記のDockerデプロイを使用した場合は、このセクションをスキップしてください。手動インストールは、コードを変更したい場合、またはDockerなしで実行したい場合にのみ必要です。

### 1. 環境要件

- **Go 1.21+**
- **Node.js 18+**
- **TA-Lib**ライブラリ（テクニカル指標計算）

#### TA-Libのインストール

**macOS:**
```bash
brew install ta-lib
```

**Ubuntu/Debian:**
```bash
sudo apt-get install libta-lib0-dev
```

**その他のシステム**: [TA-Lib公式ドキュメント](https://github.com/markcheno/go-talib)を参照

### 2. プロジェクトをクローン

```bash
git clone https://github.com/tinkle-community/nofx.git
cd nofx
```

### 3. 依存関係をインストール

**バックエンド:**
```bash
go mod download
```

**フロントエンド:**
```bash
cd web
npm install
cd ..
```

### 4. AI APIキーを取得

システムを設定する前に、AI APIキーを取得する必要があります。以下のAIプロバイダーのいずれかを選択してください：

#### オプション1：DeepSeek（初心者推奨）

**なぜDeepSeek？**
- 💰 GPT-4より安価（約1/10のコスト）
- 🚀 高速レスポンス時間
- 🎯 優れた取引判断品質
- 🌍 VPNなしで世界中で動作

**DeepSeek APIキーの取得方法：**

1. **アクセス**: [https://platform.deepseek.com](https://platform.deepseek.com)
2. **登録**: メール/電話番号でサインアップ
3. **認証**: メール/電話認証を完了
4. **チャージ**: アカウントにクレジットを追加
   - 最低: 約$5 USD
   - 推奨: テスト用に$20-50 USD
5. **APIキーを作成**：
   - APIキーセクションに移動
   - 「新しいキーを作成」をクリック
   - キーをコピーして保存（`sk-`で始まる）
   - ⚠️ **重要**: すぐに保存してください - 再度見ることはできません！

**価格**: 約100万トークンあたり$0.14（非常に安い！）

#### オプション2：Qwen（Alibaba Cloud）

**Qwen APIキーの取得方法：**

1. **アクセス**: [https://dashscope.aliyuncs.com](https://dashscope.aliyuncs.com)
2. **登録**: Alibaba Cloudアカウントでサインアップ
3. **サービスを有効化**: DashScopeサービスを有効化
4. **APIキーを作成**：
   - APIキー管理に移動
   - 新しいキーを作成
   - コピーして保存（`sk-`で始まる）

**注意**: 登録には中国の電話番号が必要な場合があります

---

### 5. システム設定

**2つの設定モードが利用可能：**
- **🌟 初心者モード**: シングルトレーダー + デフォルトコイン（推奨！）
- **⚔️ エキスパートモード**: 複数トレーダー競争

#### 🌟 初心者モード設定（推奨）

**ステップ1**: 設定例ファイルをコピーしてリネーム

```bash
cp config.json.example config.json
```

**ステップ2**: APIキーで`config.json`を編集

```json
{
  "traders": [
    {
      "id": "my_trader",
      "name": "My AI Trader",
      "ai_model": "deepseek",
      "binance_api_key": "YOUR_BINANCE_API_KEY",
      "binance_secret_key": "YOUR_BINANCE_SECRET_KEY",
      "use_qwen": false,
      "deepseek_key": "sk-xxxxxxxxxxxxx",
      "qwen_key": "",
      "initial_balance": 1000.0,
      "scan_interval_minutes": 3
    }
  ],
  "leverage": {
    "btc_eth_leverage": 5,
    "altcoin_leverage": 5
  },
  "use_default_coins": true,
  "coin_pool_api_url": "",
  "oi_top_api_url": "",
  "api_server_port": 8080
}
```

**ステップ3**: プレースホルダーを実際のキーに置き換え

| プレースホルダー | 置き換え先 | 取得場所 |
|------------|--------------|--------------|
| `YOUR_BINANCE_API_KEY` | BinanceのAPIキー | Binance → アカウント → API管理 |
| `YOUR_BINANCE_SECRET_KEY` | Binanceのシークレットキー | 上記と同じ |
| `sk-xxxxxxxxxxxxx` | DeepSeek APIキー | [platform.deepseek.com](https://platform.deepseek.com) |

**ステップ4**: 初期残高を調整（オプション）

- `initial_balance`: 実際のBinance先物アカウント残高に設定
- 損益パーセンテージの計算に使用
- 例：500 USDTがある場合、`"initial_balance": 500.0`に設定

**✅ 設定チェックリスト：**

- [ ] Binance APIキーを入力（引用符の問題なし）
- [ ] Binanceシークレットキーを入力（引用符の問題なし）
- [ ] DeepSeek APIキーを入力（`sk-`で始まる）
- [ ] `use_default_coins`を`true`に設定（初心者向け）
- [ ] `initial_balance`をアカウント残高と一致させる
- [ ] ファイルを`config.json`として保存（`.example`ではない）

---

#### 🔷 代替：Hyperliquid取引所の使用

**NOFXはHyperliquidもサポート** - 分散型無期限先物取引所。Binanceの代わりにHyperliquidを使用するには：

**ステップ1**: Ethereum秘密鍵を取得（Hyperliquid認証用）

1. **MetaMask**（または任意のEthereumウォレット）を開く
2. 秘密鍵をエクスポート
3. キーから**`0x`プレフィックスを削除**
4. [Hyperliquid](https://hyperliquid.xyz)でウォレットに資金を入金

**ステップ2**: Hyperliquid用に`config.json`を設定

```json
{
  "traders": [
    {
      "id": "hyperliquid_trader",
      "name": "My Hyperliquid Trader",
      "enabled": true,
      "ai_model": "deepseek",
      "exchange": "hyperliquid",
      "hyperliquid_private_key": "your_private_key_without_0x",
      "hyperliquid_wallet_addr": "your_ethereum_address",
      "hyperliquid_testnet": false,
      "deepseek_key": "sk-xxxxxxxxxxxxx",
      "initial_balance": 1000.0,
      "scan_interval_minutes": 3
    }
  ],
  "use_default_coins": true,
  "api_server_port": 8080
}
```

**Binance設定との主な違い:**
- `binance_api_key` + `binance_secret_key`を`hyperliquid_private_key`に置き換え
- `"exchange": "hyperliquid"`フィールドを追加
- メインネットには`hyperliquid_testnet: false`、テストネットには`true`を設定

**⚠️ セキュリティ警告**: 秘密鍵は絶対に共有しないでください！メインウォレットではなく、取引専用のウォレットを使用してください。

---

#### 🔶 代替：Aster DEX取引所の使用

**NOFXはAster DEXもサポート** - Binance互換の分散型無期限先物取引所！

**なぜAsterを選ぶ？**
- 🎯 Binance互換API（簡単な移行）
- 🔐 APIウォレットセキュリティシステム
- 💰 低い取引手数料
- 🌐 マルチチェーンサポート（ETH、BSC、Polygon）
- 🌍 KYC不要

**ステップ1**: Aster APIウォレットを作成

1. [Aster APIウォレット](https://www.asterdex.com/en/api-wallet)にアクセス
2. メインウォレットを接続（MetaMask、WalletConnectなど）
3. 「APIウォレットを作成」をクリック
4. **これらの3つの項目をすぐに保存：**
   - メインウォレットアドレス（User）
   - APIウォレットアドレス（Signer）
   - APIウォレット秘密鍵（⚠️ 一度だけ表示！）

**ステップ2**: Aster用に`config.json`を設定

```json
{
  "traders": [
    {
      "id": "aster_deepseek",
      "name": "Aster DeepSeek Trader",
      "enabled": true,
      "ai_model": "deepseek",
      "exchange": "aster",

      "aster_user": "0x63DD5aCC6b1aa0f563956C0e534DD30B6dcF7C4e",
      "aster_signer": "0x21cF8Ae13Bb72632562c6Fff438652Ba1a151bb0",
      "aster_private_key": "4fd0a42218f3eae43a6ce26d22544e986139a01e5b34a62db53757ffca81bae1",

      "deepseek_key": "sk-xxxxxxxxxxxxx",
      "initial_balance": 1000.0,
      "scan_interval_minutes": 3
    }
  ],
  "use_default_coins": true,
  "api_server_port": 8080,
  "leverage": {
    "btc_eth_leverage": 5,
    "altcoin_leverage": 5
  }
}
```

**主要設定フィールド:**
- `"exchange": "aster"` - 取引所をAsterに設定
- `aster_user` - メインウォレットアドレス
- `aster_signer` - APIウォレットアドレス（ステップ1から）
- `aster_private_key` - APIウォレット秘密鍵（`0x`プレフィックスなし）

**📖 詳細なセットアップ手順については**: [Aster統合ガイド](ASTER_INTEGRATION.md)を参照

**⚠️ セキュリティ注意事項**:
- APIウォレットはメインウォレットとは別（追加のセキュリティレイヤー）
- API秘密鍵は絶対に共有しない
- [asterdex.com](https://www.asterdex.com/en/api-wallet)でいつでもAPIウォレットアクセスを取り消し可能

---

#### ⚔️ エキスパートモード：マルチトレーダー競争

複数のAIトレーダーが互いに競争する場合：

```json
{
  "traders": [
    {
      "id": "qwen_trader",
      "name": "Qwen AI Trader",
      "ai_model": "qwen",
      "binance_api_key": "YOUR_BINANCE_API_KEY_1",
      "binance_secret_key": "YOUR_BINANCE_SECRET_KEY_1",
      "use_qwen": true,
      "qwen_key": "sk-xxxxx",
      "deepseek_key": "",
      "initial_balance": 1000.0,
      "scan_interval_minutes": 3
    },
    {
      "id": "deepseek_trader",
      "name": "DeepSeek AI Trader",
      "ai_model": "deepseek",
      "binance_api_key": "YOUR_BINANCE_API_KEY_2",
      "binance_secret_key": "YOUR_BINANCE_SECRET_KEY_2",
      "use_qwen": false,
      "qwen_key": "",
      "deepseek_key": "sk-xxxxx",
      "initial_balance": 1000.0,
      "scan_interval_minutes": 3
    }
  ],
  "use_default_coins": true,
  "coin_pool_api_url": "",
  "oi_top_api_url": "",
  "api_server_port": 8080
}
```

**競争モードの要件:**
- 2つの別々のBinance先物アカウント（異なるAPIキー）
- 両方のAI APIキー（Qwen + DeepSeek）
- テスト用により多くの資本（推奨：アカウントあたり500+ USDT）

---

#### 📚 設定フィールド説明

| フィールド | 説明 | 例の値 | 必須？ |
|-------|-------------|---------------|-----------|
| `id` | このトレーダーの一意の識別子 | `"my_trader"` | ✅ はい |
| `name` | 表示名 | `"My AI Trader"` | ✅ はい |
| `enabled` | このトレーダーが有効かどうか<br>起動をスキップする場合は`false`に設定 | `true`または`false` | ✅ はい |
| `ai_model` | 使用するAIプロバイダー | `"deepseek"`または`"qwen"`または`"custom"` | ✅ はい |
| `exchange` | 使用する取引所 | `"binance"`または`"hyperliquid"`または`"aster"` | ✅ はい |
| `binance_api_key` | Binance APIキー | `"abc123..."` | Binance使用時に必須 |
| `binance_secret_key` | Binanceシークレットキー | `"xyz789..."` | Binance使用時に必須 |
| `hyperliquid_private_key` | Hyperliquid秘密鍵<br>⚠️ `0x`プレフィックスを削除 | `"your_key..."` | Hyperliquid使用時に必須 |
| `hyperliquid_wallet_addr` | Hyperliquidウォレットアドレス | `"0xabc..."` | Hyperliquid使用時に必須 |
| `hyperliquid_testnet` | テストネットを使用 | `true`または`false` | ❌ いいえ（デフォルトはfalse） |
| `use_qwen` | Qwenを使用するかどうか | `true`または`false` | ✅ はい |
| `deepseek_key` | DeepSeek APIキー | `"sk-xxx"` | DeepSeek使用時 |
| `qwen_key` | Qwen APIキー | `"sk-xxx"` | Qwen使用時 |
| `initial_balance` | 損益計算の開始残高 | `1000.0` | ✅ はい |
| `scan_interval_minutes` | 判断を行う頻度 | `3`（3-5推奨） | ✅ はい |
| **`leverage`** | **レバレッジ設定（v2.0.3+）** | 下記参照 | ✅ はい |
| `btc_eth_leverage` | BTC/ETHの最大レバレッジ<br>⚠️ サブアカウント：≤5x | `5`（デフォルト、安全）<br>`50`（メインアカウント最大） | ✅ はい |
| `altcoin_leverage` | アルトコインの最大レバレッジ<br>⚠️ サブアカウント：≤5x | `5`（デフォルト、安全）<br>`20`（メインアカウント最大） | ✅ はい |
| `use_default_coins` | 組み込みコインリストを使用<br>**✨ スマートデフォルト：`true`**（v2.0.2+）<br>API URLが提供されていない場合自動有効化 | `true`または省略 | ❌ いいえ<br>（オプション、自動デフォルト） |
| `coin_pool_api_url` | カスタムコインプールAPI<br>*`use_default_coins: false`の場合のみ必要* | `""`（空） | ❌ いいえ |
| `oi_top_api_url` | 建玉API<br>*オプション補足データ* | `""`（空） | ❌ いいえ |
| `api_server_port` | Webダッシュボードポート | `8080` | ✅ はい |

**デフォルト取引コイン**（`use_default_coins: true`の場合）：
- BTC、ETH、SOL、BNB、XRP、DOGE、ADA、HYPE

---

#### ⚙️ レバレッジ設定（v2.0.3+）

**レバレッジ設定とは？**

レバレッジ設定は、AIが各取引で使用できる最大レバレッジを制御します。これは、特にレバレッジ制限があるBinanceサブアカウントでリスク管理に重要です。

**設定形式：**

```json
"leverage": {
  "btc_eth_leverage": 5,    // BTCとETHの最大レバレッジ
  "altcoin_leverage": 5      // その他すべてのコインの最大レバレッジ
}
```

**⚠️ 重要：Binanceサブアカウント制限**

- **サブアカウント**: Binanceにより**≤5xレバレッジ**に制限
- **メインアカウント**: 最大20x（アルトコイン）または50x（BTC/ETH）を使用可能
- サブアカウントを使用していてレバレッジを>5xに設定すると、取引は**失敗**し、エラーが表示されます：`Subaccounts are restricted from using leverage greater than 5x`

**推奨設定：**

| アカウントタイプ | BTC/ETHレバレッジ | アルトコインレバレッジ | リスクレベル |
|-------------|------------------|------------------|------------|
| **サブアカウント** | `5` | `5` | ✅ 安全（デフォルト） |
| **メイン（保守的）** | `10` | `10` | 🟡 中程度 |
| **メイン（積極的）** | `20` | `15` | 🔴 高 |
| **メイン（最大）** | `50` | `20` | 🔴🔴 非常に高 |

**例：**

**安全な設定（サブアカウントまたは保守的）：**
```json
"leverage": {
  "btc_eth_leverage": 5,
  "altcoin_leverage": 5
}
```

**積極的な設定（メインアカウントのみ）：**
```json
"leverage": {
  "btc_eth_leverage": 20,
  "altcoin_leverage": 15
}
```

**AIのレバレッジ使用方法：**

- AIは設定された最大値まで**1xから任意のレバレッジを選択**できます
- たとえば、`altcoin_leverage: 20`の場合、AIは市場条件に基づいて5x、10x、または20xを使用することを決定する可能性があります
- 設定は固定値ではなく**上限**を設定します
- AIはレバレッジを選択する際にボラティリティ、リスクリワード比率、アカウント残高を考慮します

---

#### ⚠️ 重要：`use_default_coins`フィールド

**スマートデフォルト動作（v2.0.2+）：**

次の場合、システムは自動的に`use_default_coins: true`をデフォルトにします：
- config.jsonにこのフィールドを含めていない、または
- `false`に設定したが`coin_pool_api_url`を提供していない

これにより初心者に優しくなります！このフィールドを完全に省略することもできます。

**設定例：**

✅ **オプション1：明示的に設定（明確性のため推奨）**
```json
"use_default_coins": true,
"coin_pool_api_url": "",
"oi_top_api_url": ""
```

✅ **オプション2：フィールドを省略（デフォルトコインを自動使用）**
```json
// "use_default_coins"を含めないだけ
"coin_pool_api_url": "",
"oi_top_api_url": ""
```

⚙️ **高度：外部APIを使用**
```json
"use_default_coins": false,
"coin_pool_api_url": "http://your-api.com/coins",
"oi_top_api_url": "http://your-api.com/oi"
```

---

### 6. システムを実行

#### 🚀 システムの起動（2ステップ）

システムには別々に実行される**2つの部分**があります：
1. **バックエンド**（AIトレーディングブレイン + API）
2. **フロントエンド**（監視用Webダッシュボード）

---

#### **ステップ1：バックエンドを起動**

ターミナルを開いて実行：

```bash
# プログラムをビルド（初回のみ、またはコード変更後）
go build -o nofx

# バックエンドを起動
./nofx
```

**表示されるべきもの：**

```
🚀 启动自动交易系统...
✓ Trader [my_trader] 已初始化
✓ API服务器启动在端口 8080
📊 开始交易监控...
```

**⚠️ エラーが表示される場合：**

| エラーメッセージ | 解決策 |
|--------------|----------|
| `invalid API key` | config.jsonのBinance APIキーを確認 |
| `TA-Lib not found` | `brew install ta-lib`を実行（macOS） |
| `port 8080 already in use` | config.jsonの`api_server_port`を変更 |
| `DeepSeek API error` | DeepSeek APIキーと残高を確認 |

**✅ バックエンドが正しく実行されているとき：**
- エラーメッセージなし
- "开始交易监控..."が表示される
- システムがアカウント残高を表示
- このターミナルウィンドウを開いたままにしてください！

---

#### **ステップ2：フロントエンドを起動**

**新しいターミナルウィンドウ**を開き（最初のものは実行したまま）、次を実行：

```bash
cd web
npm run dev
```

**表示されるべきもの：**

```
VITE v5.x.x  ready in xxx ms

➜  Local:   http://localhost:3000/
➜  Network: use --host to expose
```

**✅ フロントエンドが実行されているとき：**
- "Local: http://localhost:3000/"メッセージ
- エラーメッセージなし
- このターミナルウィンドウも開いたままにしてください！

---

#### **ステップ3：ダッシュボードにアクセス**

Webブラウザを開いて次にアクセス：

**🌐 http://localhost:3000**

**表示されるもの：**
- 📊 リアルタイムアカウント残高
- 📈 オープンポジション（ある場合）
- 🤖 AI判断ログ
- 📉 エクイティカーブチャート

**初回のヒント：**
- 最初のAI判断まで3-5分かかることがあります
- 初期判断は「観望」（待機）と言う場合があります - これは正常です
- AIは最初に市場状況を分析する必要があります

---

### 7. システムを監視

**監視すべきもの：**

✅ **健全なシステムの兆候：**
- バックエンドターミナルが3-5分ごとに判断サイクルを表示
- 継続的なエラーメッセージなし
- アカウント残高の更新
- Webダッシュボードの自動更新

⚠️ **警告の兆候：**
- 繰り返されるAPIエラー
- 10分以上判断なし
- 残高の急速な減少

**システムステータスの確認：**

```bash
# 新しいターミナルウィンドウで
curl http://localhost:8080/health
```

戻り値：`{"status":"ok"}`

---

### 8. システムを停止

**グレースフルシャットダウン（推奨）：**

1. **バックエンドターミナル**（最初のもの）に移動
2. `Ctrl+C`を押す
3. "系统已停止"メッセージを待つ
4. **フロントエンドターミナル**（2番目のもの）に移動
5. `Ctrl+C`を押す

**⚠️ 重要：**
- 常にバックエンドを最初に停止
- ターミナルを閉じる前に確認を待つ
- 強制終了しない（ターミナルを直接閉じない）

---

## 📖 AI判断フロー

各判断サイクル（デフォルト3分）で、システムは以下のインテリジェントプロセスを実行します：

```
┌──────────────────────────────────────────────────────────┐
│ 1. 📊 過去パフォーマンスを分析（過去20サイクル）           │
├──────────────────────────────────────────────────────────┤
│  ✓ 総合勝率、平均利益、損益比を計算                       │
│  ✓ コインごとの統計（勝率、平均損益（USDT））             │
│  ✓ 最高/最悪パフォーマンスコインを特定                    │
│  ✓ 正確なPnLを含む最後の5取引の詳細をリスト              │
│  ✓ リスク調整パフォーマンスのシャープレシオを計算          │
│  📌 NEW（v2.0.2）：レバレッジを含む正確なUSDT PnL         │
└──────────────────────────────────────────────────────────┘
                           ↓
┌──────────────────────────────────────────────────────────┐
│ 2. 💰 アカウントステータスを取得                           │
├──────────────────────────────────────────────────────────┤
│  • 総エクイティと利用可能残高                             │
│  • オープンポジション数と未実現損益                       │
│  • 証拠金使用率（AIは最大90%を管理）                      │
│  • 日次損益追跡とドローダウン監視                         │
└──────────────────────────────────────────────────────────┘
                           ↓
┌──────────────────────────────────────────────────────────┐
│ 3. 🔍 既存ポジションを分析（ある場合）                     │
├──────────────────────────────────────────────────────────┤
│  • 各ポジションについて、最新の市場データを取得           │
│  • リアルタイムのテクニカル指標を計算：                   │
│    - 3分K線：RSI(7)、MACD、EMA20                         │
│    - 4時間K線：RSI(14)、EMA20/50、ATR                    │
│  • ポジション保有期間を追跡（例：「2時間15分」）          │
│    📌 NEW（v2.0.2）：各ポジションの保有期間を表示         │
│  • 表示：エントリー価格、現在価格、損益%、期間            │
│  • AIが評価：保持するかクローズするか？                   │
└──────────────────────────────────────────────────────────┘
                           ↓
┌──────────────────────────────────────────────────────────┐
│ 4. 🎯 新しい機会を評価（候補コイン）                       │
├──────────────────────────────────────────────────────────┤
│  • コインプールを取得（2モード）：                        │
│    🌟 デフォルトモード：BTC、ETH、SOL、BNB、XRPなど       │
│    ⚙️  高度モード：AI500（上位20）+ OI Top（上位20）     │
│  • 候補コインをマージして重複削除                         │
│  • フィルター：低流動性を削除（<1500万USD OI値）          │
│  • 市場データ + テクニカル指標をバッチ取得                │
│  • ボラティリティ、トレンド強度、出来高急増を計算        │
└──────────────────────────────────────────────────────────┘
                           ↓
┌──────────────────────────────────────────────────────────┐
│ 5. 🧠 AI総合判断（DeepSeek/Qwen）                         │
├──────────────────────────────────────────────────────────┤
│  • 過去フィードバックをレビュー：                         │
│    - 最近の勝率と利益率                                   │
│    - 最高/最悪コインパフォーマンス                        │
│    - 繰り返しミスを回避                                   │
│  • すべての生シーケンスデータを分析：                     │
│    - 3分価格シーケンス、4時間K線シーケンス                │
│    - 完全な指標シーケンス（最新のみではない）             │
│    📌 NEW（v2.0.2）：AIは分析の完全な自由を持つ          │
│  • 思考連鎖（CoT）推論プロセス                            │
│  • 構造化された判断を出力：                               │
│    - アクション：close_long/close_short/open_long/open_short│
│    - コインシンボル、数量、レバレッジ                     │
│    - ストップロスとテイクプロフィットレベル（≥1:2比率）   │
│  • 判断：待機/保持/クローズ/オープン                      │
└──────────────────────────────────────────────────────────┘
                           ↓
┌──────────────────────────────────────────────────────────┐
│ 6. ⚡ 取引を実行                                           │
├──────────────────────────────────────────────────────────┤
│  • 優先順位：既存をクローズ → その後新規をオープン       │
│  • 実行前のリスクチェック：                               │
│    - ポジションサイズ制限（アルトコイン1.5x、BTC 10x）    │
│    - 重複ポジションなし（同じコイン + 方向）              │
│    - 証拠金使用量が90%制限内                              │
│  • Binance LOT_SIZE精度を自動取得して適用                 │
│  • Binance Futures APIで注文を実行                        │
│  • クローズ後：すべての保留注文を自動キャンセル           │
│  • 実際の実行価格と注文IDを記録                           │
│  📌 期間計算のためにポジションオープン時間を追跡          │
└──────────────────────────────────────────────────────────┘
                           ↓
┌──────────────────────────────────────────────────────────┐
│ 7. 📝 完全なログを記録してパフォーマンスを更新             │
├──────────────────────────────────────────────────────────┤
│  • decision_logs/{trader_id}/に判断ログを保存             │
│  • ログには以下が含まれます：                             │
│    - 完全な思考連鎖（CoT）                                │
│    - すべての市場データを含む入力プロンプト               │
│    - 構造化された判断JSON                                 │
│    - アカウントスナップショット（残高、ポジション、証拠金）│
│    - 実行結果（成功/失敗、価格）                          │
│  • パフォーマンスデータベースを更新：                     │
│    - symbol_sideキーでオープン/クローズペアをマッチ       │
│      📌 NEW：ロング/ショート競合を防止                    │
│    - 正確なUSDT PnLを計算：                               │
│      PnL = ポジション価値 × 価格変化% × レバレッジ        │
│      📌 NEW：数量 + レバレッジを考慮                      │
│    - 保存：数量、レバレッジ、オープン時間、クローズ時間   │
│    - 更新：勝率、利益率、シャープレシオ                   │
│  • パフォーマンスデータは次のサイクルにフィードバック     │
└──────────────────────────────────────────────────────────┘
                           ↓
                    （3-5分ごとに繰り返し）
```

### v2.0.2の主な改善点

**📌 ポジション期間追跡：**
- システムが各ポジションの保有期間を追跡
- ユーザープロンプトに表示：「持仓时长2小时15分钟」
- AIが出口タイミングについてより良い判断を下すのに役立つ

**📌 正確なPnL計算：**
- 以前：パーセンテージのみ（100U@5% = 1000U@5% = 両方とも「5.0」と表示）
- 現在：実際のUSDT利益 = ポジション価値 × 価格変化 × レバレッジ
- 例：1000 USDT × 5% × 20x = 1000 USDT実際の利益

**📌 AI自由度の向上：**
- AIはすべての生シーケンスデータを自由に分析可能
- 事前定義された指標の組み合わせに制限されない
- 独自のトレンド分析、サポート/レジスタンス計算を実行可能

**📌 改善されたポジション追跡：**
- `symbol_side`キーを使用（例：「BTCUSDT_long」）
- ロングとショートの両方を保有する際の競合を防止
- 完全なデータを保存：数量、レバレッジ、オープン/クローズ時間

---

## 🧠 AI自己学習の例

### 過去フィードバック（プロンプトに自動追加）

```markdown
## 📊 過去パフォーマンスフィードバック

### 総合パフォーマンス
- **総取引数**: 15（利益：8 | 損失：7）
- **勝率**: 53.3%
- **平均利益**: +3.2% | 平均損失：-2.1%
- **損益比**: 1.52:1

### 最近の取引
1. BTCUSDT LONG: 95000.0000 → 97500.0000 = +2.63% ✓
2. ETHUSDT SHORT: 3500.0000 → 3450.0000 = +1.43% ✓
3. SOLUSDT LONG: 185.0000 → 180.0000 = -2.70% ✗
4. BNBUSDT LONG: 610.0000 → 625.0000 = +2.46% ✓
5. ADAUSDT LONG: 0.8500 → 0.8300 = -2.35% ✗

### コインパフォーマンス
- **最高**: BTCUSDT（勝率75%、平均+2.5%）
- **最悪**: SOLUSDT（勝率25%、平均-1.8%）
```

### AIのフィードバック使用方法

1. **連続損失を回避**: SOLUSDTが3回連続でストップロスになっているのを見て、AIは回避するかより慎重になる
2. **成功戦略を強化**: BTCブレイクアウトロングが75%の勝率で、AIはこのパターンを継続
3. **動的スタイル調整**: 勝率<40% → 保守的；損益比>2 → 積極的を維持
4. **市場状況の特定**: 連続損失は荒れた市場を示す可能性があり、取引頻度を減らす

---

## 📊 Webインターフェース機能

### 1. 競争ページ

- **🏆 リーダーボード**: リアルタイムROIランキング、ゴールドボーダーでリーダーをハイライト
- **📈 パフォーマンス比較**: デュアルAI ROIカーブ比較（紫対青）
- **⚔️ 一対一**: リードマージンを示す直接比較
- **リアルタイムデータ**: 総エクイティ、損益%、ポジション数、証拠金使用量

### 2. 詳細ページ

- **エクイティカーブ**: 過去トレンドチャート（USD/パーセンテージ切り替え）
- **統計**: 総サイクル、成功/失敗、オープン/クローズ統計
- **ポジションテーブル**: すべてのポジション詳細（エントリー価格、現在価格、損益%、清算価格）
- **AI判断ログ**: 最近の判断記録（展開可能なCoT）

### 3. リアルタイム更新

- システムステータス、アカウント情報、ポジションリスト：**5秒更新**
- 判断ログ、統計：**10秒更新**
- エクイティチャート：**10秒更新**

---

## 🎛️ APIエンドポイント

### 競争関連

```bash
GET /api/competition          # 競争リーダーボード（全トレーダー）
GET /api/traders              # トレーダーリスト
```

### 単一トレーダー関連

```bash
GET /api/status?trader_id=xxx            # システムステータス
GET /api/account?trader_id=xxx           # アカウント情報
GET /api/positions?trader_id=xxx         # ポジションリスト
GET /api/equity-history?trader_id=xxx    # エクイティ履歴（チャートデータ）
GET /api/decisions/latest?trader_id=xxx  # 最新5判断
GET /api/statistics?trader_id=xxx        # 統計
```

### システムエンドポイント

```bash
GET /health                   # ヘルスチェック
GET /api/config               # システム設定
```

---

## ⚠️ 重要なリスク警告

### 取引リスク

1. **暗号通貨市場は非常にボラティルが高い**、AI判断は利益を保証しません
2. **先物取引はレバレッジを使用**、損失が元本を超える可能性があります
3. **極端な市場状況**は清算リスクにつながる可能性があります
4. **ファンディングレート**は保有コストに影響する可能性があります
5. **流動性リスク**: 一部のコインでスリッページが発生する可能性があります

### 技術リスク

1. **ネットワークレイテンシ**は価格スリッページを引き起こす可能性があります
2. **APIレート制限**は取引実行に影響する可能性があります
3. **AI APIタイムアウト**は判断失敗を引き起こす可能性があります
4. **システムバグ**は予期しない動作を引き起こす可能性があります

### 使用推奨事項

✅ **推奨**
- テストには失っても構わない資金のみを使用
- 少額から始める（推奨100-500 USDT）
- システムの動作状態を定期的に確認
- アカウント残高の変化を監視
- AI判断ログを分析して戦略を理解

❌ **非推奨**
- すべての資金または借りたお金を投資
- 長期間監視なしで実行
- AI判断を盲目的に信頼
- システムを理解せずに使用
- 極端な市場ボラティリティ中に実行

---

## 🛠️ よくある問題

### 1. コンパイルエラー：TA-Libが見つからない

**解決策**: TA-Libライブラリをインストール
```bash
# macOS
brew install ta-lib

# Ubuntu
sudo apt-get install libta-lib0-dev
```

### 2. 精度エラー：Precision is over the maximum

**解決策**: システムがBinance LOT_SIZEから精度を自動処理します。エラーが続く場合は、ネットワーク接続を確認してください。

### 3. AI APIタイムアウト

**解決策**:
- APIキーが正しいか確認
- ネットワーク接続を確認（プロキシが必要な場合があります）
- システムタイムアウトは120秒に設定されています

### 4. フロントエンドがバックエンドに接続できない

**解決策**:
- バックエンドが実行中であることを確認（http://localhost:8080）
- ポート8080が占有されていないか確認
- ブラウザコンソールでエラーを確認

### 5. コインプールAPI失敗

**解決策**:
- コインプールAPIはオプションです
- APIが失敗した場合、システムはデフォルトのメインストリームコイン（BTC、ETHなど）を使用
- config.jsonのAPI URLと認証パラメータを確認

---

## 📈 パフォーマンス最適化のヒント

1. **合理的な判断サイクルを設定**: 3-5分を推奨、過剰取引を避ける
2. **候補コイン数を制御**: システムはデフォルトでAI500上位20 + OI Top上位20
3. **ログを定期的にクリーン**: 過度なディスク使用を避ける
4. **API呼び出し数を監視**: Binanceレート制限のトリガーを避ける
5. **少額資本でテスト**: まず100-500 USDTで戦略検証をテスト

---

## 🔄 変更履歴

### v2.0.2（2025-10-29）

**重大なバグ修正 - 取引履歴とパフォーマンス分析：**

このバージョンは、収益性統計に大きく影響した過去取引記録とパフォーマンス分析システムの**重大な計算エラー**を修正します。

**1. PnL計算 - 主要エラー修正**（logger/decision_logger.go）
- **問題**: 以前はパーセンテージのみで計算され、ポジションサイズとレバレッジを完全に無視
  - 例：100 USDTポジションが5%獲得と1000 USDTポジションが5%獲得の両方が利益として`5.0`と表示
  - これによりパフォーマンス分析が完全に不正確に
- **解決策**: 実際のUSDT利益額を計算
  ```
  PnL（USDT）= ポジション価値 × 価格変化% × レバレッジ
  例：1000 USDT × 5% × 20x = 1000 USDT実際の利益
  ```
- **影響**: 勝率、利益率、シャープレシオが正確なUSDT額に基づくようになりました

**2. ポジション追跡 - 重要データの欠落**
- **問題**: オープンポジション記録が価格と時間のみを保存、数量とレバレッジが欠落
- **解決策**: 完全な取引データを保存：
  - `quantity`: ポジションサイズ（コイン単位）
  - `leverage`: レバレッジ倍率（例：20x）
  - これらは正確なPnL計算に不可欠

**3. ポジションキーロジック - ロング/ショート競合**
- **問題**: `symbol`をポジションキーとして使用し、ロングとショートの両方を保有する際にデータ競合を引き起こす
  - 例：BTCUSDTロングとBTCUSDTショートが互いに上書き
- **解決策**: `symbol_side`形式に変更（例：`BTCUSDT_long`、`BTCUSDT_short`）
  - ロングとショートポジションを適切に区別

**4. シャープレシオ計算 - コード最適化**
- **問題**: 平方根計算にカスタムニュートン法を使用
- **解決策**: 標準ライブラリ`math.Sqrt`に置き換え
  - より信頼性が高く、保守可能で効率的

**このアップデートが重要な理由：**
- ✅ 過去取引統計が無意味なパーセンテージではなく**実際のUSDT損益**を表示
- ✅ 異なるレバレッジ取引間のパフォーマンス比較が正確に
- ✅ AI自己学習メカニズムが正しい過去フィードバックを受信
- ✅ 利益率とシャープレシオの計算が意味を持つように
- ✅ マルチポジション追跡（ロング + ショート同時）が正しく機能

**推奨**: このアップデート前にシステムを実行していた場合、過去統計は不正確でした。v2.0.2にアップデート後、新しい取引は正しく計算されます。

### v2.0.2（2025-10-29）

**バグ修正：**
- ✅ Aster取引所精度エラーを修正（コード-1111：「Precision is over the maximum defined for this asset」）
- ✅ 取引所の精度要件に合わせて価格と数量のフォーマットを改善
- ✅ デバッグ用の詳細な精度処理ログを追加
- ✅ 適切な精度処理ですべての注文関数（OpenLong、OpenShort、CloseLong、CloseShort、SetStopLoss、SetTakeProfit）を強化

**技術詳細：**
- float64を正しい精度で文字列に変換する`formatFloatWithPrecision`関数を追加
- 価格と数量パラメータが取引所の`pricePrecision`と`quantityPrecision`仕様に従ってフォーマットされるようになりました
- API リクエストを最適化するために、フォーマットされた値から末尾のゼロを削除

### v2.0.1（2025-10-29）

**バグ修正：**
- ✅ ComparisonChartデータ処理ロジックを修正 - cycle_numberからタイムスタンプグループ化に切り替え
- ✅ バックエンド再起動時にcycle_numberがリセットされるとチャートがフリーズする問題を解決
- ✅ チャートデータ表示を改善 - すべての過去データポイントを時系列で表示
- ✅ トラブルシューティングを改善するためのデバッグログを強化

### v2.0.0（2025-10-28）

**主要アップデート：**
- ✅ AI自己学習メカニズム（過去フィードバック、パフォーマンス分析）
- ✅ マルチトレーダー競争モード（Qwen対DeepSeek）
- ✅ BinanceスタイルUI（完全なBinanceインターフェース模倣）
- ✅ パフォーマンス比較チャート（リアルタイムROI比較）
- ✅ リスク管理最適化（コインごとのポジション制限調整）

**バグ修正：**
- 初期残高のハードコーディング問題を修正
- マルチトレーダーデータ同期問題を修正
- チャートデータの整列を最適化（cycle_numberを使用）

### v1.0.0（2025-10-27）
- 初回リリース
- 基本的なAI取引機能
- 判断ログシステム
- シンプルなWebインターフェース

---

## 📄 ライセンス

MITライセンス - 詳細は[LICENSE](LICENSE)ファイルを参照してください

---

## 🤝 貢献

IssueとPull Requestを歓迎します！

### 開発ガイド

1. プロジェクトをフォーク
2. 機能ブランチを作成（`git checkout -b feature/AmazingFeature`）
3. 変更をコミット（`git commit -m 'Add some AmazingFeature'`）
4. ブランチにプッシュ（`git push origin feature/AmazingFeature`）
5. Pull Requestを開く

---

## 📬 お問い合わせ


### 🐛 技術サポート
- **GitHub Issues**: [Issueを提出](https://github.com/tinkle-community/nofx/issues)
- **開発者コミュニティ**: [Telegramグループ](https://t.me/nofx_dev_community)

---

## 🙏 謝辞

- [Binance API](https://binance-docs.github.io/apidocs/futures/en/) - Binance先物API
- [DeepSeek](https://platform.deepseek.com/) - DeepSeek AI API
- [Qwen](https://dashscope.aliyuncs.com/) - Alibaba Cloud Qwen
- [TA-Lib](https://ta-lib.org/) - テクニカル指標ライブラリ
- [Recharts](https://recharts.org/) - Reactチャートライブラリ

---

**最終更新**: 2025-10-29（v2.0.3）

**⚡ AIの力で量的取引の可能性を探求しましょう！**

---

## ⭐ Star履歴

[![Star履歴チャート](https://api.star-history.com/svg?repos=tinkle-community/nofx&type=Date)](https://star-history.com/#tinkle-community/nofx&Date)

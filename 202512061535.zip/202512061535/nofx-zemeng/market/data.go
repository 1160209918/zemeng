package market

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"math"
	"strconv"
	"strings"
	"sync"
	"time"
)

// FundingRateCache 资金费率缓存结构
// Binance Funding Rate 每 8 小时才更新一次，使用 1 小时缓存可显著减少 API 调用
type FundingRateCache struct {
	Rate      float64
	UpdatedAt time.Time
}

var (
	fundingRateMap sync.Map // map[string]*FundingRateCache
	frCacheTTL     = 1 * time.Hour
)

// fetchKlinesFromAPI 从Binance API获取历史K线数据
// interval: "1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d", "3d", "1w", "1M"
// limit: 最多1000根K线
func fetchKlinesFromAPI(symbol, interval string, limit int) ([]Kline, error) {
	if limit > 1000 {
		limit = 1000 // Binance API限制
	}

	url := fmt.Sprintf("https://fapi.binance.com/fapi/v1/klines?symbol=%s&interval=%s&limit=%d",
		symbol, interval, limit)

	apiClient := NewAPIClient()
	resp, err := apiClient.client.Get(url)
	if err != nil {
		return nil, fmt.Errorf("API请求失败: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("读取响应失败: %w", err)
	}

	var rawKlines [][]interface{}
	if err := json.Unmarshal(body, &rawKlines); err != nil {
		return nil, fmt.Errorf("解析K线数据失败: %w", err)
	}

	klines := make([]Kline, 0, len(rawKlines))
	for _, raw := range rawKlines {
		if len(raw) < 11 {
			continue
		}

		kline := Kline{
			OpenTime:  int64(raw[0].(float64)),
			Open:      parseFloatFromInterface(raw[1]),
			High:      parseFloatFromInterface(raw[2]),
			Low:       parseFloatFromInterface(raw[3]),
			Close:     parseFloatFromInterface(raw[4]),
			Volume:    parseFloatFromInterface(raw[5]),
			CloseTime: int64(raw[6].(float64)),
		}
		klines = append(klines, kline)
	}

	return klines, nil
}

// parseFloatFromInterface 从interface{}解析float64
func parseFloatFromInterface(v interface{}) float64 {
	switch val := v.(type) {
	case string:
		f, _ := strconv.ParseFloat(val, 64)
		return f
	case float64:
		return val
	case int:
		return float64(val)
	case int64:
		return float64(val)
	default:
		return 0
	}
}

// Get 获取指定代币的市场数据
func Get(symbol string) (*Data, error) {
	var klines3m, klines4h []Kline
	var err error
	// 标准化symbol
	symbol = Normalize(symbol)
	// 获取3分钟K线数据 (最近10个)
	klines3m, err = WSMonitorCli.GetCurrentKlines(symbol, "3m") // 多获取一些用于计算
	if err != nil {
		return nil, fmt.Errorf("获取3分钟K线失败: %v", err)
	}

	// Data staleness detection: Prevent DOGEUSDT-style price freeze issues
	if isStaleData(klines3m, symbol) {
		log.Printf("⚠️  WARNING: %s detected stale data (consecutive price freeze), skipping symbol", symbol)
		return nil, fmt.Errorf("%s data is stale, possible cache failure", symbol)
	}

	// 获取4小时K线数据 (最近10个)
	klines4h, err = WSMonitorCli.GetCurrentKlines(symbol, "4h") // 多获取用于计算指标
	if err != nil {
		return nil, fmt.Errorf("获取4小时K线失败: %v", err)
	}

	// 检查数据是否为空
	if len(klines3m) == 0 {
		return nil, fmt.Errorf("3分钟K线数据为空")
	}
	if len(klines4h) == 0 {
		return nil, fmt.Errorf("4小时K线数据为空")
	}

	// 计算当前指标 (基于3分钟最新数据)
	currentPrice := klines3m[len(klines3m)-1].Close
	currentEMA20 := calculateEMA(klines3m, 20)
	currentMACD := calculateMACD(klines3m)
	currentRSI7 := calculateRSI(klines3m, 7)
	macdHistory := calculateMACDHistory(klines3m)

	// 计算价格变化百分比
	// 1小时价格变化 = 20个3分钟K线前的价格
	priceChange1h := 0.0
	if len(klines3m) >= 21 { // 至少需要21根K线 (当前 + 20根前)
		price1hAgo := klines3m[len(klines3m)-21].Close
		if price1hAgo > 0 {
			priceChange1h = ((currentPrice - price1hAgo) / price1hAgo) * 100
		}
	}

	// 4小时价格变化 = 1个4小时K线前的价格
	priceChange4h := 0.0
	if len(klines4h) >= 2 {
		price4hAgo := klines4h[len(klines4h)-2].Close
		if price4hAgo > 0 {
			priceChange4h = ((currentPrice - price4hAgo) / price4hAgo) * 100
		}
	}

	// 获取OI数据
	oiData, err := getOpenInterestData(symbol)
	if err != nil {
		// OI失败不影响整体,使用默认值
		oiData = &OIData{Latest: 0, Average: 0}
	}

	// 获取Funding Rate
	fundingRate, _ := getFundingRate(symbol)

	// 计算日内系列数据
	intradayData := calculateIntradaySeries(klines3m)

	// 计算长期数据
	longerTermData := calculateLongerTermData(klines4h)

	return &Data{
		Symbol:            symbol,
		CurrentPrice:      currentPrice,
		PriceChange1h:     priceChange1h,
		PriceChange4h:     priceChange4h,
		CurrentEMA20:      currentEMA20,
		CurrentMACD:       currentMACD,
		CurrentRSI7:       currentRSI7,
		MACDHistory:       macdHistory,
		OpenInterest:      oiData,
		FundingRate:       fundingRate,
		IntradaySeries:    intradayData,
		LongerTermContext: longerTermData,
	}, nil
}

// calculateEMA 计算EMA
func calculateEMA(klines []Kline, period int) float64 {
	if len(klines) < period {
		return 0
	}

	// 计算SMA作为初始EMA
	sum := 0.0
	for i := 0; i < period; i++ {
		sum += klines[i].Close
	}
	ema := sum / float64(period)

	// 计算EMA
	multiplier := 2.0 / float64(period+1)
	for i := period; i < len(klines); i++ {
		ema = (klines[i].Close-ema)*multiplier + ema
	}

	return ema
}

// calculateMACD 计算MACD
func calculateMACD(klines []Kline) float64 {
	if len(klines) < 26 {
		return 0
	}

	// 计算12期和26期EMA
	ema12 := calculateEMA(klines, 12)
	ema26 := calculateEMA(klines, 26)

	// MACD = EMA12 - EMA26
	return ema12 - ema26
}

// calculateMACDHistory 计算最近5根K线的MACD柱状图值
// 返回值: []float64，包含最近5个MACD柱状图值（histogram = DIF - DEA）
// 用于判断MACD动量趋势（连续3根放大=趋势加速，连续3根缩小=趋势减弱）
func calculateMACDHistory(klines []Kline) []float64 {
	// 需要足够数据: 26(EMA26基础) + 9(DEA周期) = 35根K线
	if len(klines) < 35 {
		return nil
	}

	// 1. 计算完整的DIF序列 (DIF = EMA12 - EMA26)
	// 从第26根K线开始可以计算DIF
	difSeries := make([]float64, 0, len(klines)-25)

	for i := 26; i <= len(klines); i++ {
		subset := klines[:i]
		ema12 := calculateEMA(subset, 12)
		ema26 := calculateEMA(subset, 26)
		dif := ema12 - ema26
		difSeries = append(difSeries, dif)
	}

	// 2. 计算DEA序列 (DEA = DIF的9期EMA)
	if len(difSeries) < 9 {
		return nil
	}

	// 计算初始DEA (前9个DIF的SMA作为初始值)
	sum := 0.0
	for i := 0; i < 9; i++ {
		sum += difSeries[i]
	}
	dea := sum / 9.0

	deaSeries := make([]float64, 0, len(difSeries)-8)
	deaSeries = append(deaSeries, dea)

	// 使用EMA公式计算后续DEA
	multiplier := 2.0 / 10.0 // 2/(9+1)
	for i := 9; i < len(difSeries); i++ {
		dea = (difSeries[i]-dea)*multiplier + dea
		deaSeries = append(deaSeries, dea)
	}

	// 3. 计算MACD柱状图 (Histogram = DIF - DEA)
	// deaSeries[0]对应difSeries[8]（使用了前9个DIF计算）
	histogramSeries := make([]float64, len(deaSeries))
	for i := 0; i < len(deaSeries); i++ {
		difIndex := i + 8 // 对齐到对应的DIF
		histogramSeries[i] = difSeries[difIndex] - deaSeries[i]
	}

	// 4. 返回最近5个柱状图值
	if len(histogramSeries) < 5 {
		return histogramSeries // 如果不足5个，返回全部
	}

	return histogramSeries[len(histogramSeries)-5:]
}

// calculateRSI 计算RSI
func calculateRSI(klines []Kline, period int) float64 {
	if len(klines) <= period {
		return 0
	}

	gains := 0.0
	losses := 0.0

	// 计算初始平均涨跌幅
	for i := 1; i <= period; i++ {
		change := klines[i].Close - klines[i-1].Close
		if change > 0 {
			gains += change
		} else {
			losses += -change
		}
	}

	avgGain := gains / float64(period)
	avgLoss := losses / float64(period)

	// 使用Wilder平滑方法计算后续RSI
	for i := period + 1; i < len(klines); i++ {
		change := klines[i].Close - klines[i-1].Close
		if change > 0 {
			avgGain = (avgGain*float64(period-1) + change) / float64(period)
			avgLoss = (avgLoss * float64(period-1)) / float64(period)
		} else {
			avgGain = (avgGain * float64(period-1)) / float64(period)
			avgLoss = (avgLoss*float64(period-1) + (-change)) / float64(period)
		}
	}

	if avgLoss == 0 {
		return 100
	}

	rs := avgGain / avgLoss
	rsi := 100 - (100 / (1 + rs))

	return rsi
}

// calculateATR 计算ATR
func calculateATR(klines []Kline, period int) float64 {
	if len(klines) <= period {
		return 0
	}

	trs := make([]float64, len(klines))
	for i := 1; i < len(klines); i++ {
		high := klines[i].High
		low := klines[i].Low
		prevClose := klines[i-1].Close

		tr1 := high - low
		tr2 := math.Abs(high - prevClose)
		tr3 := math.Abs(low - prevClose)

		trs[i] = math.Max(tr1, math.Max(tr2, tr3))
	}

	// 计算初始ATR
	sum := 0.0
	for i := 1; i <= period; i++ {
		sum += trs[i]
	}
	atr := sum / float64(period)

	// Wilder平滑
	for i := period + 1; i < len(klines); i++ {
		atr = (atr*float64(period-1) + trs[i]) / float64(period)
	}

	return atr
}

// calculateIntradaySeries 计算日内系列数据
func calculateIntradaySeries(klines []Kline) *IntradayData {
	data := &IntradayData{
		MidPrices:   make([]float64, 0, 10),
		EMA20Values: make([]float64, 0, 10),
		MACDValues:  make([]float64, 0, 10),
		RSI7Values:  make([]float64, 0, 10),
		RSI14Values: make([]float64, 0, 10),
		Volume:      make([]float64, 0, 10),
	}

	// 获取最近10个数据点
	start := len(klines) - 10
	if start < 0 {
		start = 0
	}

	for i := start; i < len(klines); i++ {
		data.MidPrices = append(data.MidPrices, klines[i].Close)
		data.Volume = append(data.Volume, klines[i].Volume)

		// 计算每个点的EMA20
		if i >= 19 {
			ema20 := calculateEMA(klines[:i+1], 20)
			data.EMA20Values = append(data.EMA20Values, ema20)
		}

		// 计算每个点的MACD
		if i >= 25 {
			macd := calculateMACD(klines[:i+1])
			data.MACDValues = append(data.MACDValues, macd)
		}

		// 计算每个点的RSI
		if i >= 7 {
			rsi7 := calculateRSI(klines[:i+1], 7)
			data.RSI7Values = append(data.RSI7Values, rsi7)
		}
		if i >= 14 {
			rsi14 := calculateRSI(klines[:i+1], 14)
			data.RSI14Values = append(data.RSI14Values, rsi14)
		}
	}

	// 计算3m ATR14
	data.ATR14 = calculateATR(klines, 14)

	return data
}

// calculateLongerTermData 计算长期数据
func calculateLongerTermData(klines []Kline) *LongerTermData {
	data := &LongerTermData{
		MACDValues:  make([]float64, 0, 10),
		RSI14Values: make([]float64, 0, 10),
	}

	// 计算EMA
	data.EMA20 = calculateEMA(klines, 20)
	data.EMA50 = calculateEMA(klines, 50)

	// 计算ATR
	data.ATR3 = calculateATR(klines, 3)
	data.ATR14 = calculateATR(klines, 14)

	// 计算成交量
	if len(klines) > 0 {
		data.CurrentVolume = klines[len(klines)-1].Volume
		// 计算平均成交量
		sum := 0.0
		for _, k := range klines {
			sum += k.Volume
		}
		data.AverageVolume = sum / float64(len(klines))
	}

	// 计算MACD和RSI序列
	start := len(klines) - 10
	if start < 0 {
		start = 0
	}

	for i := start; i < len(klines); i++ {
		if i >= 25 {
			macd := calculateMACD(klines[:i+1])
			data.MACDValues = append(data.MACDValues, macd)
		}
		if i >= 14 {
			rsi14 := calculateRSI(klines[:i+1], 14)
			data.RSI14Values = append(data.RSI14Values, rsi14)
		}
	}

	return data
}

// getOpenInterestData 获取OI数据
func getOpenInterestData(symbol string) (*OIData, error) {
	url := fmt.Sprintf("https://fapi.binance.com/fapi/v1/openInterest?symbol=%s", symbol)

	apiClient := NewAPIClient()
	resp, err := apiClient.client.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	var result struct {
		OpenInterest string `json:"openInterest"`
		Symbol       string `json:"symbol"`
		Time         int64  `json:"time"`
	}

	if err := json.Unmarshal(body, &result); err != nil {
		return nil, err
	}

	oi, _ := strconv.ParseFloat(result.OpenInterest, 64)

	return &OIData{
		Latest:  oi,
		Average: oi * 0.999, // 近似平均值
	}, nil
}

// getFundingRate 获取资金费率（优化：使用 1 小时缓存）
func getFundingRate(symbol string) (float64, error) {
	// 检查缓存（有效期 1 小时）
	// Funding Rate 每 8 小时才更新，1 小时缓存非常合理
	if cached, ok := fundingRateMap.Load(symbol); ok {
		cache := cached.(*FundingRateCache)
		if time.Since(cache.UpdatedAt) < frCacheTTL {
			// 缓存命中，直接返回
			return cache.Rate, nil
		}
	}

	// 缓存过期或不存在，调用 API
	url := fmt.Sprintf("https://fapi.binance.com/fapi/v1/premiumIndex?symbol=%s", symbol)

	apiClient := NewAPIClient()
	resp, err := apiClient.client.Get(url)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return 0, err
	}

	var result struct {
		Symbol          string `json:"symbol"`
		MarkPrice       string `json:"markPrice"`
		IndexPrice      string `json:"indexPrice"`
		LastFundingRate string `json:"lastFundingRate"`
		NextFundingTime int64  `json:"nextFundingTime"`
		InterestRate    string `json:"interestRate"`
		Time            int64  `json:"time"`
	}

	if err := json.Unmarshal(body, &result); err != nil {
		return 0, err
	}

	rate, _ := strconv.ParseFloat(result.LastFundingRate, 64)

	// 更新缓存
	fundingRateMap.Store(symbol, &FundingRateCache{
		Rate:      rate,
		UpdatedAt: time.Now(),
	})

	return rate, nil
}

// Format 格式化输出市场数据
func Format(data *Data) string {
	var sb strings.Builder

	// 使用动态精度格式化价格
	priceStr := formatPriceWithDynamicPrecision(data.CurrentPrice)
	sb.WriteString(fmt.Sprintf("current_price = %s, current_ema20 = %.3f, current_macd = %.3f, current_rsi (7 period) = %.3f\n\n",
		priceStr, data.CurrentEMA20, data.CurrentMACD, data.CurrentRSI7))

	sb.WriteString(fmt.Sprintf("In addition, here is the latest %s open interest and funding rate for perps:\n\n",
		data.Symbol))

	if data.OpenInterest != nil {
		// 使用动态精度格式化 OI 数据
		oiLatestStr := formatPriceWithDynamicPrecision(data.OpenInterest.Latest)
		oiAverageStr := formatPriceWithDynamicPrecision(data.OpenInterest.Average)
		sb.WriteString(fmt.Sprintf("Open Interest: Latest: %s Average: %s\n\n",
			oiLatestStr, oiAverageStr))
	}

	sb.WriteString(fmt.Sprintf("Funding Rate: %.2e\n\n", data.FundingRate))

	if data.IntradaySeries != nil {
		sb.WriteString("Intraday series (3‑minute intervals, oldest → latest):\n\n")

		if len(data.IntradaySeries.MidPrices) > 0 {
			sb.WriteString(fmt.Sprintf("Mid prices: %s\n\n", formatFloatSlice(data.IntradaySeries.MidPrices)))
		}

		if len(data.IntradaySeries.EMA20Values) > 0 {
			sb.WriteString(fmt.Sprintf("EMA indicators (20‑period): %s\n\n", formatFloatSlice(data.IntradaySeries.EMA20Values)))
		}

		if len(data.IntradaySeries.MACDValues) > 0 {
			sb.WriteString(fmt.Sprintf("MACD indicators: %s\n\n", formatFloatSlice(data.IntradaySeries.MACDValues)))
		}

		if len(data.IntradaySeries.RSI7Values) > 0 {
			sb.WriteString(fmt.Sprintf("RSI indicators (7‑Period): %s\n\n", formatFloatSlice(data.IntradaySeries.RSI7Values)))
		}

		if len(data.IntradaySeries.RSI14Values) > 0 {
			sb.WriteString(fmt.Sprintf("RSI indicators (14‑Period): %s\n\n", formatFloatSlice(data.IntradaySeries.RSI14Values)))
		}

		if len(data.IntradaySeries.Volume) > 0 {
			sb.WriteString(fmt.Sprintf("Volume: %s\n\n", formatFloatSlice(data.IntradaySeries.Volume)))
		}

		sb.WriteString(fmt.Sprintf("3m ATR (14‑period): %.3f\n\n", data.IntradaySeries.ATR14))
	}

	if data.LongerTermContext != nil {
		sb.WriteString("Longer‑term context (4‑hour timeframe):\n\n")

		sb.WriteString(fmt.Sprintf("20‑Period EMA: %.3f vs. 50‑Period EMA: %.3f\n\n",
			data.LongerTermContext.EMA20, data.LongerTermContext.EMA50))

		sb.WriteString(fmt.Sprintf("3‑Period ATR: %.3f vs. 14‑Period ATR: %.3f\n\n",
			data.LongerTermContext.ATR3, data.LongerTermContext.ATR14))

		sb.WriteString(fmt.Sprintf("Current Volume: %.3f vs. Average Volume: %.3f\n\n",
			data.LongerTermContext.CurrentVolume, data.LongerTermContext.AverageVolume))

		if len(data.LongerTermContext.MACDValues) > 0 {
			sb.WriteString(fmt.Sprintf("MACD indicators: %s\n\n", formatFloatSlice(data.LongerTermContext.MACDValues)))
		}

		if len(data.LongerTermContext.RSI14Values) > 0 {
			sb.WriteString(fmt.Sprintf("RSI indicators (14‑Period): %s\n\n", formatFloatSlice(data.LongerTermContext.RSI14Values)))
		}
	}

	return sb.String()
}

// formatPriceWithDynamicPrecision 根据价格区间动态选择精度
// 这样可以完美支持从超低价 meme coin (< 0.0001) 到 BTC/ETH 的所有币种
func formatPriceWithDynamicPrecision(price float64) string {
	switch {
	case price < 0.0001:
		// 超低价 meme coin: 1000SATS, 1000WHY, DOGS
		// 0.00002070 → "0.00002070" (8位小数)
		return fmt.Sprintf("%.8f", price)
	case price < 0.001:
		// 低价 meme coin: NEIRO, HMSTR, HOT, NOT
		// 0.00015060 → "0.000151" (6位小数)
		return fmt.Sprintf("%.6f", price)
	case price < 0.01:
		// 中低价币: PEPE, SHIB, MEME
		// 0.00556800 → "0.005568" (6位小数)
		return fmt.Sprintf("%.6f", price)
	case price < 1.0:
		// 低价币: ASTER, DOGE, ADA, TRX
		// 0.9954 → "0.9954" (4位小数)
		return fmt.Sprintf("%.4f", price)
	case price < 100:
		// 中价币: SOL, AVAX, LINK, MATIC
		// 23.4567 → "23.4567" (4位小数)
		return fmt.Sprintf("%.4f", price)
	default:
		// 高价币: BTC, ETH (节省 Token)
		// 45678.9123 → "45678.91" (2位小数)
		return fmt.Sprintf("%.2f", price)
	}
}

// formatFloatSlice 格式化float64切片为字符串（使用动态精度）
func formatFloatSlice(values []float64) string {
	strValues := make([]string, len(values))
	for i, v := range values {
		strValues[i] = formatPriceWithDynamicPrecision(v)
	}
	return "[" + strings.Join(strValues, ", ") + "]"
}

// Normalize 标准化symbol,确保是USDT交易对
func Normalize(symbol string) string {
	symbol = strings.ToUpper(symbol)
	if strings.HasSuffix(symbol, "USDT") {
		return symbol
	}
	return symbol + "USDT"
}

// parseFloat 解析float值
func parseFloat(v interface{}) (float64, error) {
	switch val := v.(type) {
	case string:
		return strconv.ParseFloat(val, 64)
	case float64:
		return val, nil
	case int:
		return float64(val), nil
	case int64:
		return float64(val), nil
	default:
		return 0, fmt.Errorf("unsupported type: %T", v)
	}
}

// calculateSupertrend 计算Supertrend指标 (ATR=10, 倍数=3.0)
// 基于TradingView代码精确实现
func calculateSupertrend(klines []Kline) *SupertrendData {
	if len(klines) < 10 {
		return nil
	}

	const atrPeriod = 10
	const multiplier = 3.0

	// 计算ATR
	atr := calculateATR(klines, atrPeriod)
	if atr == 0 {
		return nil
	}

	// 获取最新K线数据
	latestKline := klines[len(klines)-1]
	hl2 := (latestKline.High + latestKline.Low) / 2

	// 初始化上下轨
	up := hl2 - multiplier*atr
	dn := hl2 + multiplier*atr

	// 计算完整的Supertrend序列以获取当前趋势
	tr := 1  // 初始趋势方向 (1=多头, -1=空头)
	u1 := up // 上轨
	d1 := dn // 下轨

	// 遍历K线计算趋势
	for i := 1; i < len(klines); i++ {
		prevClose := klines[i-1].Close
		currentClose := klines[i].Close
		currentHl2 := (klines[i].High + klines[i].Low) / 2

		// 计算当前ATR
		currentATR := calculateATR(klines[:i+1], atrPeriod)
		if currentATR == 0 {
			continue
		}

		// 计算当前上下轨
		currentUp := currentHl2 - multiplier*currentATR
		currentDn := currentHl2 + multiplier*currentATR

		// 更新上轨: 如果前一个收盘价 > 前一个上轨，取当前上轨和前一个上轨的最大值，否则用当前上轨
		if prevClose > u1 {
			u1 = math.Max(currentUp, u1)
		} else {
			u1 = currentUp
		}

		// 更新下轨: 如果前一个收盘价 < 前一个下轨，取当前下轨和前一个下轨的最小值，否则用当前下轨
		if prevClose < d1 {
			d1 = math.Min(currentDn, d1)
		} else {
			d1 = currentDn
		}

		// 更新趋势方向
		if tr == -1 && currentClose > d1 {
			tr = 1 // 从空头转为多头
		} else if tr == 1 && currentClose < u1 {
			tr = -1 // 从多头转为空头
		}
	}

	// 返回Supertrend值和方向
	var stLine float64
	if tr == 1 {
		stLine = u1
	} else {
		stLine = d1
	}

	return &SupertrendData{
		Value:     stLine,
		Direction: tr,
	}
}

// calculateFRVP 计算FRVP指标 (338根K线的POC/VAH/VAL)
// 基于TradingView代码精确实现
func calculateFRVP(klines []Kline) *FRVPData {
	// 需要至少338根K线
	lookback := 338
	if len(klines) < lookback {
		lookback = len(klines)
	}

	// 使用最近338根K线
	recentKlines := klines[len(klines)-lookback:]

	// 计算价格范围
	h := recentKlines[0].High
	l := recentKlines[0].Low

	for i := 1; i < len(recentKlines); i++ {
		h = math.Max(h, recentKlines[i].High)
		l = math.Min(l, recentKlines[i].Low)
	}

	// 如果价格范围无效
	if h <= l || h == 0 || l == 0 {
		return nil
	}

	// 将价格范围分成24个档位(与TradingView一致)
	const numBins = 24
	rh := (h - l) / numBins

	// 初始化成交量数组(分为上涨和下跌)
	vu := make([]float64, numBins) // 上涨成交量
	vd := make([]float64, numBins) // 下跌成交量

	// 遍历所有K线,将成交量分配到对应价格档位
	for _, kline := range recentKlines {
		if kline.Volume <= 0 {
			continue
		}

		// 计算K线的价格范围对应的档位
		lr := int(math.Max(0, math.Min(numBins-1, math.Floor((kline.Low-l)/rh))))
		hr := int(math.Max(0, math.Min(numBins-1, math.Floor((kline.High-l)/rh))))

		// 将成交量平均分配到覆盖的档位
		vpr := kline.Volume / float64(hr-lr+1)

		for j := lr; j <= hr; j++ {
			if kline.Close >= kline.Open {
				vu[j] += vpr // 上涨K线
			} else {
				vd[j] += vpr // 下跌K线
			}
		}
	}

	// 计算每个档位的总成交量(取上涨和下跌的最大值)
	av := make([]float64, numBins)
	mv := 0.0  // 最大成交量
	pr := 0    // 最大成交量对应的档位(POC档位)

	for i := 0; i < numBins; i++ {
		av[i] = math.Max(vu[i], vd[i])
		if av[i] > mv {
			mv = av[i]
			pr = i
		}
	}

	// 计算POC价格(最大成交量档位的中点)
	poc := l + (float64(pr)+0.5)*rh

	// 计算VAH和VAL (包含70%成交量的价值区域)
	tv := 0.0 // 总成交量
	for i := 0; i < numBins; i++ {
		tv += av[i]
	}

	vv := av[pr]       // 当前累计成交量(从POC开始)
	ur := pr           // 上边界档位
	lwr := pr          // 下边界档位
	targetVolume := tv * 0.7

	// 从POC向两侧扩展,直到累计成交量达到70%
	for i := 0; i < numBins; i++ {
		if vv >= targetVolume {
			break
		}

		cu := ur < numBins-1   // 可以向上扩展
		cl := lwr > 0          // 可以向下扩展

		if !cu && !cl {
			break
		}

		// 获取上下两侧的成交量
		uv := -1.0
		if cu {
			uv = av[ur+1]
		}
		lv := -1.0
		if cl {
			lv = av[lwr-1]
		}

		// 选择成交量更大的一侧扩展
		if cu && cl {
			if uv > lv {
				ur++
				vv += uv
			} else if lv > uv {
				lwr--
				vv += lv
			} else {
				// 相等时同时扩展
				ur++
				lwr--
				vv += uv + lv
			}
		} else if cu {
			ur++
			vv += uv
		} else if cl {
			lwr--
			vv += lv
		}
	}

	// 计算VAH和VAL价格
	vah := l + (float64(ur)+0.5)*rh
	val := l + (float64(lwr)+0.5)*rh

	return &FRVPData{
		POC: poc,
		VAH: vah,
		VAL: val,
	}
}

// isStaleData detects stale data (consecutive price freeze)
// Fix DOGEUSDT-style issue: consecutive N periods with completely unchanged prices indicate data source anomaly
func isStaleData(klines []Kline, symbol string) bool {
	if len(klines) < 5 {
		return false // Insufficient data to determine
	}

	// Detection threshold: 5 consecutive 3-minute periods with unchanged price (15 minutes without fluctuation)
	const stalePriceThreshold = 5
	const priceTolerancePct = 0.0001 // 0.01% fluctuation tolerance (avoid false positives)

	// Take the last stalePriceThreshold K-lines
	recentKlines := klines[len(klines)-stalePriceThreshold:]
	firstPrice := recentKlines[0].Close

	// Check if all prices are within tolerance
	for i := 1; i < len(recentKlines); i++ {
		priceDiff := math.Abs(recentKlines[i].Close-firstPrice) / firstPrice
		if priceDiff > priceTolerancePct {
			return false // Price fluctuation exists, data is normal
		}
	}

	// Additional check: MACD and volume
	// If price is unchanged but MACD/volume shows normal fluctuation, it might be a real market situation (extremely low volatility)
	// Check if volume is also 0 (data completely frozen)
	allVolumeZero := true
	for _, k := range recentKlines {
		if k.Volume > 0 {
			allVolumeZero = false
			break
		}
	}

	if allVolumeZero {
		log.Printf("⚠️  %s stale data confirmed: price freeze + zero volume", symbol)
		return true
	}

	// Price frozen but has volume: might be extremely low volatility market, allow but log warning
	log.Printf("⚠️  %s detected extreme price stability (no fluctuation for %d consecutive periods), but volume is normal", symbol, stalePriceThreshold)
	return false
}

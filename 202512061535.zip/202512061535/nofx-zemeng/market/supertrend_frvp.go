package market

import (
	"fmt"
	"log"
)

// GetMultiTimeframeData 获取多时间周期的Supertrend+FRVP数据
// 用于SuperTrend+FRVP策略
func GetMultiTimeframeData(symbol string) (*MultiTimeframeData, error) {
	symbol = Normalize(symbol)

	// 获取15M K线数据 (需要350根以确保有足够数据计算338根FRVP)
	klines15m, err := fetchKlinesFromAPI(symbol, "15m", 350)
	if err != nil {
		return nil, fmt.Errorf("获取15M K线失败: %w", err)
	}

	// 获取4H K线数据 (需要350根以确保有足够数据计算338根FRVP)
	klines4h, err := fetchKlinesFromAPI(symbol, "4h", 350)
	if err != nil {
		return nil, fmt.Errorf("获取4H K线失败: %w", err)
	}

	// 验证数据充足性
	if len(klines15m) < 338 {
		log.Printf("⚠️  %s 15M K线数据不足: %d < 338", symbol, len(klines15m))
	}
	if len(klines4h) < 338 {
		log.Printf("⚠️  %s 4H K线数据不足: %d < 338", symbol, len(klines4h))
	}

	// 计算15M时间框架指标
	tf15m := &TimeframeIndicators{
		CurrentPrice: 0,
		Supertrend:   nil,
		FRVP:         nil,
	}

	if len(klines15m) > 0 {
		tf15m.CurrentPrice = klines15m[len(klines15m)-1].Close

		// 计算Supertrend (需要至少10根K线)
		if len(klines15m) >= 10 {
			tf15m.Supertrend = calculateSupertrend(klines15m)
			if tf15m.Supertrend == nil {
				log.Printf("⚠️  %s 15M Supertrend计算失败", symbol)
			}
		}

		// 计算FRVP (理想情况需要338根K线)
		if len(klines15m) >= 50 { // 至少需要50根才有意义
			tf15m.FRVP = calculateFRVP(klines15m)
			if tf15m.FRVP == nil {
				log.Printf("⚠️  %s 15M FRVP计算失败", symbol)
			}
		}
	}

	// 计算4H时间框架指标
	tf4h := &TimeframeIndicators{
		CurrentPrice: 0,
		Supertrend:   nil,
		FRVP:         nil,
	}

	if len(klines4h) > 0 {
		tf4h.CurrentPrice = klines4h[len(klines4h)-1].Close

		// 计算Supertrend
		if len(klines4h) >= 10 {
			tf4h.Supertrend = calculateSupertrend(klines4h)
			if tf4h.Supertrend == nil {
				log.Printf("⚠️  %s 4H Supertrend计算失败", symbol)
			}
		}

		// 计算FRVP
		if len(klines4h) >= 50 {
			tf4h.FRVP = calculateFRVP(klines4h)
			if tf4h.FRVP == nil {
				log.Printf("⚠️  %s 4H FRVP计算失败", symbol)
			}
		}
	}

	return &MultiTimeframeData{
		Timeframe15M: tf15m,
		Timeframe4H:  tf4h,
	}, nil
}

// FormatMultiTimeframeData 格式化多时间周期数据用于AI提示词
func FormatMultiTimeframeData(symbol string, mtf *MultiTimeframeData) string {
	if mtf == nil {
		return fmt.Sprintf("%s: 多时间周期数据不可用\n", symbol)
	}

	var result string

	// 15M时间框架
	result += fmt.Sprintf("📊 %s 15分钟时间框架:\n", symbol)
	if mtf.Timeframe15M != nil {
		result += fmt.Sprintf("  当前价格: %.4f\n", mtf.Timeframe15M.CurrentPrice)

		if mtf.Timeframe15M.Supertrend != nil {
			direction := "多头"
			if mtf.Timeframe15M.Supertrend.Direction == -1 {
				direction = "空头"
			}
			result += fmt.Sprintf("  Supertrend: %.4f (方向: %s)\n",
				mtf.Timeframe15M.Supertrend.Value, direction)
		} else {
			result += "  Supertrend: 数据不足\n"
		}

		if mtf.Timeframe15M.FRVP != nil {
			result += fmt.Sprintf("  FRVP-338: POC=%.4f | VAH=%.4f | VAL=%.4f\n",
				mtf.Timeframe15M.FRVP.POC,
				mtf.Timeframe15M.FRVP.VAH,
				mtf.Timeframe15M.FRVP.VAL)
		} else {
			result += "  FRVP-338: 数据不足\n"
		}
	} else {
		result += "  数据不可用\n"
	}

	// 4H时间框架
	result += fmt.Sprintf("\n📊 %s 4小时时间框架:\n", symbol)
	if mtf.Timeframe4H != nil {
		result += fmt.Sprintf("  当前价格: %.4f\n", mtf.Timeframe4H.CurrentPrice)

		if mtf.Timeframe4H.Supertrend != nil {
			direction := "多头"
			if mtf.Timeframe4H.Supertrend.Direction == -1 {
				direction = "空头"
			}
			result += fmt.Sprintf("  Supertrend: %.4f (方向: %s)\n",
				mtf.Timeframe4H.Supertrend.Value, direction)
		} else {
			result += "  Supertrend: 数据不足\n"
		}

		if mtf.Timeframe4H.FRVP != nil {
			result += fmt.Sprintf("  FRVP-338: POC=%.4f | VAH=%.4f | VAL=%.4f\n",
				mtf.Timeframe4H.FRVP.POC,
				mtf.Timeframe4H.FRVP.VAH,
				mtf.Timeframe4H.FRVP.VAL)
		} else {
			result += "  FRVP-338: 数据不足\n"
		}
	} else {
		result += "  数据不可用\n"
	}

	result += "\n"
	return result
}

// CheckLongCondition 检查做多条件
// 1. 4H价格 > 4H Supertrend
// 2. 15M价格 > 15M Supertrend
// 3. 15M价格 > 15M 338 VAH
// 返回: (是否满足条件, 建议止损价格, 条件说明)
func CheckLongCondition(mtf *MultiTimeframeData) (bool, float64, string) {
	if mtf == nil || mtf.Timeframe15M == nil || mtf.Timeframe4H == nil {
		return false, 0, "多时间周期数据不可用"
	}

	// 检查必要数据是否完整
	if mtf.Timeframe4H.Supertrend == nil {
		return false, 0, "4H Supertrend数据缺失"
	}
	if mtf.Timeframe15M.Supertrend == nil {
		return false, 0, "15M Supertrend数据缺失"
	}
	if mtf.Timeframe15M.FRVP == nil {
		return false, 0, "15M FRVP数据缺失"
	}

	// 条件1: 4H价格 > 4H Supertrend
	cond1 := mtf.Timeframe4H.CurrentPrice > mtf.Timeframe4H.Supertrend.Value
	// 条件2: 15M价格 > 15M Supertrend
	cond2 := mtf.Timeframe15M.CurrentPrice > mtf.Timeframe15M.Supertrend.Value
	// 条件3: 15M价格 > 15M VAH
	cond3 := mtf.Timeframe15M.CurrentPrice > mtf.Timeframe15M.FRVP.VAH

	// 建议止损: 15M Supertrend值
	stopLoss := mtf.Timeframe15M.Supertrend.Value

	// 生成条件说明
	explanation := fmt.Sprintf("做多条件检查: [1]4H价格>4HST:%v [2]15M价格>15MST:%v [3]15M价格>VAH:%v",
		cond1, cond2, cond3)

	return cond1 && cond2 && cond3, stopLoss, explanation
}

// CheckShortCondition 检查做空条件
// 1. 4H价格 < 4H Supertrend
// 2. 15M价格 < 15M Supertrend
// 3. 15M价格 < 15M 338 VAL
// 返回: (是否满足条件, 建议止损价格, 条件说明)
func CheckShortCondition(mtf *MultiTimeframeData) (bool, float64, string) {
	if mtf == nil || mtf.Timeframe15M == nil || mtf.Timeframe4H == nil {
		return false, 0, "多时间周期数据不可用"
	}

	// 检查必要数据是否完整
	if mtf.Timeframe4H.Supertrend == nil {
		return false, 0, "4H Supertrend数据缺失"
	}
	if mtf.Timeframe15M.Supertrend == nil {
		return false, 0, "15M Supertrend数据缺失"
	}
	if mtf.Timeframe15M.FRVP == nil {
		return false, 0, "15M FRVP数据缺失"
	}

	// 条件1: 4H价格 < 4H Supertrend
	cond1 := mtf.Timeframe4H.CurrentPrice < mtf.Timeframe4H.Supertrend.Value
	// 条件2: 15M价格 < 15M Supertrend
	cond2 := mtf.Timeframe15M.CurrentPrice < mtf.Timeframe15M.Supertrend.Value
	// 条件3: 15M价格 < 15M VAL
	cond3 := mtf.Timeframe15M.CurrentPrice < mtf.Timeframe15M.FRVP.VAL

	// 建议止损: 15M Supertrend值
	stopLoss := mtf.Timeframe15M.Supertrend.Value

	// 生成条件说明
	explanation := fmt.Sprintf("做空条件检查: [1]4H价格<4HST:%v [2]15M价格<15MST:%v [3]15M价格<VAL:%v",
		cond1, cond2, cond3)

	return cond1 && cond2 && cond3, stopLoss, explanation
}
package trader

import (
	"fmt"
	"log"
	"math"
	"nofx/config"
	"strings"
	"time"
)

// PositionManager 仓位管理器 (SuperTrend+FRVP策略专用)
type PositionManager struct {
	database *config.Database
	traderID string
	userID   string
}

// PositionManagementData 仓位管理计算结果
type PositionManagementData struct {
	// 反马丁仓位数据
	AntiMartingalePosition float64 `json:"anti_martingale_position"` // 反马丁仓位
	BaseCapital            float64 `json:"base_capital"`             // 基础本金
	SingleMargin           float64 `json:"single_margin"`            // 单笔保证金
	TotalEquity            float64 `json:"total_equity"`             // 总资金

	// 风控状态
	CurrentPositionCount   int     `json:"current_position_count"`    // 当前持仓数量
	TodayOpenCount         int     `json:"today_open_count"`          // 今日开仓次数
	BaseCapitalLossPct     float64 `json:"base_capital_loss_pct"`     // 基础本金亏损百分比
	AntiMartingaleLossPct  float64 `json:"anti_martingale_loss_pct"`  // 反马丁仓位亏损百分比
	CanOpenPosition        bool    `json:"can_open_position"`         // 是否可开仓
	RiskControlReason      string  `json:"risk_control_reason"`       // 风控拒绝原因

	// 计算字段
	Date string `json:"date"` // 日期 (YYYY-MM-DD)
}

// OpenPositionParams 开仓参数计算结果
type OpenPositionParams struct {
	StopLossDistance    float64 `json:"stop_loss_distance"`    // 止损波幅(%)，含手续费
	TheoreticalLeverage int     `json:"theoretical_leverage"`  // 理论开仓倍数
	ActualLeverage      int     `json:"actual_leverage"`       // 实际开仓倍数 (受最大倍数限制)
	PositionSizeUSD     float64 `json:"position_size_usd"`     // 开仓价值 (USDT)
	ActualRisk          float64 `json:"actual_risk"`           // 实际风险% (止损时保证金亏损比例)
	Symbol              string  `json:"symbol"`                // 币种
	IsBTCETH            bool    `json:"is_btc_eth"`            // 是否为BTC/ETH
}

// NewPositionManager 创建仓位管理器
func NewPositionManager(database *config.Database, traderID, userID string) *PositionManager {
	return &PositionManager{
		database: database,
		traderID: traderID,
		userID:   userID,
	}
}

// GetManagementData 获取仓位管理数据
func (pm *PositionManager) GetManagementData(totalEquity float64, currentPositionCount int) (*PositionManagementData, error) {
	return pm.GetManagementDataWithPositions(totalEquity, currentPositionCount, nil)
}

// GetManagementDataWithPositions 获取仓位管理数据（含板块统计）
func (pm *PositionManager) GetManagementDataWithPositions(totalEquity float64, currentPositionCount int, positionSymbols []string) (*PositionManagementData, error) {
	// ⚠️ 使用UTC时间，与 auto_trader.go 中的 AddDailyPnL 保持一致
	today := time.Now().UTC().Format("2006-01-02")

	// 1. 获取今日记录
	todayRecord, err := pm.database.GetAntiMartingalePosition(pm.traderID, pm.userID, today)
	if err != nil {
		return nil, fmt.Errorf("获取今日反马丁仓位失败: %w", err)
	}

	// 2. 获取昨日记录
	yesterdayRecord, err := pm.database.GetPreviousDayAntiMartingalePosition(pm.traderID, pm.userID, today)
	if err != nil {
		return nil, fmt.Errorf("获取昨日反马丁仓位失败: %w", err)
	}

	// 3. 计算反马丁仓位
	// 反马丁仓位(临时) = 昨日反马丁 + 0.9×昨日盈利 - 昨日亏损
	var antiMartingalePosition float64
	if yesterdayRecord != nil {
		antiMartingalePosition = yesterdayRecord.AntiMartingalePosition +
			0.9*yesterdayRecord.DailyProfit -
			yesterdayRecord.DailyLoss

		// 确保不为负数
		if antiMartingalePosition < 0 {
			antiMartingalePosition = 0
		}

		// 反马丁仓位上限 = 总资金×50%
		maxAntiMartingale := totalEquity * 0.5
		if antiMartingalePosition > maxAntiMartingale {
			log.Printf("📊 [仓位管理] 反马丁仓位超出上限 (%.2f > %.2f)，超出部分转入基础本金", antiMartingalePosition, maxAntiMartingale)
			antiMartingalePosition = maxAntiMartingale
		}
	} else {
		// 首次启动，反马丁仓位为0
		antiMartingalePosition = 0
	}

	// 4. 计算基础本金 (保证≥50%总资金)
	baseCapital := totalEquity - antiMartingalePosition
	if baseCapital < totalEquity*0.5 {
		baseCapital = totalEquity * 0.5
	}

	// 5. 计算单笔保证金
	// 单笔保证金 = 0.02×基础本金 + 0.3×反马丁仓位
	singleMargin := 0.02*baseCapital + 0.3*antiMartingalePosition

	// 6. 计算基础本金亏损百分比
	baseCapitalLossPct := 0.0
	if todayRecord != nil && todayRecord.DailyLoss > 0 && baseCapital > 0 {
		// 基础本金占比 = 0.02×基础本金 / 单笔保证金
		baseCapitalRatio := 0.02 * baseCapital / singleMargin
		baseCapitalLossPct = (todayRecord.DailyLoss * baseCapitalRatio) / baseCapital * 100
	}

	// 7. 计算反马丁仓位亏损百分比
	antiMartingaleLossPct := 0.0
	if todayRecord != nil && todayRecord.DailyLoss > 0 && antiMartingalePosition > 0 {
		// 反马丁占比 = 0.3×反马丁仓位 / 单笔保证金
		antiMartingaleRatio := 0.3 * antiMartingalePosition / singleMargin
		antiMartingaleLossPct = (todayRecord.DailyLoss * antiMartingaleRatio) / antiMartingalePosition * 100
	}

	// 8. 获取今日开仓次数
	todayOpenCount := 0
	if todayRecord != nil {
		todayOpenCount = todayRecord.OpenCount
	}

	// 9. 风控检查：是否可开仓
	canOpenPosition := true
	riskControlReason := ""

	if currentPositionCount >= 3 {
		canOpenPosition = false
		riskControlReason = fmt.Sprintf("持仓数量已达上限 (%d/3)", currentPositionCount)
		log.Printf("⚠️  [仓位管理] %s", riskControlReason)
	}
	if todayOpenCount >= 8 {
		canOpenPosition = false
		riskControlReason = fmt.Sprintf("今日开仓次数已达上限 (%d/8)", todayOpenCount)
		log.Printf("⚠️  [仓位管理] %s", riskControlReason)
	}
	if baseCapitalLossPct >= 6.0 {
		canOpenPosition = false
		riskControlReason = fmt.Sprintf("基础本金亏损超过阈值 (%.2f%% >= 6%%)", baseCapitalLossPct)
		log.Printf("⚠️  [仓位管理] %s", riskControlReason)
	}
	if antiMartingaleLossPct >= 30.0 {
		canOpenPosition = false
		riskControlReason = fmt.Sprintf("反马丁仓位亏损超过阈值 (%.2f%% >= 30%%)", antiMartingaleLossPct)
		log.Printf("⚠️  [仓位管理] %s", riskControlReason)
	}

	// 11. 更新或创建今日记录
	if todayRecord == nil || todayRecord.AntiMartingalePosition != antiMartingalePosition ||
		todayRecord.BaseCapital != baseCapital || todayRecord.TotalEquity != totalEquity {
		newRecord := &config.AntiMartingalePosition{
			TraderID:               pm.traderID,
			UserID:                 pm.userID,
			Date:                   today,
			AntiMartingalePosition: antiMartingalePosition,
			BaseCapital:            baseCapital,
			TotalEquity:            totalEquity,
			DailyProfit:            0,
			DailyLoss:              0,
			OpenCount:              todayOpenCount,
		}

		if todayRecord != nil {
			// 保留今日盈亏数据
			newRecord.DailyProfit = todayRecord.DailyProfit
			newRecord.DailyLoss = todayRecord.DailyLoss
		}

		if err := pm.database.UpsertAntiMartingalePosition(newRecord); err != nil {
			log.Printf("⚠️  [仓位管理] 更新今日记录失败: %v", err)
		}
	}

	return &PositionManagementData{
		AntiMartingalePosition: antiMartingalePosition,
		BaseCapital:            baseCapital,
		SingleMargin:           singleMargin,
		TotalEquity:            totalEquity,
		CurrentPositionCount:   currentPositionCount,
		TodayOpenCount:         todayOpenCount,
		BaseCapitalLossPct:     baseCapitalLossPct,
		AntiMartingaleLossPct:  antiMartingaleLossPct,
		CanOpenPosition:        canOpenPosition,
		RiskControlReason:      riskControlReason,
		Date:                   today,
	}, nil
}

// CalculateOpenPosition 计算开仓参数
// currentPrice: 当前价格
// stopLossPrice: 止损价格 (15M SuperTrend值)
// symbol: 币种
// isBTCETH: 是否为BTC/ETH
// managementData: 仓位管理数据
func (pm *PositionManager) CalculateOpenPosition(
	currentPrice float64,
	stopLossPrice float64,
	symbol string,
	isBTCETH bool,
	managementData *PositionManagementData,
) (*OpenPositionParams, error) {
	// 1. 计算止损波幅(%) + 0.08%手续费
	// 止损波幅% = |当前价 - 15M ST| / 当前价 × 100 + 0.08%
	rawStopLossDistance := math.Abs(currentPrice-stopLossPrice) / currentPrice * 100
	stopLossDistance := rawStopLossDistance + 0.08 // 加上手续费

	// 最小止损距离检查 (0.3%)
	if rawStopLossDistance < 0.3 {
		return nil, fmt.Errorf("止损距离过小 (%.2f%% < 0.3%%)，处于临界区域", rawStopLossDistance)
	}

	if stopLossDistance <= 0 {
		return nil, fmt.Errorf("止损波幅无效: %.4f%%", stopLossDistance)
	}

	// 2. 计算理论开仓倍数
	// 理论杠杆 = 85 / 止损波幅%
	theoreticalLeverage := int(85 / stopLossDistance)

	// 确保至少为1倍
	if theoreticalLeverage < 1 {
		theoreticalLeverage = 1
	}

	// 3. 应用最大倍数限制
	var maxLeverage int
	if isBTCETH {
		maxLeverage = 50
	} else {
		maxLeverage = 20
	}

	actualLeverage := theoreticalLeverage
	if actualLeverage > maxLeverage {
		actualLeverage = maxLeverage
	}

	// 4. 计算开仓价值
	// 开仓价值 = 单笔保证金 × 实际开仓倍数
	positionSizeUSD := managementData.SingleMargin * float64(actualLeverage)

	// 确保最小开仓价值 (交易所要求)
	minPositionSize := 12.0
	if positionSizeUSD < minPositionSize {
		log.Printf("⚠️  [仓位管理] 开仓价值过小 (%.2f < %.2f USDT)，调整至最小值", positionSizeUSD, minPositionSize)
		positionSizeUSD = minPositionSize
	}

	// 5. 计算实际风险%
	// 实际风险% = 实际杠杆 × 止损波幅%
	actualRisk := float64(actualLeverage) * stopLossDistance

	log.Printf("📊 [仓位管理] %s 开仓计算: 止损波幅=%.2f%%(含0.08%%手续费), 理论倍数=%dx, 实际倍数=%dx, 开仓价值=%.2f USDT, 风险=%.2f%%",
		symbol, stopLossDistance, theoreticalLeverage, actualLeverage, positionSizeUSD, actualRisk)

	return &OpenPositionParams{
		StopLossDistance:    stopLossDistance,
		TheoreticalLeverage: theoreticalLeverage,
		ActualLeverage:      actualLeverage,
		PositionSizeUSD:     positionSizeUSD,
		ActualRisk:          actualRisk,
		Symbol:              symbol,
		IsBTCETH:            isBTCETH,
	}, nil
}

// IncrementOpenCount 增加今日开仓次数
func (pm *PositionManager) IncrementOpenCount() error {
	// ⚠️ 使用UTC时间，与其他函数保持一致
	today := time.Now().UTC().Format("2006-01-02")
	err := pm.database.IncrementOpenCount(pm.traderID, pm.userID, today)
	if err != nil {
		return fmt.Errorf("增加开仓次数失败: %w", err)
	}

	log.Printf("✅ [仓位管理] 今日开仓次数已增加")
	return nil
}

// UpdateDailyPnL 更新当日盈亏
func (pm *PositionManager) UpdateDailyPnL(profit, loss float64) error {
	// ⚠️ 使用UTC时间，与其他函数保持一致
	today := time.Now().UTC().Format("2006-01-02")
	err := pm.database.UpdateDailyPnL(pm.traderID, pm.userID, today, profit, loss)
	if err != nil {
		return fmt.Errorf("更新当日盈亏失败: %w", err)
	}

	log.Printf("✅ [仓位管理] 当日盈亏已更新: 盈利=%.2f, 亏损=%.2f", profit, loss)
	return nil
}

// FormatManagementDataForPrompt 格式化仓位管理数据用于AI提示词（新格式）
func FormatManagementDataForPrompt(data *PositionManagementData) string {
	var sb strings.Builder

	// 风控状态行（简洁格式）
	canOpenStr := "✅可开仓"
	if !data.CanOpenPosition {
		canOpenStr = "❌禁止开仓"
	}

	sb.WriteString(fmt.Sprintf("【风控】持仓%d/3 | 今日开仓%d/8 | 基础亏损%.1f%% | 反马丁亏损%.1f%% | %s\n",
		data.CurrentPositionCount,
		data.TodayOpenCount,
		data.BaseCapitalLossPct,
		data.AntiMartingaleLossPct,
		canOpenStr))

	// 资金状态
	sb.WriteString(fmt.Sprintf("【资金】基础本金%.2f | 反马丁%.2f | 单笔保证金%.2f\n",
		data.BaseCapital, data.AntiMartingalePosition, data.SingleMargin))

	if !data.CanOpenPosition && data.RiskControlReason != "" {
		sb.WriteString(fmt.Sprintf("【警告】%s\n", data.RiskControlReason))
	}

	return sb.String()
}

// FormatCandidateForPrompt 格式化可开仓候选币种
func FormatCandidateForPrompt(
	symbol string,
	direction string, // "long" or "short"
	currentPrice float64,
	stopLoss float64,
	params *OpenPositionParams,
	macdSignal string, // "金叉" or "死叉"
	data *PositionManagementData,
) string {
	directionStr := "long"
	if direction == "short" {
		directionStr = "short"
	}

	return fmt.Sprintf("✅ %s %s | 价%.4f 止%.4f(%.2f%%) | 保证金%.2f 杠杆%dx 风险%.0f%% | MACD%s\n",
		symbol, directionStr,
		currentPrice, stopLoss, params.StopLossDistance,
		data.SingleMargin, params.ActualLeverage, params.ActualRisk,
		macdSignal)
}

// FormatPositionForPrompt 格式化持仓信息
func FormatPositionForPrompt(
	symbol string,
	side string,
	entryPrice float64,
	currentPrice float64,
	pnlPct float64,
	stopLoss float64,
	holdingHours int,
	canAddPosition bool,
	canReducePosition bool,
) string {
	hourlyReturn := 0.0
	if holdingHours > 0 {
		hourlyReturn = pnlPct / float64(holdingHours)
	}

	status := ""
	if canAddPosition {
		status = " ✅可加仓"
	} else if canReducePosition {
		status = " ⚠️建议减仓"
	}

	holdingWarning := ""
	if holdingHours > 72 && pnlPct < 5 {
		holdingWarning = " 🔴强烈建议平仓"
	} else if holdingHours > 48 && pnlPct < 10 {
		holdingWarning = " 🟡建议平仓"
	} else if holdingHours > 24 {
		holdingWarning = " 📌长期持仓"
	}

	return fmt.Sprintf("%s %s | 入场%.4f 现%.4f(%+.1f%%) | 止损%.4f | %dH %.2f%%/H%s%s\n",
		symbol, side,
		entryPrice, currentPrice, pnlPct,
		stopLoss,
		holdingHours, hourlyReturn,
		status, holdingWarning)
}

// IsBTCETH 判断币种是否为BTC/ETH
func IsBTCETH(symbol string) bool {
	return symbol == "BTCUSDT" || symbol == "ETHUSDT"
}
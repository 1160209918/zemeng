package trader

import (
	"encoding/json"
	"fmt"
	"log"
	"math"
	"nofx/config"
	"nofx/decision"
	"nofx/logger"
	"nofx/market"
	"nofx/mcp"
	"nofx/pool"
	"strings"
	"sync"
	"time"
)

// AutoTraderConfig 自动交易配置（简化版 - AI全权决策）
type AutoTraderConfig struct {
	// Trader标识
	ID      string // Trader唯一标识（用于日志目录等）
	Name    string // Trader显示名称
	AIModel string // AI模型: "qwen" 或 "deepseek"

	// 交易平台选择
	Exchange string // "binance", "hyperliquid" 或 "aster"

	// 币安API配置
	BinanceAPIKey    string
	BinanceSecretKey string

	// Hyperliquid配置
	HyperliquidPrivateKey string
	HyperliquidWalletAddr string
	HyperliquidTestnet    bool

	// Aster配置
	AsterUser       string // Aster主钱包地址
	AsterSigner     string // Aster API钱包地址
	AsterPrivateKey string // Aster API钱包私钥

	CoinPoolAPIURL string

	// AI配置
	UseQwen     bool
	DeepSeekKey string
	QwenKey     string

	// 自定义AI API配置
	CustomAPIURL    string
	CustomAPIKey    string
	CustomModelName string

	// 扫描配置
	ScanInterval time.Duration // 扫描间隔（建议3分钟）

	// 账户配置
	InitialBalance float64 // 初始金额（用于计算盈亏，需手动设置）

	// 杠杆配置
	BTCETHLeverage  int // BTC和ETH的杠杆倍数
	AltcoinLeverage int // 山寨币的杠杆倍数

	// 风险控制（仅作为提示，AI可自主决定）
	MaxDailyLoss    float64       // 最大日亏损百分比（提示）
	MaxDrawdown     float64       // 最大回撤百分比（提示）
	StopTradingTime time.Duration // 触发风控后暂停时长

	// 仓位模式
	IsCrossMargin bool // true=全仓模式, false=逐仓模式

	// 币种配置
	DefaultCoins []string // 默认币种列表（从数据库获取）
	TradingCoins []string // 实际交易币种列表

	// 系统提示词模板
	SystemPromptTemplate string // 系统提示词模板名称（如 "default", "aggressive"）
}

// AutoTrader 自动交易器
type AutoTrader struct {
	id                    string // Trader唯一标识
	name                  string // Trader显示名称
	aiModel               string // AI模型名称
	exchange              string // 交易平台名称
	config                AutoTraderConfig
	trader                Trader // 使用Trader接口（支持多平台）
	mcpClient             mcp.AIClient
	decisionLogger        logger.IDecisionLogger // 决策日志记录器
	initialBalance        float64
	dailyPnL              float64
	customPrompt          string   // 自定义交易策略prompt
	overrideBasePrompt    bool     // 是否覆盖基础prompt
	systemPromptTemplate  string   // 系统提示词模板名称
	defaultCoins          []string // 默认币种列表（从数据库获取）
	tradingCoins          []string // 实际交易币种列表
	lastResetTime         time.Time
	stopUntil             time.Time
	isRunning             bool
	startTime             time.Time          // 系统启动时间
	callCount             int                // AI调用次数
	positionFirstSeenTime map[string]int64            // 持仓首次出现时间 (symbol_side -> timestamp毫秒)
	lastKnownPositions    map[string]map[string]interface{} // 上一周期的持仓快照 (symbol_side -> position info)
	stopMonitorCh         chan struct{}                     // 用于停止监控goroutine
	monitorWg             sync.WaitGroup     // 用于等待监控goroutine结束
	peakPnLCache          map[string]float64 // 最高收益缓存 (symbol -> 峰值盈亏百分比)
	peakPnLCacheMutex     sync.RWMutex       // 缓存读写锁
	lastBalanceSyncTime   time.Time          // 上次余额同步时间
	database              interface{}        // 数据库引用（用于自动更新余额）
	userID                string             // 用户ID
}

// NewAutoTrader 创建自动交易器
func NewAutoTrader(config AutoTraderConfig, database interface{}, userID string) (*AutoTrader, error) {
	// 设置默认值
	if config.ID == "" {
		config.ID = "default_trader"
	}
	if config.Name == "" {
		config.Name = "Default Trader"
	}
	if config.AIModel == "" {
		if config.UseQwen {
			config.AIModel = "qwen"
		} else {
			config.AIModel = "deepseek"
		}
	}

	mcpClient := mcp.New()

	// 初始化AI
	if config.AIModel == "custom" {
		// 使用自定义API
		mcpClient.SetAPIKey(config.CustomAPIKey, config.CustomAPIURL, config.CustomModelName)
		log.Printf("🤖 [%s] 使用自定义AI API: %s (模型: %s)", config.Name, config.CustomAPIURL, config.CustomModelName)
	} else if config.UseQwen || config.AIModel == "qwen" {
		// 使用Qwen (支持自定义URL和Model)
		mcpClient = mcp.NewQwenClient()
		mcpClient.SetAPIKey(config.QwenKey, config.CustomAPIURL, config.CustomModelName)
		if config.CustomAPIURL != "" || config.CustomModelName != "" {
			log.Printf("🤖 [%s] 使用阿里云Qwen AI (自定义URL: %s, 模型: %s)", config.Name, config.CustomAPIURL, config.CustomModelName)
		} else {
			log.Printf("🤖 [%s] 使用阿里云Qwen AI", config.Name)
		}
	} else {
		// 默认使用DeepSeek (支持自定义URL和Model)
		mcpClient = mcp.NewDeepSeekClient()
		mcpClient.SetAPIKey(config.DeepSeekKey, config.CustomAPIURL, config.CustomModelName)
		if config.CustomAPIURL != "" || config.CustomModelName != "" {
			log.Printf("🤖 [%s] 使用DeepSeek AI (自定义URL: %s, 模型: %s)", config.Name, config.CustomAPIURL, config.CustomModelName)
		} else {
			log.Printf("🤖 [%s] 使用DeepSeek AI", config.Name)
		}
	}

	// 初始化币种池API
	if config.CoinPoolAPIURL != "" {
		pool.SetCoinPoolAPI(config.CoinPoolAPIURL)
	}

	// 设置默认交易平台
	if config.Exchange == "" {
		config.Exchange = "binance"
	}

	// 根据配置创建对应的交易器
	var trader Trader
	var err error

	// 记录仓位模式（通用）
	marginModeStr := "全仓"
	if !config.IsCrossMargin {
		marginModeStr = "逐仓"
	}
	log.Printf("📊 [%s] 仓位模式: %s", config.Name, marginModeStr)

	switch config.Exchange {
	case "binance":
		log.Printf("🏦 [%s] 使用币安合约交易", config.Name)
		trader = NewFuturesTrader(config.BinanceAPIKey, config.BinanceSecretKey, userID)
	case "hyperliquid":
		log.Printf("🏦 [%s] 使用Hyperliquid交易", config.Name)
		trader, err = NewHyperliquidTrader(config.HyperliquidPrivateKey, config.HyperliquidWalletAddr, config.HyperliquidTestnet)
		if err != nil {
			return nil, fmt.Errorf("初始化Hyperliquid交易器失败: %w", err)
		}
	case "aster":
		log.Printf("🏦 [%s] 使用Aster交易", config.Name)
		trader, err = NewAsterTrader(config.AsterUser, config.AsterSigner, config.AsterPrivateKey)
		if err != nil {
			return nil, fmt.Errorf("初始化Aster交易器失败: %w", err)
		}
	default:
		return nil, fmt.Errorf("不支持的交易平台: %s", config.Exchange)
	}

	// 验证初始金额配置
	if config.InitialBalance <= 0 {
		return nil, fmt.Errorf("初始金额必须大于0，请在配置中设置InitialBalance")
	}

	// 初始化决策日志记录器（使用trader ID创建独立目录）
	logDir := fmt.Sprintf("decision_logs/%s", config.ID)
	decisionLogger := logger.NewDecisionLogger(logDir)

	// 设置默认系统提示词模板
	systemPromptTemplate := config.SystemPromptTemplate
	if systemPromptTemplate == "" {
		// feature/partial-close-dynamic-tpsl 分支默认使用 adaptive（支持动态止盈止损）
		systemPromptTemplate = "adaptive"
	}

	return &AutoTrader{
		id:                    config.ID,
		name:                  config.Name,
		aiModel:               config.AIModel,
		exchange:              config.Exchange,
		config:                config,
		trader:                trader,
		mcpClient:             mcpClient,
		decisionLogger:        decisionLogger,
		initialBalance:        config.InitialBalance,
		systemPromptTemplate:  systemPromptTemplate,
		defaultCoins:          config.DefaultCoins,
		tradingCoins:          config.TradingCoins,
		lastResetTime:         time.Now(),
		startTime:             time.Now(),
		callCount:             0,
		isRunning:             false,
		positionFirstSeenTime: make(map[string]int64),
		lastKnownPositions:    make(map[string]map[string]interface{}),
		stopMonitorCh:         make(chan struct{}),
		monitorWg:             sync.WaitGroup{},
		peakPnLCache:          make(map[string]float64),
		peakPnLCacheMutex:     sync.RWMutex{},
		lastBalanceSyncTime:   time.Now(), // 初始化为当前时间
		database:              database,
		userID:                userID,
	}, nil
}

// Run 运行自动交易主循环
func (at *AutoTrader) Run() error {
	at.isRunning = true
	at.stopMonitorCh = make(chan struct{})
	at.startTime = time.Now()

	log.Println("🚀 AI驱动自动交易系统启动")
	log.Printf("💰 初始余额: %.2f USDT", at.initialBalance)
	log.Printf("⚙️  扫描间隔: %v", at.config.ScanInterval)
	log.Println("🤖 AI将全权决定杠杆、仓位大小、止损止盈等参数")
	at.monitorWg.Add(1)
	defer at.monitorWg.Done()

	// 启动回撤监控（已禁用，完全依赖AI策略的SuperTrend动态止损）
	// at.startDrawdownMonitor()

	// 启动15M SuperTrend动态止损监控（仅supertrend_frvp策略）
	at.startSuperTrendStopLossMonitor()

	ticker := time.NewTicker(at.config.ScanInterval)
	defer ticker.Stop()

	// 首次立即执行
	if err := at.runCycle(); err != nil {
		log.Printf("❌ 执行失败: %v", err)
	}

	for at.isRunning {
		select {
		case <-ticker.C:
			if err := at.runCycle(); err != nil {
				log.Printf("❌ 执行失败: %v", err)
			}
		case <-at.stopMonitorCh:
			log.Printf("[%s] ⏹ 收到停止信号，退出自动交易主循环", at.name)
			return nil
		}
	}

	return nil
}

// Stop 停止自动交易
func (at *AutoTrader) Stop() {
	if !at.isRunning {
		return
	}
	at.isRunning = false
	close(at.stopMonitorCh) // 通知监控goroutine停止
	at.monitorWg.Wait()     // 等待监控goroutine结束
	log.Println("⏹ 自动交易系统停止")
}

// runCycle 运行一个交易周期（使用AI全权决策）
func (at *AutoTrader) runCycle() error {
	at.callCount++

	log.Print("\n" + strings.Repeat("=", 70) + "\n")
	log.Printf("⏰ %s - AI决策周期 #%d", time.Now().Format("2006-01-02 15:04:05"), at.callCount)
	log.Println(strings.Repeat("=", 70))

	// 创建决策记录
	record := &logger.DecisionRecord{
		ExecutionLog: []string{},
		Success:      true,
	}

	// 1. 检查是否需要停止交易
	if time.Now().Before(at.stopUntil) {
		remaining := at.stopUntil.Sub(time.Now())
		log.Printf("⏸ 风险控制：暂停交易中，剩余 %.0f 分钟", remaining.Minutes())
		record.Success = false
		record.ErrorMessage = fmt.Sprintf("风险控制暂停中，剩余 %.0f 分钟", remaining.Minutes())
		at.decisionLogger.LogDecision(record)
		return nil
	}

	// 2. 重置日盈亏（每天重置）
	if time.Since(at.lastResetTime) > 24*time.Hour {
		at.dailyPnL = 0
		at.lastResetTime = time.Now()
		log.Println("📅 日盈亏已重置")
	}

	// 4. 收集交易上下文
	ctx, err := at.buildTradingContext()
	if err != nil {
		record.Success = false
		record.ErrorMessage = fmt.Sprintf("构建交易上下文失败: %v", err)
		at.decisionLogger.LogDecision(record)
		return fmt.Errorf("构建交易上下文失败: %w", err)
	}

	// 保存账户状态快照
	record.AccountState = logger.AccountSnapshot{
		TotalBalance:          ctx.Account.TotalEquity - ctx.Account.UnrealizedPnL,
		AvailableBalance:      ctx.Account.AvailableBalance,
		TotalUnrealizedProfit: ctx.Account.UnrealizedPnL,
		PositionCount:         ctx.Account.PositionCount,
		MarginUsedPct:         ctx.Account.MarginUsedPct,
		InitialBalance:        at.initialBalance, // 记录当时的初始余额基准
	}

	// 保存持仓快照
	for _, pos := range ctx.Positions {
		record.Positions = append(record.Positions, logger.PositionSnapshot{
			Symbol:           pos.Symbol,
			Side:             pos.Side,
			PositionAmt:      pos.Quantity,
			EntryPrice:       pos.EntryPrice,
			MarkPrice:        pos.MarkPrice,
			UnrealizedProfit: pos.UnrealizedPnL,
			Leverage:         float64(pos.Leverage),
			LiquidationPrice: pos.LiquidationPrice,
		})
	}

	log.Print(strings.Repeat("=", 70))
	for _, coin := range ctx.CandidateCoins {
		record.CandidateCoins = append(record.CandidateCoins, coin.Symbol)
	}

	log.Printf("📊 账户净值: %.2f USDT | 可用: %.2f USDT | 持仓: %d",
		ctx.Account.TotalEquity, ctx.Account.AvailableBalance, ctx.Account.PositionCount)

	// 5. 调用AI获取完整决策
	log.Printf("🤖 正在请求AI分析并决策... [模板: %s]", at.systemPromptTemplate)
	decision, err := decision.GetFullDecisionWithCustomPrompt(ctx, at.mcpClient, at.customPrompt, at.overrideBasePrompt, at.systemPromptTemplate)

	if decision != nil && decision.AIRequestDurationMs > 0 {
		record.AIRequestDurationMs = decision.AIRequestDurationMs
		log.Printf("⏱️ AI调用耗时: %.2f 秒", float64(record.AIRequestDurationMs)/1000)
		record.ExecutionLog = append(record.ExecutionLog,
			fmt.Sprintf("AI调用耗时: %d ms", record.AIRequestDurationMs))
	}

	// 即使有错误，也保存思维链、决策和输入prompt（用于debug）
	if decision != nil {
		record.SystemPrompt = decision.SystemPrompt // 保存系统提示词
		record.InputPrompt = decision.UserPrompt
		record.CoTTrace = decision.CoTTrace
		if len(decision.Decisions) > 0 {
			decisionJSON, _ := json.MarshalIndent(decision.Decisions, "", "  ")
			record.DecisionJSON = string(decisionJSON)
		}
	}

	if err != nil {
		record.Success = false
		record.ErrorMessage = fmt.Sprintf("获取AI决策失败: %v", err)

		// 打印系统提示词和AI思维链（即使有错误，也要输出以便调试）
		if decision != nil {
			log.Print("\n" + strings.Repeat("=", 70) + "\n")
			log.Printf("📋 系统提示词 [模板: %s] (错误情况)", at.systemPromptTemplate)
			log.Println(strings.Repeat("=", 70))
			log.Println(decision.SystemPrompt)
			log.Println(strings.Repeat("=", 70))

			if decision.CoTTrace != "" {
				log.Print("\n" + strings.Repeat("-", 70) + "\n")
				log.Println("💭 AI思维链分析（错误情况）:")
				log.Println(strings.Repeat("-", 70))
				log.Println(decision.CoTTrace)
				log.Println(strings.Repeat("-", 70))
			}
		}

		at.decisionLogger.LogDecision(record)
		return fmt.Errorf("获取AI决策失败: %w", err)
	}

	// // 5. 打印系统提示词
	// log.Printf("\n" + strings.Repeat("=", 70))
	// log.Printf("📋 系统提示词 [模板: %s]", at.systemPromptTemplate)
	// log.Println(strings.Repeat("=", 70))
	// log.Println(decision.SystemPrompt)
	// log.Printf(strings.Repeat("=", 70) + "\n")

	// 6. 打印AI思维链
	// log.Printf("\n" + strings.Repeat("-", 70))
	// log.Println("💭 AI思维链分析:")
	// log.Println(strings.Repeat("-", 70))
	// log.Println(decision.CoTTrace)
	// log.Printf(strings.Repeat("-", 70) + "\n")

	// 7. 打印AI决策
	// log.Printf("📋 AI决策列表 (%d 个):\n", len(decision.Decisions))
	// for i, d := range decision.Decisions {
	//     log.Printf("  [%d] %s: %s - %s", i+1, d.Symbol, d.Action, d.Reasoning)
	//     if d.Action == "open_long" || d.Action == "open_short" {
	//        log.Printf("      杠杆: %dx | 仓位: %.2f USDT | 止损: %.4f | 止盈: %.4f",
	//           d.Leverage, d.PositionSizeUSD, d.StopLoss, d.TakeProfit)
	//     }
	// }
	log.Println()
	log.Print(strings.Repeat("-", 70))
	// 8. 对决策排序：确保先平仓后开仓（防止仓位叠加超限）
	log.Print(strings.Repeat("-", 70))

	// 8. 对决策排序：确保先平仓后开仓（防止仓位叠加超限）
	sortedDecisions := sortDecisionsByPriority(decision.Decisions)

	log.Println("🔄 执行顺序（已优化）: 先平仓→后开仓")
	for i, d := range sortedDecisions {
		log.Printf("  [%d] %s %s", i+1, d.Symbol, d.Action)
	}
	log.Println()

	// 执行决策并记录结果
	for _, d := range sortedDecisions {
		actionRecord := logger.DecisionAction{
			Action:    d.Action,
			Symbol:    d.Symbol,
			Quantity:  0,
			Leverage:  d.Leverage,
			Price:     0,
			Timestamp: time.Now(),
			Success:   false,
		}

		if err := at.executeDecisionWithRecord(&d, &actionRecord); err != nil {
			log.Printf("❌ 执行决策失败 (%s %s): %v", d.Symbol, d.Action, err)
			actionRecord.Error = err.Error()
			record.ExecutionLog = append(record.ExecutionLog, fmt.Sprintf("❌ %s %s 失败: %v", d.Symbol, d.Action, err))
		} else {
			actionRecord.Success = true
			record.ExecutionLog = append(record.ExecutionLog, fmt.Sprintf("✓ %s %s 成功", d.Symbol, d.Action))
			// 成功执行后短暂延迟
			time.Sleep(1 * time.Second)
		}

		record.Decisions = append(record.Decisions, actionRecord)
	}

	// 9. 保存决策记录
	if err := at.decisionLogger.LogDecision(record); err != nil {
		log.Printf("⚠ 保存决策记录失败: %v", err)
	}

	return nil
}

// buildTradingContext 构建交易上下文
func (at *AutoTrader) buildTradingContext() (*decision.Context, error) {
	// 1. 获取账户信息
	balance, err := at.trader.GetBalance()
	if err != nil {
		return nil, fmt.Errorf("获取账户余额失败: %w", err)
	}

	// 获取账户字段
	totalWalletBalance := 0.0
	totalUnrealizedProfit := 0.0
	availableBalance := 0.0

	if wallet, ok := balance["totalWalletBalance"].(float64); ok {
		totalWalletBalance = wallet
	}
	if unrealized, ok := balance["totalUnrealizedProfit"].(float64); ok {
		totalUnrealizedProfit = unrealized
	}
	if avail, ok := balance["availableBalance"].(float64); ok {
		availableBalance = avail
	}

	// Total Equity = 钱包余额 + 未实现盈亏
	totalEquity := totalWalletBalance + totalUnrealizedProfit

	// 2. 获取持仓信息
	positions, err := at.trader.GetPositions()
	if err != nil {
		return nil, fmt.Errorf("获取持仓失败: %w", err)
	}

	var positionInfos []decision.PositionInfo
	totalMarginUsed := 0.0

	// 当前持仓的key集合（用于清理已平仓的记录）
	currentPositionKeys := make(map[string]bool)

	for _, pos := range positions {
		symbol := pos["symbol"].(string)
		side := pos["side"].(string)
		entryPrice := pos["entryPrice"].(float64)
		markPrice := pos["markPrice"].(float64)
		quantity := pos["positionAmt"].(float64)
		if quantity < 0 {
			quantity = -quantity // 空仓数量为负，转为正数
		}

		// 跳过已平仓的持仓（quantity = 0），防止"幽灵持仓"传递给AI
		if quantity == 0 {
			continue
		}

		unrealizedPnl := pos["unRealizedProfit"].(float64)
		liquidationPrice := pos["liquidationPrice"].(float64)

		// 计算占用保证金（估算）
		leverage := 10 // 默认值，实际应该从持仓信息获取
		if lev, ok := pos["leverage"].(float64); ok {
			leverage = int(lev)
		}
		marginUsed := (quantity * markPrice) / float64(leverage)
		totalMarginUsed += marginUsed

		// 计算盈亏百分比（基于保证金，考虑杠杆）
		pnlPct := calculatePnLPercentage(unrealizedPnl, marginUsed)

		// 跟踪持仓首次出现时间
		posKey := symbol + "_" + side
		currentPositionKeys[posKey] = true
		if _, exists := at.positionFirstSeenTime[posKey]; !exists {
			// 新持仓，记录当前时间
			at.positionFirstSeenTime[posKey] = time.Now().UnixMilli()
		}
		updateTime := at.positionFirstSeenTime[posKey]

		// 获取该持仓的历史最高收益率
		at.peakPnLCacheMutex.RLock()
		peakPnlPct := at.peakPnLCache[posKey]
		at.peakPnLCacheMutex.RUnlock()

		positionInfos = append(positionInfos, decision.PositionInfo{
			Symbol:           symbol,
			Side:             side,
			EntryPrice:       entryPrice,
			MarkPrice:        markPrice,
			Quantity:         quantity,
			Leverage:         leverage,
			UnrealizedPnL:    unrealizedPnl,
			UnrealizedPnLPct: pnlPct,
			PeakPnLPct:       peakPnlPct,
			LiquidationPrice: liquidationPrice,
			MarginUsed:       marginUsed,
			UpdateTime:       updateTime,
		})
	}

	// 清理已平仓的持仓记录
	for key := range at.positionFirstSeenTime {
		if !currentPositionKeys[key] {
			delete(at.positionFirstSeenTime, key)
		}
	}

	// 3. 获取交易员的候选币种池
	candidateCoins, err := at.getCandidateCoins()
	if err != nil {
		return nil, fmt.Errorf("获取候选币种失败: %w", err)
	}

	// 4. 计算总盈亏
	totalPnL := totalEquity - at.initialBalance
	totalPnLPct := 0.0
	if at.initialBalance > 0 {
		totalPnLPct = (totalPnL / at.initialBalance) * 100
	}

	marginUsedPct := 0.0
	if totalEquity > 0 {
		marginUsedPct = (totalMarginUsed / totalEquity) * 100
	}

	// 5. 分析历史表现（最近100个周期，避免长期持仓的交易记录丢失）
	// 假设每3分钟一个周期，100个周期 = 5小时，足够覆盖大部分交易
	performance, err := at.decisionLogger.AnalyzePerformance(100)
	if err != nil {
		log.Printf("⚠️  分析历史表现失败: %v", err)
		// 不影响主流程，继续执行（但设置performance为nil以避免传递错误数据）
		performance = nil
	}

	// 6. 计算仓位管理数据（仅SuperTrend+FRVP策略使用）
	var positionManagementDataFormatted string
	if at.systemPromptTemplate == "supertrend_frvp" && at.database != nil && at.userID != "" {
		positionMgr := NewPositionManager(at.database.(*config.Database), at.id, at.userID)

		// 计算仓位管理数据
		managementData, err := positionMgr.GetManagementData(
			totalEquity,
			len(positionInfos), // 当前持仓数量
		)
		if err != nil {
			log.Printf("⚠️  [%s] 获取仓位管理数据失败: %v", at.id, err)
		} else {
			// 格式化数据用于注入提示词
			positionManagementDataFormatted = FormatManagementDataForPrompt(managementData)

			log.Printf("📊 [仓位管理] 基础本金=%.2f, 反马丁仓位=%.2f, 单笔保证金=%.2f, 可开仓=%v",
				managementData.BaseCapital,
				managementData.AntiMartingalePosition,
				managementData.SingleMargin,
				managementData.CanOpenPosition,
			)
		}
	}

	// 7. 构建上下文
	ctx := &decision.Context{
		CurrentTime:     time.Now().Format("2006-01-02 15:04:05"),
		RuntimeMinutes:  int(time.Since(at.startTime).Minutes()),
		CallCount:       at.callCount,
		BTCETHLeverage:  at.config.BTCETHLeverage,  // 使用配置的杠杆倍数
		AltcoinLeverage: at.config.AltcoinLeverage, // 使用配置的杠杆倍数
		Account: decision.AccountInfo{
			TotalEquity:      totalEquity,
			AvailableBalance: availableBalance,
			UnrealizedPnL:    totalUnrealizedProfit,
			TotalPnL:         totalPnL,
			TotalPnLPct:      totalPnLPct,
			MarginUsed:       totalMarginUsed,
			MarginUsedPct:    marginUsedPct,
			PositionCount:    len(positionInfos),
		},
		Positions:      positionInfos,
		CandidateCoins: candidateCoins,
		Performance:    performance, // 添加历史表现分析
		// SuperTrend+FRVP 策略专用字段
		TraderID:                      at.id,
		UserID:                        at.userID,
		Database:                      at.database,
		TemplateName:                  at.systemPromptTemplate,
		PositionManagementDataFormatted: positionManagementDataFormatted,
	}

	return ctx, nil
}

// executeDecisionWithRecord 执行AI决策并记录详细信息
func (at *AutoTrader) executeDecisionWithRecord(decision *decision.Decision, actionRecord *logger.DecisionAction) error {
	switch decision.Action {
	case "open_long":
		return at.executeOpenLongWithRecord(decision, actionRecord)
	case "open_short":
		return at.executeOpenShortWithRecord(decision, actionRecord)
	case "close_long":
		return at.executeCloseLongWithRecord(decision, actionRecord)
	case "close_short":
		return at.executeCloseShortWithRecord(decision, actionRecord)
	case "update_stop_loss":
		return at.executeUpdateStopLossWithRecord(decision, actionRecord)
	case "update_take_profit":
		return at.executeUpdateTakeProfitWithRecord(decision, actionRecord)
	case "partial_close":
		return at.executePartialCloseWithRecord(decision, actionRecord)
	case "add_position":
		return at.executeAddPositionWithRecord(decision, actionRecord)
	case "reduce_position":
		return at.executeReducePositionWithRecord(decision, actionRecord)
	case "hold", "wait":
		// 无需执行，仅记录
		return nil
	default:
		return fmt.Errorf("未知的action: %s", decision.Action)
	}
}

// executeOpenLongWithRecord 执行开多仓并记录详细信息
func (at *AutoTrader) executeOpenLongWithRecord(decision *decision.Decision, actionRecord *logger.DecisionAction) error {
	log.Printf("  📈 开多仓: %s", decision.Symbol)

	// ⚠️ 关键：检查是否已有同币种同方向持仓，如果有则拒绝开仓（防止仓位叠加超限）
	positions, err := at.trader.GetPositions()
	if err == nil {
		for _, pos := range positions {
			if pos["symbol"] == decision.Symbol && pos["side"] == "long" {
				return fmt.Errorf("❌ %s 已有多仓，拒绝开仓以防止仓位叠加超限。如需换仓，请先给出 close_long 决策", decision.Symbol)
			}
		}
	}

	// 获取当前价格
	marketData, err := market.Get(decision.Symbol)
	if err != nil {
		return err
	}

	// ========== SuperTrend+FRVP 仓位管理系统集成 ==========
	if at.systemPromptTemplate == "supertrend_frvp" && at.database != nil && at.userID != "" {
		// 1. 如果AI没有提供止损价格，自动从15M SuperTrend获取
		if decision.StopLoss <= 0 {
			mtfData, err := market.GetMultiTimeframeData(decision.Symbol)
			if err != nil {
				return fmt.Errorf("❌ 获取SuperTrend数据失败: %w", err)
			}
			if mtfData.Timeframe15M == nil || mtfData.Timeframe15M.Supertrend == nil {
				return fmt.Errorf("❌ 15M SuperTrend数据不可用")
			}
			decision.StopLoss = mtfData.Timeframe15M.Supertrend.Value
			log.Printf("  ℹ️  [SuperTrend+FRVP] 系统自动设置止损价格: %.4f (15M SuperTrend)", decision.StopLoss)
		}

		// 2. 初始化仓位管理器
		positionMgr := NewPositionManager(at.database.(*config.Database), at.id, at.userID)

		// 3. 获取账户总权益
		balance, err := at.trader.GetBalance()
		if err != nil {
			return fmt.Errorf("获取账户余额失败: %w", err)
		}
		totalEquity := 0.0
		if equity, ok := balance["totalWalletBalance"].(float64); ok {
			totalEquity = equity
		}
		if unrealized, ok := balance["totalUnrealizedProfit"].(float64); ok {
			totalEquity += unrealized
		}

		// 4. 获取仓位管理数据
		managementData, err := positionMgr.GetManagementData(totalEquity, len(positions))
		if err != nil {
			return fmt.Errorf("获取仓位管理数据失败: %w", err)
		}

		// 5. 风控验证
		if !managementData.CanOpenPosition {
			return fmt.Errorf("❌ 风控拒绝开仓: 当前持仓数=%d, 今日开仓次数=%d, 基础资金亏损=%.2f%%",
				managementData.CurrentPositionCount,
				managementData.TodayOpenCount,
				managementData.BaseCapitalLossPct)
		}

		// 6. 计算开仓参数（基于15M SuperTrend止损）
		isBTCETH := decision.Symbol == "BTCUSDT" || decision.Symbol == "ETHUSDT"
		openParams, err := positionMgr.CalculateOpenPosition(
			marketData.CurrentPrice,
			decision.StopLoss,
			decision.Symbol,
			isBTCETH,
			managementData,
		)
		if err != nil {
			return fmt.Errorf("计算开仓参数失败: %w", err)
		}

		// 7. 覆盖AI的杠杆和仓位大小（系统计算优先）
		decision.Leverage = openParams.ActualLeverage
		decision.PositionSizeUSD = openParams.PositionSizeUSD

		log.Printf("  🎯 [SuperTrend+FRVP] 止损波幅=%.2f%%(含0.08%%手续费), 理论杠杆=%dx, 实际杠杆=%dx, 仓位=$%.2f, 风险=%.2f%%",
			openParams.StopLossDistance,
			openParams.TheoreticalLeverage,
			openParams.ActualLeverage,
			openParams.PositionSizeUSD,
			openParams.ActualRisk)

		// 8. 增加今日开仓次数
		if err := positionMgr.IncrementOpenCount(); err != nil {
			log.Printf("  ⚠️ 更新开仓次数失败: %v", err)
		}
	}
	// ========== SuperTrend+FRVP 仓位管理系统集成结束 ==========

	// 计算数量
	quantity := decision.PositionSizeUSD / marketData.CurrentPrice
	actionRecord.Quantity = quantity
	actionRecord.Price = marketData.CurrentPrice
	// ✅ 记录杠杆（用于历史成交记录匹配，SuperTrend+FRVP策略中系统计算的杠杆）
	actionRecord.Leverage = decision.Leverage

	// ⚠️ 保证金验证：防止保证金不足错误（code=-2019）
	requiredMargin := decision.PositionSizeUSD / float64(decision.Leverage)

	balance, err := at.trader.GetBalance()
	if err != nil {
		return fmt.Errorf("获取账户余额失败: %w", err)
	}
	availableBalance := 0.0
	if avail, ok := balance["availableBalance"].(float64); ok {
		availableBalance = avail
	}

	// 手续费估算（Taker费率 0.04%）
	estimatedFee := decision.PositionSizeUSD * 0.0004
	totalRequired := requiredMargin + estimatedFee

	if totalRequired > availableBalance {
		return fmt.Errorf("❌ 保证金不足: 需要 %.2f USDT（保证金 %.2f + 手续费 %.2f），可用 %.2f USDT",
			totalRequired, requiredMargin, estimatedFee, availableBalance)
	}

	// 设置仓位模式
	if err := at.trader.SetMarginMode(decision.Symbol, at.config.IsCrossMargin); err != nil {
		log.Printf("  ⚠️ 设置仓位模式失败: %v", err)
		// 继续执行，不影响交易
	}

	// 开仓
	order, err := at.trader.OpenLong(decision.Symbol, quantity, decision.Leverage)
	if err != nil {
		return err
	}

	// 记录订单ID
	if orderID, ok := order["orderId"].(int64); ok {
		actionRecord.OrderID = orderID
	}

	log.Printf("  ✓ 开仓成功，订单ID: %v, 数量: %.4f", order["orderId"], quantity)

	// 记录开仓时间
	posKey := decision.Symbol + "_long"
	at.positionFirstSeenTime[posKey] = time.Now().UnixMilli()

	// 设置止损
	if err := at.trader.SetStopLoss(decision.Symbol, "LONG", quantity, decision.StopLoss); err != nil {
		log.Printf("  ⚠ 设置止损失败: %v", err)
	}

	// SuperTrend+FRVP 策略：趋势跟踪，不设止盈，让利润奔跑
	if at.systemPromptTemplate != "supertrend_frvp" && decision.TakeProfit > 0 {
		if err := at.trader.SetTakeProfit(decision.Symbol, "LONG", quantity, decision.TakeProfit); err != nil {
			log.Printf("  ⚠ 设置止盈失败: %v", err)
		}
	} else if at.systemPromptTemplate == "supertrend_frvp" {
		log.Printf("  ℹ️ SuperTrend+FRVP策略: 趋势跟踪模式，不设止盈，让利润奔跑")
	}

	return nil
}

// executeOpenShortWithRecord 执行开空仓并记录详细信息
func (at *AutoTrader) executeOpenShortWithRecord(decision *decision.Decision, actionRecord *logger.DecisionAction) error {
	log.Printf("  📉 开空仓: %s", decision.Symbol)

	// ⚠️ 关键：检查是否已有同币种同方向持仓，如果有则拒绝开仓（防止仓位叠加超限）
	positions, err := at.trader.GetPositions()
	if err == nil {
		for _, pos := range positions {
			if pos["symbol"] == decision.Symbol && pos["side"] == "short" {
				return fmt.Errorf("❌ %s 已有空仓，拒绝开仓以防止仓位叠加超限。如需换仓，请先给出 close_short 决策", decision.Symbol)
			}
		}
	}

	// 获取当前价格
	marketData, err := market.Get(decision.Symbol)
	if err != nil {
		return err
	}

	// ========== SuperTrend+FRVP 仓位管理系统集成 ==========
	if at.systemPromptTemplate == "supertrend_frvp" && at.database != nil && at.userID != "" {
		// 1. 如果AI没有提供止损价格，自动从15M SuperTrend获取
		if decision.StopLoss <= 0 {
			mtfData, err := market.GetMultiTimeframeData(decision.Symbol)
			if err != nil {
				return fmt.Errorf("❌ 获取SuperTrend数据失败: %w", err)
			}
			if mtfData.Timeframe15M == nil || mtfData.Timeframe15M.Supertrend == nil {
				return fmt.Errorf("❌ 15M SuperTrend数据不可用")
			}
			decision.StopLoss = mtfData.Timeframe15M.Supertrend.Value
			log.Printf("  ℹ️  [SuperTrend+FRVP] 系统自动设置止损价格: %.4f (15M SuperTrend)", decision.StopLoss)
		}

		// 2. 初始化仓位管理器
		positionMgr := NewPositionManager(at.database.(*config.Database), at.id, at.userID)

		// 3. 获取账户总权益
		balance, err := at.trader.GetBalance()
		if err != nil {
			return fmt.Errorf("获取账户余额失败: %w", err)
		}
		totalEquity := 0.0
		if equity, ok := balance["totalWalletBalance"].(float64); ok {
			totalEquity = equity
		}
		if unrealized, ok := balance["totalUnrealizedProfit"].(float64); ok {
			totalEquity += unrealized
		}

		// 4. 获取仓位管理数据
		managementData, err := positionMgr.GetManagementData(totalEquity, len(positions))
		if err != nil {
			return fmt.Errorf("获取仓位管理数据失败: %w", err)
		}

		// 5. 风控验证
		if !managementData.CanOpenPosition {
			return fmt.Errorf("❌ 风控拒绝开仓: 当前持仓数=%d, 今日开仓次数=%d, 基础资金亏损=%.2f%%",
				managementData.CurrentPositionCount,
				managementData.TodayOpenCount,
				managementData.BaseCapitalLossPct)
		}

		// 6. 计算开仓参数（基于15M SuperTrend止损）
		isBTCETH := decision.Symbol == "BTCUSDT" || decision.Symbol == "ETHUSDT"
		openParams, err := positionMgr.CalculateOpenPosition(
			marketData.CurrentPrice,
			decision.StopLoss,
			decision.Symbol,
			isBTCETH,
			managementData,
		)
		if err != nil {
			return fmt.Errorf("计算开仓参数失败: %w", err)
		}

		// 7. 覆盖AI的杠杆和仓位大小（系统计算优先）
		decision.Leverage = openParams.ActualLeverage
		decision.PositionSizeUSD = openParams.PositionSizeUSD

		log.Printf("  🎯 [SuperTrend+FRVP] 止损波幅=%.2f%%(含0.08%%手续费), 理论杠杆=%dx, 实际杠杆=%dx, 仓位=$%.2f, 风险=%.2f%%",
			openParams.StopLossDistance,
			openParams.TheoreticalLeverage,
			openParams.ActualLeverage,
			openParams.PositionSizeUSD,
			openParams.ActualRisk)

		// 8. 增加今日开仓次数
		if err := positionMgr.IncrementOpenCount(); err != nil {
			log.Printf("  ⚠️ 更新开仓次数失败: %v", err)
		}
	}
	// ========== SuperTrend+FRVP 仓位管理系统集成结束 ==========

	// 计算数量
	quantity := decision.PositionSizeUSD / marketData.CurrentPrice
	actionRecord.Quantity = quantity
	actionRecord.Price = marketData.CurrentPrice
	// ✅ 记录杠杆（用于历史成交记录匹配，SuperTrend+FRVP策略中系统计算的杠杆）
	actionRecord.Leverage = decision.Leverage

	// ⚠️ 保证金验证：防止保证金不足错误（code=-2019）
	requiredMargin := decision.PositionSizeUSD / float64(decision.Leverage)

	balance, err := at.trader.GetBalance()
	if err != nil {
		return fmt.Errorf("获取账户余额失败: %w", err)
	}
	availableBalance := 0.0
	if avail, ok := balance["availableBalance"].(float64); ok {
		availableBalance = avail
	}

	// 手续费估算（Taker费率 0.04%）
	estimatedFee := decision.PositionSizeUSD * 0.0004
	totalRequired := requiredMargin + estimatedFee

	if totalRequired > availableBalance {
		return fmt.Errorf("❌ 保证金不足: 需要 %.2f USDT（保证金 %.2f + 手续费 %.2f），可用 %.2f USDT",
			totalRequired, requiredMargin, estimatedFee, availableBalance)
	}

	// 设置仓位模式
	if err := at.trader.SetMarginMode(decision.Symbol, at.config.IsCrossMargin); err != nil {
		log.Printf("  ⚠️ 设置仓位模式失败: %v", err)
		// 继续执行，不影响交易
	}

	// 开仓
	order, err := at.trader.OpenShort(decision.Symbol, quantity, decision.Leverage)
	if err != nil {
		return err
	}

	// 记录订单ID
	if orderID, ok := order["orderId"].(int64); ok {
		actionRecord.OrderID = orderID
	}

	log.Printf("  ✓ 开仓成功，订单ID: %v, 数量: %.4f", order["orderId"], quantity)

	// 记录开仓时间
	posKey := decision.Symbol + "_short"
	at.positionFirstSeenTime[posKey] = time.Now().UnixMilli()

	// 设置止损
	if err := at.trader.SetStopLoss(decision.Symbol, "SHORT", quantity, decision.StopLoss); err != nil {
		log.Printf("  ⚠ 设置止损失败: %v", err)
	}

	// SuperTrend+FRVP 策略：趋势跟踪，不设止盈，让利润奔跑
	if at.systemPromptTemplate != "supertrend_frvp" && decision.TakeProfit > 0 {
		if err := at.trader.SetTakeProfit(decision.Symbol, "SHORT", quantity, decision.TakeProfit); err != nil {
			log.Printf("  ⚠ 设置止盈失败: %v", err)
		}
	} else if at.systemPromptTemplate == "supertrend_frvp" {
		log.Printf("  ℹ️ SuperTrend+FRVP策略: 趋势跟踪模式，不设止盈，让利润奔跑")
	}

	return nil
}

// executeCloseLongWithRecord 执行平多仓并记录详细信息
func (at *AutoTrader) executeCloseLongWithRecord(decision *decision.Decision, actionRecord *logger.DecisionAction) error {
	log.Printf("  🔄 平多仓: %s", decision.Symbol)

	// 获取当前价格
	marketData, err := market.Get(decision.Symbol)
	if err != nil {
		return err
	}
	actionRecord.Price = marketData.CurrentPrice

	// 平仓前获取持仓信息（用于计算盈亏）
	var entryPrice, positionAmt, leverage float64
	positions, posErr := at.trader.GetPositions()
	if posErr == nil {
		for _, pos := range positions {
			symbol, _ := pos["symbol"].(string)
			posAmt, _ := pos["positionAmt"].(float64)
			if symbol == decision.Symbol && posAmt > 0 {
				entryPrice, _ = pos["entryPrice"].(float64)
				positionAmt = posAmt
				leverage, _ = pos["leverage"].(float64)
				break
			}
		}
	}

	// 平仓
	order, err := at.trader.CloseLong(decision.Symbol, 0) // 0 = 全部平仓
	if err != nil {
		return err
	}

	// 记录订单ID
	if orderID, ok := order["orderId"].(int64); ok {
		actionRecord.OrderID = orderID
	}

	// ✅ 记录平仓数量和杠杆（用于历史成交记录匹配）
	actionRecord.Quantity = positionAmt
	actionRecord.Leverage = int(leverage)

	// 计算并记录盈亏到数据库
	if at.database != nil && at.userID != "" && entryPrice > 0 && positionAmt > 0 {
		closePrice := marketData.CurrentPrice
		// 做多盈亏 = (平仓价 - 入场价) * 数量
		pnl := (closePrice - entryPrice) * positionAmt
		today := time.Now().UTC().Format("2006-01-02")

		if db, ok := at.database.(*config.Database); ok {
			if addErr := db.AddDailyPnL(at.id, at.userID, today, pnl); addErr != nil {
				log.Printf("  ⚠️ 记录盈亏失败: %v", addErr)
			} else {
				pnlPct := ((closePrice - entryPrice) / entryPrice) * leverage * 100
				log.Printf("  💰 平仓盈亏: %.4f USDT (%.2f%%)", pnl, pnlPct)
			}
		}
	}

	log.Printf("  ✓ 平仓成功")
	return nil
}

// executeCloseShortWithRecord 执行平空仓并记录详细信息
func (at *AutoTrader) executeCloseShortWithRecord(decision *decision.Decision, actionRecord *logger.DecisionAction) error {
	log.Printf("  🔄 平空仓: %s", decision.Symbol)

	// 获取当前价格
	marketData, err := market.Get(decision.Symbol)
	if err != nil {
		return err
	}
	actionRecord.Price = marketData.CurrentPrice

	// 平仓前获取持仓信息（用于计算盈亏）
	var entryPrice, positionAmt, leverage float64
	positions, posErr := at.trader.GetPositions()
	if posErr == nil {
		for _, pos := range positions {
			symbol, _ := pos["symbol"].(string)
			posAmt, _ := pos["positionAmt"].(float64)
			if symbol == decision.Symbol && posAmt < 0 { // 空仓数量为负
				entryPrice, _ = pos["entryPrice"].(float64)
				positionAmt = -posAmt // 转为正数
				leverage, _ = pos["leverage"].(float64)
				break
			}
		}
	}

	// 平仓
	order, err := at.trader.CloseShort(decision.Symbol, 0) // 0 = 全部平仓
	if err != nil {
		return err
	}

	// 记录订单ID
	if orderID, ok := order["orderId"].(int64); ok {
		actionRecord.OrderID = orderID
	}

	// ✅ 记录平仓数量和杠杆（用于历史成交记录匹配）
	actionRecord.Quantity = positionAmt
	actionRecord.Leverage = int(leverage)

	// 计算并记录盈亏到数据库
	if at.database != nil && at.userID != "" && entryPrice > 0 && positionAmt > 0 {
		closePrice := marketData.CurrentPrice
		// 做空盈亏 = (入场价 - 平仓价) * 数量
		pnl := (entryPrice - closePrice) * positionAmt
		today := time.Now().UTC().Format("2006-01-02")

		if db, ok := at.database.(*config.Database); ok {
			if addErr := db.AddDailyPnL(at.id, at.userID, today, pnl); addErr != nil {
				log.Printf("  ⚠️ 记录盈亏失败: %v", addErr)
			} else {
				pnlPct := ((entryPrice - closePrice) / entryPrice) * leverage * 100
				log.Printf("  💰 平仓盈亏: %.4f USDT (%.2f%%)", pnl, pnlPct)
			}
		}
	}

	log.Printf("  ✓ 平仓成功")
	return nil
}

// executeUpdateStopLossWithRecord 执行调整止损并记录详细信息
func (at *AutoTrader) executeUpdateStopLossWithRecord(decision *decision.Decision, actionRecord *logger.DecisionAction) error {
	log.Printf("  🎯 调整止损: %s → %.2f", decision.Symbol, decision.NewStopLoss)

	// 获取当前价格
	marketData, err := market.Get(decision.Symbol)
	if err != nil {
		return err
	}
	actionRecord.Price = marketData.CurrentPrice

	// 获取当前持仓
	positions, err := at.trader.GetPositions()
	if err != nil {
		return fmt.Errorf("获取持仓失败: %w", err)
	}

	// 查找目标持仓
	var targetPosition map[string]interface{}
	for _, pos := range positions {
		symbol, _ := pos["symbol"].(string)
		posAmt, _ := pos["positionAmt"].(float64)
		if symbol == decision.Symbol && posAmt != 0 {
			targetPosition = pos
			break
		}
	}

	if targetPosition == nil {
		return fmt.Errorf("持仓不存在: %s", decision.Symbol)
	}

	// 获取持仓方向和数量
	side, _ := targetPosition["side"].(string)
	positionSide := strings.ToUpper(side)
	positionAmt, _ := targetPosition["positionAmt"].(float64)

	// 验证新止损价格合理性
	if positionSide == "LONG" && decision.NewStopLoss >= marketData.CurrentPrice {
		return fmt.Errorf("多单止损必须低于当前价格 (当前: %.2f, 新止损: %.2f)", marketData.CurrentPrice, decision.NewStopLoss)
	}
	if positionSide == "SHORT" && decision.NewStopLoss <= marketData.CurrentPrice {
		return fmt.Errorf("空单止损必须高于当前价格 (当前: %.2f, 新止损: %.2f)", marketData.CurrentPrice, decision.NewStopLoss)
	}

	// ⚠️ 防御性检查：检测是否存在双向持仓（不应该出现，但提供保护）
	var hasOppositePosition bool
	oppositeSide := ""
	for _, pos := range positions {
		symbol, _ := pos["symbol"].(string)
		posSide, _ := pos["side"].(string)
		posAmt, _ := pos["positionAmt"].(float64)
		if symbol == decision.Symbol && posAmt != 0 && strings.ToUpper(posSide) != positionSide {
			hasOppositePosition = true
			oppositeSide = strings.ToUpper(posSide)
			break
		}
	}

	if hasOppositePosition {
		log.Printf("  🚨 警告：检测到 %s 存在双向持仓（%s + %s），这违反了策略规则",
			decision.Symbol, positionSide, oppositeSide)
		log.Printf("  🚨 取消止损单将影响两个方向的订单，请检查是否为用户手动操作导致")
		log.Printf("  🚨 建议：手动平掉其中一个方向的持仓，或检查系统是否有BUG")
	}

	// 取消旧的止损单（只删除止损单，不影响止盈单）
	// 注意：如果存在双向持仓，这会删除两个方向的止损单
	if err := at.trader.CancelStopLossOrders(decision.Symbol); err != nil {
		log.Printf("  ⚠ 取消旧止损单失败: %v", err)
		// 不中断执行，继续设置新止损
	}

	// 调用交易所 API 修改止损
	quantity := math.Abs(positionAmt)
	err = at.trader.SetStopLoss(decision.Symbol, positionSide, quantity, decision.NewStopLoss)
	if err != nil {
		return fmt.Errorf("修改止损失败: %w", err)
	}

	log.Printf("  ✓ 止损已调整: %.2f (当前价格: %.2f)", decision.NewStopLoss, marketData.CurrentPrice)
	return nil
}

// executeUpdateTakeProfitWithRecord 执行调整止盈并记录详细信息
func (at *AutoTrader) executeUpdateTakeProfitWithRecord(decision *decision.Decision, actionRecord *logger.DecisionAction) error {
	log.Printf("  🎯 调整止盈: %s → %.2f", decision.Symbol, decision.NewTakeProfit)

	// 获取当前价格
	marketData, err := market.Get(decision.Symbol)
	if err != nil {
		return err
	}
	actionRecord.Price = marketData.CurrentPrice

	// 获取当前持仓
	positions, err := at.trader.GetPositions()
	if err != nil {
		return fmt.Errorf("获取持仓失败: %w", err)
	}

	// 查找目标持仓
	var targetPosition map[string]interface{}
	for _, pos := range positions {
		symbol, _ := pos["symbol"].(string)
		posAmt, _ := pos["positionAmt"].(float64)
		if symbol == decision.Symbol && posAmt != 0 {
			targetPosition = pos
			break
		}
	}

	if targetPosition == nil {
		return fmt.Errorf("持仓不存在: %s", decision.Symbol)
	}

	// 获取持仓方向和数量
	side, _ := targetPosition["side"].(string)
	positionSide := strings.ToUpper(side)
	positionAmt, _ := targetPosition["positionAmt"].(float64)

	// 验证新止盈价格合理性
	if positionSide == "LONG" && decision.NewTakeProfit <= marketData.CurrentPrice {
		return fmt.Errorf("多单止盈必须高于当前价格 (当前: %.2f, 新止盈: %.2f)", marketData.CurrentPrice, decision.NewTakeProfit)
	}
	if positionSide == "SHORT" && decision.NewTakeProfit >= marketData.CurrentPrice {
		return fmt.Errorf("空单止盈必须低于当前价格 (当前: %.2f, 新止盈: %.2f)", marketData.CurrentPrice, decision.NewTakeProfit)
	}

	// ⚠️ 防御性检查：检测是否存在双向持仓（不应该出现，但提供保护）
	var hasOppositePosition bool
	oppositeSide := ""
	for _, pos := range positions {
		symbol, _ := pos["symbol"].(string)
		posSide, _ := pos["side"].(string)
		posAmt, _ := pos["positionAmt"].(float64)
		if symbol == decision.Symbol && posAmt != 0 && strings.ToUpper(posSide) != positionSide {
			hasOppositePosition = true
			oppositeSide = strings.ToUpper(posSide)
			break
		}
	}

	if hasOppositePosition {
		log.Printf("  🚨 警告：检测到 %s 存在双向持仓（%s + %s），这违反了策略规则",
			decision.Symbol, positionSide, oppositeSide)
		log.Printf("  🚨 取消止盈单将影响两个方向的订单，请检查是否为用户手动操作导致")
		log.Printf("  🚨 建议：手动平掉其中一个方向的持仓，或检查系统是否有BUG")
	}

	// 取消旧的止盈单（只删除止盈单，不影响止损单）
	// 注意：如果存在双向持仓，这会删除两个方向的止盈单
	if err := at.trader.CancelTakeProfitOrders(decision.Symbol); err != nil {
		log.Printf("  ⚠ 取消旧止盈单失败: %v", err)
		// 不中断执行，继续设置新止盈
	}

	// 调用交易所 API 修改止盈
	quantity := math.Abs(positionAmt)
	err = at.trader.SetTakeProfit(decision.Symbol, positionSide, quantity, decision.NewTakeProfit)
	if err != nil {
		return fmt.Errorf("修改止盈失败: %w", err)
	}

	log.Printf("  ✓ 止盈已调整: %.2f (当前价格: %.2f)", decision.NewTakeProfit, marketData.CurrentPrice)
	return nil
}

// executePartialCloseWithRecord 执行部分平仓并记录详细信息
func (at *AutoTrader) executePartialCloseWithRecord(decision *decision.Decision, actionRecord *logger.DecisionAction) error {
	log.Printf("  📊 部分平仓: %s %.1f%%", decision.Symbol, decision.ClosePercentage)

	// 验证百分比范围
	if decision.ClosePercentage <= 0 || decision.ClosePercentage > 100 {
		return fmt.Errorf("平仓百分比必须在 0-100 之间，当前: %.1f", decision.ClosePercentage)
	}

	// 获取当前价格
	marketData, err := market.Get(decision.Symbol)
	if err != nil {
		return err
	}
	actionRecord.Price = marketData.CurrentPrice

	// 获取当前持仓
	positions, err := at.trader.GetPositions()
	if err != nil {
		return fmt.Errorf("获取持仓失败: %w", err)
	}

	// 查找目标持仓
	var targetPosition map[string]interface{}
	for _, pos := range positions {
		symbol, _ := pos["symbol"].(string)
		posAmt, _ := pos["positionAmt"].(float64)
		if symbol == decision.Symbol && posAmt != 0 {
			targetPosition = pos
			break
		}
	}

	if targetPosition == nil {
		return fmt.Errorf("持仓不存在: %s", decision.Symbol)
	}

	// 获取持仓方向和数量
	side, _ := targetPosition["side"].(string)
	positionSide := strings.ToUpper(side)
	positionAmt, _ := targetPosition["positionAmt"].(float64)

	// 计算平仓数量
	totalQuantity := math.Abs(positionAmt)
	closeQuantity := totalQuantity * (decision.ClosePercentage / 100.0)
	actionRecord.Quantity = closeQuantity

	// ✅ Layer 2: 最小仓位检查（防止产生小额剩余）
	markPrice, ok := targetPosition["markPrice"].(float64)
	if !ok || markPrice <= 0 {
		return fmt.Errorf("无法解析当前价格，无法执行最小仓位检查")
	}

	currentPositionValue := totalQuantity * markPrice
	remainingQuantity := totalQuantity - closeQuantity
	remainingValue := remainingQuantity * markPrice

	const MIN_POSITION_VALUE = 10.0 // 最小持仓价值 10 USDT（對齊交易所底线，小仓位建议直接全平）

	if remainingValue > 0 && remainingValue <= MIN_POSITION_VALUE {
		log.Printf("⚠️ 检测到 partial_close 后剩余仓位 %.2f USDT < %.0f USDT",
			remainingValue, MIN_POSITION_VALUE)
		log.Printf("  → 当前仓位价值: %.2f USDT, 平仓 %.1f%%, 剩余: %.2f USDT",
			currentPositionValue, decision.ClosePercentage, remainingValue)
		log.Printf("  → 自动修正为全部平仓，避免产生无法平仓的小额剩余")

		// 🔄 自动修正为全部平仓
		if positionSide == "LONG" {
			decision.Action = "close_long"
			log.Printf("  ✓ 已修正为: close_long")
			return at.executeCloseLongWithRecord(decision, actionRecord)
		} else {
			decision.Action = "close_short"
			log.Printf("  ✓ 已修正为: close_short")
			return at.executeCloseShortWithRecord(decision, actionRecord)
		}
	}

	// 执行平仓
	var order map[string]interface{}
	if positionSide == "LONG" {
		order, err = at.trader.CloseLong(decision.Symbol, closeQuantity)
	} else {
		order, err = at.trader.CloseShort(decision.Symbol, closeQuantity)
	}

	if err != nil {
		return fmt.Errorf("部分平仓失败: %w", err)
	}

	// 记录订单ID
	if orderID, ok := order["orderId"].(int64); ok {
		actionRecord.OrderID = orderID
	}

	log.Printf("  ✓ 部分平仓成功: 平仓 %.4f (%.1f%%), 剩余 %.4f",
		closeQuantity, decision.ClosePercentage, remainingQuantity)

	// ✅ Step 4: 恢复止盈止损（防止剩余仓位裸奔）
	// 重要：币安等交易所在部分平仓后会自动取消原有的 TP/SL 订单（因为数量不匹配）
	// 如果 AI 提供了新的止损止盈价格，则为剩余仓位重新设置保护
	if decision.NewStopLoss > 0 {
		log.Printf("  → 为剩余仓位 %.4f 恢复止损单: %.2f", remainingQuantity, decision.NewStopLoss)
		err = at.trader.SetStopLoss(decision.Symbol, positionSide, remainingQuantity, decision.NewStopLoss)
		if err != nil {
			log.Printf("  ⚠️ 恢复止损失败: %v（不影响平仓结果）", err)
		}
	}

	if decision.NewTakeProfit > 0 {
		log.Printf("  → 为剩余仓位 %.4f 恢复止盈单: %.2f", remainingQuantity, decision.NewTakeProfit)
		err = at.trader.SetTakeProfit(decision.Symbol, positionSide, remainingQuantity, decision.NewTakeProfit)
		if err != nil {
			log.Printf("  ⚠️ 恢复止盈失败: %v（不影响平仓结果）", err)
		}
	}

	// 如果 AI 没有提供新的止盈止损，记录警告
	if decision.NewStopLoss <= 0 && decision.NewTakeProfit <= 0 {
		log.Printf("  ⚠️⚠️⚠️ 警告: 部分平仓后AI未提供新的止盈止损价格")
		log.Printf("  → 剩余仓位 %.4f (价值 %.2f USDT) 目前没有止盈止损保护", remainingQuantity, remainingValue)
		log.Printf("  → 建议: 在 partial_close 决策中包含 new_stop_loss 和 new_take_profit 字段")
	}

	return nil
}

// executeAddPositionWithRecord 执行加仓并记录详细信息（SuperTrend+FRVP策略专用）
// 加仓规则：浮盈≥50% + 止损距离≥1% + 累计加仓≤60% + 成本价安全
// 执行：单次加仓=初始仓位×30%
func (at *AutoTrader) executeAddPositionWithRecord(decision *decision.Decision, actionRecord *logger.DecisionAction) error {
	log.Printf("  ➕ 加仓: %s", decision.Symbol)

	// 获取当前持仓
	positions, err := at.trader.GetPositions()
	if err != nil {
		return fmt.Errorf("获取持仓失败: %w", err)
	}

	// 查找目标持仓
	var targetPosition map[string]interface{}
	for _, pos := range positions {
		symbol, _ := pos["symbol"].(string)
		posAmt, _ := pos["positionAmt"].(float64)
		if symbol == decision.Symbol && posAmt != 0 {
			targetPosition = pos
			break
		}
	}

	if targetPosition == nil {
		return fmt.Errorf("❌ 加仓失败: 持仓不存在 %s", decision.Symbol)
	}

	// 获取持仓信息
	side, _ := targetPosition["side"].(string)
	positionSide := strings.ToUpper(side)
	entryPrice, _ := targetPosition["entryPrice"].(float64)
	markPrice, _ := targetPosition["markPrice"].(float64)
	positionAmt, _ := targetPosition["positionAmt"].(float64)
	leverage, _ := targetPosition["leverage"].(float64)
	if leverage == 0 {
		leverage = 10 // 默认杠杆
	}

	totalQuantity := math.Abs(positionAmt)
	marginUsed := (totalQuantity * markPrice) / leverage

	// 计算当前盈亏百分比
	pnlPct := 0.0
	if marginUsed > 0 {
		unrealizedPnl, _ := targetPosition["unRealizedProfit"].(float64)
		pnlPct = (unrealizedPnl / marginUsed) * 100
	}

	// 获取当前止损价（从15M SuperTrend）用于验证加仓条件
	mtfDataForValidation, errMtf := market.GetMultiTimeframeData(decision.Symbol)
	var stopLossDistancePct float64
	if errMtf == nil && mtfDataForValidation != nil && mtfDataForValidation.Timeframe15M != nil && mtfDataForValidation.Timeframe15M.Supertrend != nil {
		stValue := mtfDataForValidation.Timeframe15M.Supertrend.Value
		if markPrice > 0 {
			stopLossDistancePct = math.Abs(markPrice-stValue) / markPrice * 100
		}
	}

	// 验证加仓条件：浮盈≥50% + 止损距离≥1%（与Prompt生成逻辑一致）
	if pnlPct < 50 {
		return fmt.Errorf("❌ 加仓条件不满足: 当前浮盈%.2f%% < 50%%", pnlPct)
	}
	if stopLossDistancePct < 1.0 {
		return fmt.Errorf("❌ 加仓条件不满足: 止损距离%.2f%% < 1%%（价格距ST过近）", stopLossDistancePct)
	}

	log.Printf("  ✓ 加仓条件验证通过: 浮盈%.2f%% ≥ 50%%, 止损距离%.2f%% ≥ 1%%", pnlPct, stopLossDistancePct)

	// 计算加仓数量：初始仓位×30%
	// 注意：这里简化处理，使用当前仓位的30%作为加仓量
	addQuantity := totalQuantity * 0.30
	addPositionValue := addQuantity * markPrice

	// 检查加仓金额是否低于最小要求（10 USDT，与交易所要求一致）
	// 如果低于最小金额，跳过加仓而不是报错
	minNotional := 10.0
	if addPositionValue < minNotional {
		log.Printf("  ⏭️ 跳过加仓: %s 加仓金额 %.2f USDT 低于最小要求 %.2f USDT，仓位过小无需加仓",
			decision.Symbol, addPositionValue, minNotional)
		return nil // 返回nil表示跳过，不是错误
	}

	actionRecord.Quantity = addQuantity
	actionRecord.Price = markPrice

	// 验证保证金
	requiredMargin := addPositionValue / leverage
	balance, err := at.trader.GetBalance()
	if err != nil {
		return fmt.Errorf("获取账户余额失败: %w", err)
	}
	availableBalance := 0.0
	if avail, ok := balance["availableBalance"].(float64); ok {
		availableBalance = avail
	}

	estimatedFee := addPositionValue * 0.0004
	totalRequired := requiredMargin + estimatedFee

	if totalRequired > availableBalance {
		return fmt.Errorf("❌ 加仓保证金不足: 需要 %.2f USDT，可用 %.2f USDT",
			totalRequired, availableBalance)
	}

	// 计算加仓后的加权入场价
	newTotalQuantity := totalQuantity + addQuantity
	newEntryPrice := (totalQuantity*entryPrice + addQuantity*markPrice) / newTotalQuantity

	// 获取当前止损价（从15M SuperTrend）
	mtfData, err := market.GetMultiTimeframeData(decision.Symbol)
	var stopLossPrice float64
	if err == nil && mtfData != nil && mtfData.Timeframe15M != nil && mtfData.Timeframe15M.Supertrend != nil {
		stopLossPrice = mtfData.Timeframe15M.Supertrend.Value
	}

	// 验证成本价安全：加仓后加权入场价与止损价距离≥0.5%
	if stopLossPrice > 0 {
		costToStopDistance := math.Abs(newEntryPrice-stopLossPrice) / newEntryPrice * 100
		if costToStopDistance < 0.5 {
			return fmt.Errorf("❌ 加仓后成本价过近止损: 距离%.2f%% < 0.5%%", costToStopDistance)
		}
	}

	log.Printf("  📊 加仓详情: 当前仓位=%.4f, 加仓=%.4f(30%%), 新入场价=%.4f",
		totalQuantity, addQuantity, newEntryPrice)

	// 执行加仓（同方向开仓）
	var order map[string]interface{}
	if positionSide == "LONG" {
		order, err = at.trader.OpenLong(decision.Symbol, addQuantity, int(leverage))
	} else {
		order, err = at.trader.OpenShort(decision.Symbol, addQuantity, int(leverage))
	}

	if err != nil {
		return fmt.Errorf("加仓执行失败: %w", err)
	}

	// 记录订单ID
	if orderID, ok := order["orderId"].(int64); ok {
		actionRecord.OrderID = orderID
	}

	log.Printf("  ✓ 加仓成功: 加仓 %.4f, 新总仓位 %.4f", addQuantity, newTotalQuantity)

	// 更新止损单（数量变化后需要重新设置）
	// ⚠️ 重要：止损是SuperTrend+FRVP策略的核心风控，必须确保设置成功
	if stopLossPrice > 0 {
		// 先取消旧止损单
		if err := at.trader.CancelStopLossOrders(decision.Symbol); err != nil {
			log.Printf("  ⚠️ 取消旧止损单失败: %v", err)
		}

		// 设置新止损单（带重试机制）
		var stopLossErr error
		for retry := 0; retry < 3; retry++ {
			stopLossErr = at.trader.SetStopLoss(decision.Symbol, positionSide, newTotalQuantity, stopLossPrice)
			if stopLossErr == nil {
				log.Printf("  ✓ 止损单已更新: 数量=%.4f, 止损价=%.4f", newTotalQuantity, stopLossPrice)
				break
			}
			log.Printf("  ⚠️ 设置止损单失败(重试%d/3): %v", retry+1, stopLossErr)
			time.Sleep(500 * time.Millisecond)
		}

		if stopLossErr != nil {
			// 止损单设置失败，记录严重警告（但不回滚加仓，因为已执行）
			log.Printf("  🚨🚨🚨 严重警告: 加仓成功但止损单设置失败！仓位 %s 当前无止损保护！", decision.Symbol)
			log.Printf("  🚨 建议: 手动检查并设置止损单，止损价=%.4f, 数量=%.4f", stopLossPrice, newTotalQuantity)
		}
	}

	return nil
}

// executeReducePositionWithRecord 执行减仓并记录详细信息（SuperTrend+FRVP策略专用）
// 减仓规则：(浮盈≥100%+回落≥15%) 或 (浮盈≥50%+持仓>24H)
// 执行：单次减仓=当前仓位×30%
func (at *AutoTrader) executeReducePositionWithRecord(decision *decision.Decision, actionRecord *logger.DecisionAction) error {
	log.Printf("  ➖ 减仓: %s", decision.Symbol)

	// 获取当前持仓
	positions, err := at.trader.GetPositions()
	if err != nil {
		return fmt.Errorf("获取持仓失败: %w", err)
	}

	// 查找目标持仓
	var targetPosition map[string]interface{}
	for _, pos := range positions {
		symbol, _ := pos["symbol"].(string)
		posAmt, _ := pos["positionAmt"].(float64)
		if symbol == decision.Symbol && posAmt != 0 {
			targetPosition = pos
			break
		}
	}

	if targetPosition == nil {
		return fmt.Errorf("❌ 减仓失败: 持仓不存在 %s", decision.Symbol)
	}

	// 获取持仓信息
	side, _ := targetPosition["side"].(string)
	positionSide := strings.ToUpper(side)
	positionAmt, _ := targetPosition["positionAmt"].(float64)
	markPrice, _ := targetPosition["markPrice"].(float64)
	leverage, _ := targetPosition["leverage"].(float64)
	if leverage == 0 {
		leverage = 10 // 默认杠杆
	}

	totalQuantity := math.Abs(positionAmt)
	marginUsed := (totalQuantity * markPrice) / leverage

	// 计算当前盈亏百分比
	pnlPct := 0.0
	if marginUsed > 0 {
		unrealizedPnl, _ := targetPosition["unRealizedProfit"].(float64)
		pnlPct = (unrealizedPnl / marginUsed) * 100
	}

	// 获取持仓时长（小时）
	posKey := decision.Symbol + "_" + strings.ToLower(side)
	holdingHours := 0
	if firstSeenTime, exists := at.positionFirstSeenTime[posKey]; exists {
		durationMs := time.Now().UnixMilli() - firstSeenTime
		holdingHours = int(durationMs / (1000 * 60 * 60))
	}

	// 获取峰值收益率
	at.peakPnLCacheMutex.RLock()
	peakPnlPct := at.peakPnLCache[posKey]
	at.peakPnLCacheMutex.RUnlock()

	// 验证减仓条件（与Prompt生成逻辑一致）：
	// 组合1: 浮盈≥100% + 从高点回落≥15%
	// 组合2: 浮盈≥50% + 持仓>24H
	reduceCondition1 := pnlPct >= 100 && (peakPnlPct-pnlPct) >= 15
	reduceCondition2 := pnlPct >= 50 && holdingHours > 24
	canReduce := reduceCondition1 || reduceCondition2

	if !canReduce {
		return fmt.Errorf("❌ 减仓条件不满足: 浮盈%.2f%%, 峰值%.2f%%, 回落%.2f%%, 持仓%dH（需满足: [浮盈≥100%%+回落≥15%%] 或 [浮盈≥50%%+持仓>24H]）",
			pnlPct, peakPnlPct, peakPnlPct-pnlPct, holdingHours)
	}

	if reduceCondition1 {
		log.Printf("  ✓ 减仓条件验证通过(组合1): 浮盈%.2f%% ≥ 100%%, 从峰值%.2f%%回落%.2f%% ≥ 15%%",
			pnlPct, peakPnlPct, peakPnlPct-pnlPct)
	} else {
		log.Printf("  ✓ 减仓条件验证通过(组合2): 浮盈%.2f%% ≥ 50%%, 持仓%dH > 24H",
			pnlPct, holdingHours)
	}

	// 计算减仓数量：当前仓位×30%
	reduceQuantity := totalQuantity * 0.30
	remainingQuantity := totalQuantity - reduceQuantity

	actionRecord.Quantity = reduceQuantity
	actionRecord.Price = markPrice

	// 检查剩余仓位价值
	remainingValue := remainingQuantity * markPrice
	const MIN_POSITION_VALUE = 10.0

	if remainingValue > 0 && remainingValue <= MIN_POSITION_VALUE {
		log.Printf("  ⚠️ 减仓后剩余仓位 %.2f USDT < %.0f USDT，自动修正为全部平仓",
			remainingValue, MIN_POSITION_VALUE)

		// 自动修正为全部平仓
		if positionSide == "LONG" {
			decision.Action = "close_long"
			return at.executeCloseLongWithRecord(decision, actionRecord)
		} else {
			decision.Action = "close_short"
			return at.executeCloseShortWithRecord(decision, actionRecord)
		}
	}

	log.Printf("  📊 减仓详情: 当前仓位=%.4f, 减仓=%.4f(30%%), 剩余=%.4f",
		totalQuantity, reduceQuantity, remainingQuantity)

	// 执行减仓（部分平仓）
	var order map[string]interface{}
	if positionSide == "LONG" {
		order, err = at.trader.CloseLong(decision.Symbol, reduceQuantity)
	} else {
		order, err = at.trader.CloseShort(decision.Symbol, reduceQuantity)
	}

	if err != nil {
		return fmt.Errorf("减仓执行失败: %w", err)
	}

	// 记录订单ID
	if orderID, ok := order["orderId"].(int64); ok {
		actionRecord.OrderID = orderID
	}

	log.Printf("  ✓ 减仓成功: 减仓 %.4f (30%%), 剩余 %.4f", reduceQuantity, remainingQuantity)

	// 更新止损单（数量变化后需要重新设置）
	// ⚠️ 重要：止损是SuperTrend+FRVP策略的核心风控，必须确保设置成功
	mtfData, err := market.GetMultiTimeframeData(decision.Symbol)
	if err == nil && mtfData != nil && mtfData.Timeframe15M != nil && mtfData.Timeframe15M.Supertrend != nil {
		stopLossPrice := mtfData.Timeframe15M.Supertrend.Value

		// 先取消旧止损单
		if err := at.trader.CancelStopLossOrders(decision.Symbol); err != nil {
			log.Printf("  ⚠️ 取消旧止损单失败: %v", err)
		}

		// 设置新止损单（带重试机制）
		var stopLossErr error
		for retry := 0; retry < 3; retry++ {
			stopLossErr = at.trader.SetStopLoss(decision.Symbol, positionSide, remainingQuantity, stopLossPrice)
			if stopLossErr == nil {
				log.Printf("  ✓ 止损单已更新: 数量=%.4f, 止损价=%.4f", remainingQuantity, stopLossPrice)
				break
			}
			log.Printf("  ⚠️ 设置止损单失败(重试%d/3): %v", retry+1, stopLossErr)
			time.Sleep(500 * time.Millisecond)
		}

		if stopLossErr != nil {
			// 止损单设置失败，记录严重警告（但不回滚减仓，因为已执行）
			log.Printf("  🚨🚨🚨 严重警告: 减仓成功但止损单设置失败！仓位 %s 当前无止损保护！", decision.Symbol)
			log.Printf("  🚨 建议: 手动检查并设置止损单，止损价=%.4f, 数量=%.4f", stopLossPrice, remainingQuantity)
		}
	}

	return nil
}

// GetID 获取trader ID
func (at *AutoTrader) GetID() string {
	return at.id
}

// GetName 获取trader名称
func (at *AutoTrader) GetName() string {
	return at.name
}

// GetAIModel 获取AI模型
func (at *AutoTrader) GetAIModel() string {
	return at.aiModel
}

// GetExchange 获取交易所
func (at *AutoTrader) GetExchange() string {
	return at.exchange
}

// SetCustomPrompt 设置自定义交易策略prompt
func (at *AutoTrader) SetCustomPrompt(prompt string) {
	at.customPrompt = prompt
}

// SetOverrideBasePrompt 设置是否覆盖基础prompt
func (at *AutoTrader) SetOverrideBasePrompt(override bool) {
	at.overrideBasePrompt = override
}

// SetSystemPromptTemplate 设置系统提示词模板
func (at *AutoTrader) SetSystemPromptTemplate(templateName string) {
	at.systemPromptTemplate = templateName
}

// GetSystemPromptTemplate 获取当前系统提示词模板名称
func (at *AutoTrader) GetSystemPromptTemplate() string {
	return at.systemPromptTemplate
}

// GetDecisionLogger 获取决策日志记录器
func (at *AutoTrader) GetDecisionLogger() logger.IDecisionLogger {
	return at.decisionLogger
}

// GetStatus 获取系统状态（用于API）
func (at *AutoTrader) GetStatus() map[string]interface{} {
	aiProvider := "DeepSeek"
	if at.config.UseQwen {
		aiProvider = "Qwen"
	}

	return map[string]interface{}{
		"trader_id":       at.id,
		"trader_name":     at.name,
		"ai_model":        at.aiModel,
		"exchange":        at.exchange,
		"is_running":      at.isRunning,
		"start_time":      at.startTime.Format(time.RFC3339),
		"runtime_minutes": int(time.Since(at.startTime).Minutes()),
		"call_count":      at.callCount,
		"initial_balance": at.initialBalance,
		"scan_interval":   at.config.ScanInterval.String(),
		"stop_until":      at.stopUntil.Format(time.RFC3339),
		"last_reset_time": at.lastResetTime.Format(time.RFC3339),
		"ai_provider":     aiProvider,
	}
}

// GetAccountInfo 获取账户信息（用于API）
func (at *AutoTrader) GetAccountInfo() (map[string]interface{}, error) {
	balance, err := at.trader.GetBalance()
	if err != nil {
		return nil, fmt.Errorf("获取余额失败: %w", err)
	}

	// 获取账户字段
	totalWalletBalance := 0.0
	totalUnrealizedProfit := 0.0
	availableBalance := 0.0

	if wallet, ok := balance["totalWalletBalance"].(float64); ok {
		totalWalletBalance = wallet
	}
	if unrealized, ok := balance["totalUnrealizedProfit"].(float64); ok {
		totalUnrealizedProfit = unrealized
	}
	if avail, ok := balance["availableBalance"].(float64); ok {
		availableBalance = avail
	}

	// Total Equity = 钱包余额 + 未实现盈亏
	totalEquity := totalWalletBalance + totalUnrealizedProfit

	// 获取持仓计算总保证金
	positions, err := at.trader.GetPositions()
	if err != nil {
		return nil, fmt.Errorf("获取持仓失败: %w", err)
	}

	totalMarginUsed := 0.0
	totalUnrealizedPnLCalculated := 0.0
	for _, pos := range positions {
		markPrice := pos["markPrice"].(float64)
		quantity := pos["positionAmt"].(float64)
		if quantity < 0 {
			quantity = -quantity
		}
		unrealizedPnl := pos["unRealizedProfit"].(float64)
		totalUnrealizedPnLCalculated += unrealizedPnl

		leverage := 10
		if lev, ok := pos["leverage"].(float64); ok {
			leverage = int(lev)
		}
		marginUsed := (quantity * markPrice) / float64(leverage)
		totalMarginUsed += marginUsed
	}

	// 验证未实现盈亏的一致性（API值 vs 从持仓计算）
	diff := math.Abs(totalUnrealizedProfit - totalUnrealizedPnLCalculated)
	if diff > 0.1 { // 允许0.01 USDT的误差
		log.Printf("⚠️ 未实现盈亏不一致: API=%.4f, 计算=%.4f, 差异=%.4f",
			totalUnrealizedProfit, totalUnrealizedPnLCalculated, diff)
	}

	totalPnL := totalEquity - at.initialBalance
	totalPnLPct := 0.0
	if at.initialBalance > 0 {
		totalPnLPct = (totalPnL / at.initialBalance) * 100
	} else {
		log.Printf("⚠️ Initial Balance异常: %.2f，无法计算PNL百分比", at.initialBalance)
	}

	marginUsedPct := 0.0
	if totalEquity > 0 {
		marginUsedPct = (totalMarginUsed / totalEquity) * 100
	}

	return map[string]interface{}{
		// 核心字段
		"total_equity":      totalEquity,           // 账户净值 = wallet + unrealized
		"wallet_balance":    totalWalletBalance,    // 钱包余额（不含未实现盈亏）
		"unrealized_profit": totalUnrealizedProfit, // 未实现盈亏（交易所API官方值）
		"available_balance": availableBalance,      // 可用余额

		// 盈亏统计
		"total_pnl":       totalPnL,          // 总盈亏 = equity - initial
		"total_pnl_pct":   totalPnLPct,       // 总盈亏百分比
		"initial_balance": at.initialBalance, // 初始余额
		"daily_pnl":       at.dailyPnL,       // 日盈亏

		// 持仓信息
		"position_count":  len(positions),  // 持仓数量
		"margin_used":     totalMarginUsed, // 保证金占用
		"margin_used_pct": marginUsedPct,   // 保证金使用率
	}, nil
}

// GetPositions 获取持仓列表（用于API）
func (at *AutoTrader) GetPositions() ([]map[string]interface{}, error) {
	positions, err := at.trader.GetPositions()
	if err != nil {
		return nil, fmt.Errorf("获取持仓失败: %w", err)
	}

	var result []map[string]interface{}
	for _, pos := range positions {
		symbol := pos["symbol"].(string)
		side := pos["side"].(string)
		entryPrice := pos["entryPrice"].(float64)
		markPrice := pos["markPrice"].(float64)
		quantity := pos["positionAmt"].(float64)
		if quantity < 0 {
			quantity = -quantity
		}
		unrealizedPnl := pos["unRealizedProfit"].(float64)
		liquidationPrice := pos["liquidationPrice"].(float64)

		leverage := 10
		if lev, ok := pos["leverage"].(float64); ok {
			leverage = int(lev)
		}

		// 计算占用保证金
		marginUsed := (quantity * markPrice) / float64(leverage)

		// 计算盈亏百分比（基于保证金）
		pnlPct := calculatePnLPercentage(unrealizedPnl, marginUsed)

		result = append(result, map[string]interface{}{
			"symbol":             symbol,
			"side":               side,
			"entry_price":        entryPrice,
			"mark_price":         markPrice,
			"quantity":           quantity,
			"leverage":           leverage,
			"unrealized_pnl":     unrealizedPnl,
			"unrealized_pnl_pct": pnlPct,
			"liquidation_price":  liquidationPrice,
			"margin_used":        marginUsed,
		})
	}

	return result, nil
}

// calculatePnLPercentage 计算盈亏百分比（基于保证金，自动考虑杠杆）
// 收益率 = 未实现盈亏 / 保证金 × 100%
func calculatePnLPercentage(unrealizedPnl, marginUsed float64) float64 {
	if marginUsed > 0 {
		return (unrealizedPnl / marginUsed) * 100
	}
	return 0.0
}

// sortDecisionsByPriority 对决策排序：先平仓，再开仓，最后hold/wait
// 这样可以避免换仓时仓位叠加超限
func sortDecisionsByPriority(decisions []decision.Decision) []decision.Decision {
	if len(decisions) <= 1 {
		return decisions
	}

	// 定义优先级
	getActionPriority := func(action string) int {
		switch action {
		case "close_long", "close_short", "partial_close", "reduce_position":
			return 1 // 最高优先级：先平仓/减仓（包括部分平仓）
		case "update_stop_loss", "update_take_profit":
			return 2 // 调整持仓止盈止损
		case "add_position":
			return 3 // 加仓（在调整止损后，开仓前）
		case "open_long", "open_short":
			return 4 // 次优先级：后开仓
		case "hold", "wait":
			return 5 // 最低优先级：观望
		default:
			return 999 // 未知动作放最后
		}
	}

	// 复制决策列表
	sorted := make([]decision.Decision, len(decisions))
	copy(sorted, decisions)

	// 按优先级排序
	for i := 0; i < len(sorted)-1; i++ {
		for j := i + 1; j < len(sorted); j++ {
			if getActionPriority(sorted[i].Action) > getActionPriority(sorted[j].Action) {
				sorted[i], sorted[j] = sorted[j], sorted[i]
			}
		}
	}

	return sorted
}

// getCandidateCoins 获取交易员的候选币种列表
func (at *AutoTrader) getCandidateCoins() ([]decision.CandidateCoin, error) {
	if len(at.tradingCoins) == 0 {
		// 使用数据库配置的默认币种列表
		var candidateCoins []decision.CandidateCoin

		if len(at.defaultCoins) > 0 {
			// 使用数据库中配置的默认币种
			for _, coin := range at.defaultCoins {
				symbol := normalizeSymbol(coin)
				candidateCoins = append(candidateCoins, decision.CandidateCoin{
					Symbol:  symbol,
					Sources: []string{"default"}, // 标记为数据库默认币种
				})
			}
			log.Printf("📋 [%s] 使用数据库默认币种: %d个币种 %v",
				at.name, len(candidateCoins), at.defaultCoins)
			return candidateCoins, nil
		} else {
			// 如果数据库中没有配置默认币种，则使用AI500+OI Top作为fallback
			const ai500Limit = 20 // AI500取前20个评分最高的币种

			mergedPool, err := pool.GetMergedCoinPool(ai500Limit)
			if err != nil {
				return nil, fmt.Errorf("获取合并币种池失败: %w", err)
			}

			// 构建候选币种列表（包含来源信息）
			for _, symbol := range mergedPool.AllSymbols {
				sources := mergedPool.SymbolSources[symbol]
				candidateCoins = append(candidateCoins, decision.CandidateCoin{
					Symbol:  symbol,
					Sources: sources, // "ai500" 和/或 "oi_top"
				})
			}

			log.Printf("📋 [%s] 数据库无默认币种配置，使用AI500+OI Top: AI500前%d + OI_Top20 = 总计%d个候选币种",
				at.name, ai500Limit, len(candidateCoins))
			return candidateCoins, nil
		}
	} else {
		// 使用自定义币种列表
		var candidateCoins []decision.CandidateCoin
		for _, coin := range at.tradingCoins {
			// 确保币种格式正确（转为大写USDT交易对）
			symbol := normalizeSymbol(coin)
			candidateCoins = append(candidateCoins, decision.CandidateCoin{
				Symbol:  symbol,
				Sources: []string{"custom"}, // 标记为自定义来源
			})
		}

		log.Printf("📋 [%s] 使用自定义币种: %d个币种 %v",
			at.name, len(candidateCoins), at.tradingCoins)
		return candidateCoins, nil
	}
}

// normalizeSymbol 标准化币种符号（确保以USDT结尾）
func normalizeSymbol(symbol string) string {
	// 转为大写
	symbol = strings.ToUpper(strings.TrimSpace(symbol))

	// 确保以USDT结尾
	if !strings.HasSuffix(symbol, "USDT") {
		symbol = symbol + "USDT"
	}

	return symbol
}

// 启动回撤监控
func (at *AutoTrader) startDrawdownMonitor() {
	at.monitorWg.Add(1)
	go func() {
		defer at.monitorWg.Done()

		ticker := time.NewTicker(1 * time.Minute) // 每分钟检查一次
		defer ticker.Stop()

		log.Println("📊 启动持仓回撤监控（每分钟检查一次）")

		for {
			select {
			case <-ticker.C:
				at.checkPositionDrawdown()
			case <-at.stopMonitorCh:
				log.Println("⏹ 停止持仓回撤监控")
				return
			}
		}
	}()
}

// 检查持仓回撤情况
func (at *AutoTrader) checkPositionDrawdown() {
	// 获取当前持仓
	positions, err := at.trader.GetPositions()
	if err != nil {
		log.Printf("❌ 回撤监控：获取持仓失败: %v", err)
		return
	}

	for _, pos := range positions {
		symbol := pos["symbol"].(string)
		side := pos["side"].(string)
		entryPrice := pos["entryPrice"].(float64)
		markPrice := pos["markPrice"].(float64)
		quantity := pos["positionAmt"].(float64)
		if quantity < 0 {
			quantity = -quantity // 空仓数量为负，转为正数
		}

		// 计算当前盈亏百分比
		leverage := 10 // 默认值
		if lev, ok := pos["leverage"].(float64); ok {
			leverage = int(lev)
		}

		var currentPnLPct float64
		if side == "long" {
			currentPnLPct = ((markPrice - entryPrice) / entryPrice) * float64(leverage) * 100
		} else {
			currentPnLPct = ((entryPrice - markPrice) / entryPrice) * float64(leverage) * 100
		}

		// 构造持仓唯一标识（区分多空）
		posKey := symbol + "_" + side

		// 获取该持仓的历史最高收益
		at.peakPnLCacheMutex.RLock()
		peakPnLPct, exists := at.peakPnLCache[posKey]
		at.peakPnLCacheMutex.RUnlock()

		if !exists {
			// 如果没有历史最高记录，使用当前盈亏作为初始值
			peakPnLPct = currentPnLPct
			at.UpdatePeakPnL(symbol, side, currentPnLPct)
		} else {
			// 更新峰值缓存
			at.UpdatePeakPnL(symbol, side, currentPnLPct)
		}

		// 计算回撤（从最高点下跌的幅度）
		var drawdownPct float64
		if peakPnLPct > 0 && currentPnLPct < peakPnLPct {
			drawdownPct = ((peakPnLPct - currentPnLPct) / peakPnLPct) * 100
		}

		// 检查平仓条件：收益大于5%且回撤超过40%
		if currentPnLPct > 5.0 && drawdownPct >= 40.0 {
			log.Printf("🚨 触发回撤平仓条件: %s %s | 当前收益: %.2f%% | 最高收益: %.2f%% | 回撤: %.2f%%",
				symbol, side, currentPnLPct, peakPnLPct, drawdownPct)

			// 执行平仓
			if err := at.emergencyClosePosition(symbol, side); err != nil {
				log.Printf("❌ 回撤平仓失败 (%s %s): %v", symbol, side, err)
			} else {
				log.Printf("✅ 回撤平仓成功: %s %s", symbol, side)
				// 平仓后清理该持仓的缓存
				at.ClearPeakPnLCache(symbol, side)
			}
		} else if currentPnLPct > 5.0 {
			// 记录接近平仓条件的情况（用于调试）
			log.Printf("📊 回撤监控: %s %s | 收益: %.2f%% | 最高: %.2f%% | 回撤: %.2f%%",
				symbol, side, currentPnLPct, peakPnLPct, drawdownPct)
		}
	}
}

// 紧急平仓函数
func (at *AutoTrader) emergencyClosePosition(symbol, side string) error {
	// 平仓前获取持仓信息（用于计算盈亏）
	var entryPrice, positionAmt, leverage float64
	positions, posErr := at.trader.GetPositions()
	if posErr == nil {
		for _, pos := range positions {
			posSymbol, _ := pos["symbol"].(string)
			posAmt, _ := pos["positionAmt"].(float64)
			if posSymbol == symbol {
				if side == "long" && posAmt > 0 {
					entryPrice, _ = pos["entryPrice"].(float64)
					positionAmt = posAmt
					leverage, _ = pos["leverage"].(float64)
					break
				} else if side == "short" && posAmt < 0 {
					entryPrice, _ = pos["entryPrice"].(float64)
					positionAmt = -posAmt // 转为正数
					leverage, _ = pos["leverage"].(float64)
					break
				}
			}
		}
	}

	// 获取当前市场价格
	marketData, _ := market.Get(symbol)
	var closePrice float64
	if marketData != nil {
		closePrice = marketData.CurrentPrice
	}

	switch side {
	case "long":
		order, err := at.trader.CloseLong(symbol, 0) // 0 = 全部平仓
		if err != nil {
			return err
		}
		log.Printf("✅ 紧急平多仓成功，订单ID: %v", order["orderId"])

		// 记录盈亏到数据库
		if at.database != nil && at.userID != "" && entryPrice > 0 && positionAmt > 0 && closePrice > 0 {
			// 做多盈亏 = (平仓价 - 入场价) * 数量
			pnl := (closePrice - entryPrice) * positionAmt
			today := time.Now().UTC().Format("2006-01-02")

			if db, ok := at.database.(*config.Database); ok {
				if addErr := db.AddDailyPnL(at.id, at.userID, today, pnl); addErr != nil {
					log.Printf("  ⚠️ 紧急平仓记录盈亏失败: %v", addErr)
				} else {
					pnlPct := ((closePrice - entryPrice) / entryPrice) * leverage * 100
					log.Printf("  💰 紧急平仓盈亏: %.4f USDT (%.2f%%)", pnl, pnlPct)
				}
			}
		}

	case "short":
		order, err := at.trader.CloseShort(symbol, 0) // 0 = 全部平仓
		if err != nil {
			return err
		}
		log.Printf("✅ 紧急平空仓成功，订单ID: %v", order["orderId"])

		// 记录盈亏到数据库
		if at.database != nil && at.userID != "" && entryPrice > 0 && positionAmt > 0 && closePrice > 0 {
			// 做空盈亏 = (入场价 - 平仓价) * 数量
			pnl := (entryPrice - closePrice) * positionAmt
			today := time.Now().UTC().Format("2006-01-02")

			if db, ok := at.database.(*config.Database); ok {
				if addErr := db.AddDailyPnL(at.id, at.userID, today, pnl); addErr != nil {
					log.Printf("  ⚠️ 紧急平仓记录盈亏失败: %v", addErr)
				} else {
					pnlPct := ((entryPrice - closePrice) / entryPrice) * leverage * 100
					log.Printf("  💰 紧急平仓盈亏: %.4f USDT (%.2f%%)", pnl, pnlPct)
				}
			}
		}

	default:
		return fmt.Errorf("未知的持仓方向: %s", side)
	}

	return nil
}

// GetPeakPnLCache 获取最高收益缓存
func (at *AutoTrader) GetPeakPnLCache() map[string]float64 {
	at.peakPnLCacheMutex.RLock()
	defer at.peakPnLCacheMutex.RUnlock()

	// 返回缓存的副本
	cache := make(map[string]float64)
	for k, v := range at.peakPnLCache {
		cache[k] = v
	}
	return cache
}

// UpdatePeakPnL 更新最高收益缓存
func (at *AutoTrader) UpdatePeakPnL(symbol, side string, currentPnLPct float64) {
	at.peakPnLCacheMutex.Lock()
	defer at.peakPnLCacheMutex.Unlock()

	posKey := symbol + "_" + side
	if peak, exists := at.peakPnLCache[posKey]; exists {
		// 更新峰值（如果是多头，取较大值；如果是空头，currentPnLPct为负，也要比较）
		if currentPnLPct > peak {
			at.peakPnLCache[posKey] = currentPnLPct
		}
	} else {
		// 首次记录
		at.peakPnLCache[posKey] = currentPnLPct
	}
}

// ClearPeakPnLCache 清除指定持仓的峰值缓存
func (at *AutoTrader) ClearPeakPnLCache(symbol, side string) {
	at.peakPnLCacheMutex.Lock()
	defer at.peakPnLCacheMutex.Unlock()

	posKey := symbol + "_" + side
	delete(at.peakPnLCache, posKey)
}

// startSuperTrendStopLossMonitor 启动15M SuperTrend动态止损监控
// 仅对 supertrend_frvp 策略生效
func (at *AutoTrader) startSuperTrendStopLossMonitor() {
	if at.systemPromptTemplate != "supertrend_frvp" {
		return // 非SuperTrend策略不启用
	}

	at.monitorWg.Add(1)
	go func() {
		defer at.monitorWg.Done()

		ticker := time.NewTicker(1 * time.Minute) // 每分钟检查一次
		defer ticker.Stop()

		log.Println("📊 [SuperTrend] 启动15M SuperTrend动态止损监控（每分钟检查）")

		for {
			select {
			case <-ticker.C:
				at.checkAndUpdateSuperTrendStopLoss()
			case <-at.stopMonitorCh:
				log.Println("⏹ [SuperTrend] 停止动态止损监控")
				return
			}
		}
	}()
}

// checkAndUpdateSuperTrendStopLoss 检查并更新止损到15M SuperTrend
func (at *AutoTrader) checkAndUpdateSuperTrendStopLoss() {
	// 获取当前持仓
	positions, err := at.trader.GetPositions()
	if err != nil {
		log.Printf("❌ [SuperTrend止损] 获取持仓失败: %v", err)
		return
	}

	// ========== 止损触发检测：对比上次持仓快照 ==========
	at.detectStopLossTriggered(positions)

	// ========== 更新持仓快照（用于下次检测） ==========
	at.updatePositionSnapshot(positions)

	for _, pos := range positions {
		symbol := pos["symbol"].(string)
		side := pos["side"].(string)
		markPrice := pos["markPrice"].(float64)
		quantity := pos["positionAmt"].(float64)
		if quantity < 0 {
			quantity = -quantity
		}
		if quantity == 0 {
			continue // 跳过空仓位
		}

		// 获取15M SuperTrend值
		mtfData, err := market.GetMultiTimeframeData(symbol)
		if err != nil {
			continue // 获取失败跳过
		}
		if mtfData.Timeframe15M == nil || mtfData.Timeframe15M.Supertrend == nil {
			continue // 数据不可用跳过
		}

		newStopLoss := mtfData.Timeframe15M.Supertrend.Value
		stDirection := mtfData.Timeframe15M.Supertrend.Direction

		// 验证止损方向是否正确
		positionSide := strings.ToUpper(side)
		if positionSide == "LONG" {
			// 多单：止损必须低于当前价，且ST方向应为上涨(1)
			if newStopLoss >= markPrice {
				continue // 止损价高于当前价，不更新
			}
			if stDirection != 1 {
				// ST方向转空，可能需要平仓而非移动止损
				log.Printf("⚠️ [SuperTrend止损] %s 多单ST方向转空，建议关注", symbol)
				continue
			}
		} else {
			// 空单：止损必须高于当前价，且ST方向应为下跌(-1)
			if newStopLoss <= markPrice {
				continue // 止损价低于当前价，不更新
			}
			if stDirection != -1 {
				log.Printf("⚠️ [SuperTrend止损] %s 空单ST方向转多，建议关注", symbol)
				continue
			}
		}

		// 获取当前止损单价格（如果有）
		currentStopLoss := at.getCurrentStopLossPrice(symbol, positionSide)

		// 判断是否需要移动止损（只能向有利方向移动）
		shouldUpdate := false
		if positionSide == "LONG" {
			// 多单：新止损必须高于旧止损（向上移动）
			if currentStopLoss == 0 || newStopLoss > currentStopLoss {
				shouldUpdate = true
			}
		} else {
			// 空单：新止损必须低于旧止损（向下移动）
			if currentStopLoss == 0 || newStopLoss < currentStopLoss {
				shouldUpdate = true
			}
		}

		if !shouldUpdate {
			continue // 不需要更新
		}

		// 计算止损距离百分比
		stopLossDistPct := math.Abs(markPrice-newStopLoss) / markPrice * 100

		// 最小止损距离检查（防止止损过近被扫）
		if stopLossDistPct < 0.3 {
			log.Printf("⚠️ [SuperTrend止损] %s 止损距离%.2f%%过近(<0.3%%)，暂不更新", symbol, stopLossDistPct)
			continue
		}

		log.Printf("🎯 [SuperTrend止损] %s %s | 当前价=%.4f | 旧止损=%.4f | 新止损=%.4f (距离%.2f%%)",
			symbol, side, markPrice, currentStopLoss, newStopLoss, stopLossDistPct)

		// 取消旧止损单
		if err := at.trader.CancelStopLossOrders(symbol); err != nil {
			log.Printf("  ⚠️ 取消旧止损单失败: %v", err)
		}

		// 设置新止损单
		if err := at.trader.SetStopLoss(symbol, positionSide, quantity, newStopLoss); err != nil {
			log.Printf("  ❌ 设置新止损失败: %v", err)
		} else {
			log.Printf("  ✅ 止损已移动到 %.4f", newStopLoss)
		}
	}
}

// getCurrentStopLossPrice 获取当前止损单价格
func (at *AutoTrader) getCurrentStopLossPrice(symbol, positionSide string) float64 {
	// 尝试从交易所获取当前止损单
	orders, err := at.trader.GetOpenOrders(symbol)
	if err != nil {
		return 0
	}

	for _, order := range orders {
		orderType, _ := order["type"].(string)
		orderSide, _ := order["side"].(string)
		stopPrice, _ := order["stopPrice"].(float64)

		// 止损单类型：STOP_MARKET
		if orderType == "STOP_MARKET" && stopPrice > 0 {
			// 多单止损是卖单，空单止损是买单
			if positionSide == "LONG" && orderSide == "SELL" {
				return stopPrice
			}
			if positionSide == "SHORT" && orderSide == "BUY" {
				return stopPrice
			}
		}
	}

	return 0
}

// detectStopLossTriggered 检测止损触发（对比上次持仓快照）
// 当持仓从快照中消失时，判断为止损触发，计算并记录盈亏
func (at *AutoTrader) detectStopLossTriggered(currentPositions []map[string]interface{}) {
	// 如果没有上次快照，跳过检测（首次运行）
	if len(at.lastKnownPositions) == 0 {
		return
	}

	// 构建当前持仓的key集合
	currentPosKeys := make(map[string]bool)
	for _, pos := range currentPositions {
		symbol, _ := pos["symbol"].(string)
		side, _ := pos["side"].(string)
		quantity, _ := pos["positionAmt"].(float64)
		if quantity < 0 {
			quantity = -quantity
		}
		if quantity > 0 {
			posKey := symbol + "_" + side
			currentPosKeys[posKey] = true
		}
	}

	// 检查上次快照中的持仓是否消失
	for posKey, lastPos := range at.lastKnownPositions {
		if currentPosKeys[posKey] {
			continue // 持仓仍然存在，跳过
		}

		// 持仓消失了，可能是止损触发
		symbol, _ := lastPos["symbol"].(string)
		side, _ := lastPos["side"].(string)
		entryPrice, _ := lastPos["entryPrice"].(float64)
		quantity, _ := lastPos["positionAmt"].(float64)
		leverage, _ := lastPos["leverage"].(float64)
		if quantity < 0 {
			quantity = -quantity
		}
		if leverage == 0 {
			leverage = 10
		}

		// 获取当前市场价格作为平仓价（止损触发时的价格）
		marketData, err := market.Get(symbol)
		if err != nil {
			log.Printf("⚠️ [止损检测] %s 获取市场价格失败: %v", symbol, err)
			continue
		}
		closePrice := marketData.CurrentPrice

		// 计算盈亏
		var pnl float64
		var pnlPct float64
		if side == "long" {
			// 做多盈亏 = (平仓价 - 入场价) * 数量
			pnl = (closePrice - entryPrice) * quantity
			pnlPct = ((closePrice - entryPrice) / entryPrice) * leverage * 100
		} else {
			// 做空盈亏 = (入场价 - 平仓价) * 数量
			pnl = (entryPrice - closePrice) * quantity
			pnlPct = ((entryPrice - closePrice) / entryPrice) * leverage * 100
		}

		log.Printf("🚨 [止损检测] %s %s 持仓消失（可能止损触发）", symbol, side)
		log.Printf("  📊 入场价=%.4f, 平仓价≈%.4f, 数量=%.4f, 杠杆=%dx",
			entryPrice, closePrice, quantity, int(leverage))
		log.Printf("  💰 估算盈亏: %.4f USDT (%.2f%%)", pnl, pnlPct)

		// 记录盈亏到数据库
		if at.database != nil && at.userID != "" && entryPrice > 0 && quantity > 0 {
			today := time.Now().UTC().Format("2006-01-02")

			if db, ok := at.database.(*config.Database); ok {
				if addErr := db.AddDailyPnL(at.id, at.userID, today, pnl); addErr != nil {
					log.Printf("  ❌ 记录止损盈亏失败: %v", addErr)
				} else {
					log.Printf("  ✅ 止损盈亏已记录到数据库: %.4f USDT", pnl)
				}
			}
		}

		// 清理相关缓存
		at.ClearPeakPnLCache(symbol, side)
		delete(at.positionFirstSeenTime, posKey)
	}
}

// updatePositionSnapshot 更新持仓快照（用于下次止损检测）
func (at *AutoTrader) updatePositionSnapshot(positions []map[string]interface{}) {
	// 清空旧快照
	at.lastKnownPositions = make(map[string]map[string]interface{})

	// 保存当前持仓快照
	for _, pos := range positions {
		symbol, _ := pos["symbol"].(string)
		side, _ := pos["side"].(string)
		quantity, _ := pos["positionAmt"].(float64)
		if quantity < 0 {
			quantity = -quantity
		}

		// 只保存有效持仓
		if quantity > 0 {
			posKey := symbol + "_" + side
			// 深拷贝持仓信息
			snapshot := make(map[string]interface{})
			for k, v := range pos {
				snapshot[k] = v
			}
			at.lastKnownPositions[posKey] = snapshot
		}
	}
}

package trader

import (
	"database/sql"
	"fmt"
	"log"
	"time"
)

// AntiMartingalePosition 反马丁仓位记录
type AntiMartingalePosition struct {
	ID                     int       `json:"id"`
	TraderID               string    `json:"trader_id"`
	UserID                 string    `json:"user_id"`
	Date                   string    `json:"date"` // YYYY-MM-DD
	AntiMartingalePosition float64   `json:"anti_martingale_position"`
	BaseCapital            float64   `json:"base_capital"`
	TotalEquity            float64   `json:"total_equity"`
	DailyProfit            float64   `json:"daily_profit"`
	DailyLoss              float64   `json:"daily_loss"`
	OpenCount              int       `json:"open_count"`
	CreatedAt              time.Time `json:"created_at"`
	UpdatedAt              time.Time `json:"updated_at"`
}

// AntiMartingaleManager 反马丁仓位管理器
type AntiMartingaleManager struct {
	db       *sql.DB
	traderID string
	userID   string
}

// NewAntiMartingaleManager 创建反马丁仓位管理器
func NewAntiMartingaleManager(db *sql.DB, traderID, userID string) *AntiMartingaleManager {
	return &AntiMartingaleManager{
		db:       db,
		traderID: traderID,
		userID:   userID,
	}
}

// GetTodayPosition 获取今日反马丁仓位信息
func (m *AntiMartingaleManager) GetTodayPosition(totalEquity float64) (*AntiMartingalePosition, error) {
	today := time.Now().Format("2006-01-02")

	var pos AntiMartingalePosition
	err := m.db.QueryRow(`
		SELECT id, trader_id, user_id, date, anti_martingale_position,
		       base_capital, total_equity, daily_profit, daily_loss, open_count,
		       created_at, updated_at
		FROM anti_martingale_positions
		WHERE trader_id = ? AND user_id = ? AND date = ?
	`, m.traderID, m.userID, today).Scan(
		&pos.ID, &pos.TraderID, &pos.UserID, &pos.Date,
		&pos.AntiMartingalePosition, &pos.BaseCapital, &pos.TotalEquity,
		&pos.DailyProfit, &pos.DailyLoss, &pos.OpenCount,
		&pos.CreatedAt, &pos.UpdatedAt,
	)

	if err == sql.ErrNoRows {
		// 今日记录不存在，创建新记录
		yesterdayPos := m.getYesterdayPosition()
		newPos := m.calculateNewPosition(yesterdayPos, totalEquity)

		// 插入新记录
		result, err := m.db.Exec(`
			INSERT INTO anti_martingale_positions
			(trader_id, user_id, date, anti_martingale_position, base_capital, total_equity,
			 daily_profit, daily_loss, open_count, created_at, updated_at)
			VALUES (?, ?, ?, ?, ?, ?, 0, 0, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
		`, m.traderID, m.userID, today, newPos.AntiMartingalePosition,
			newPos.BaseCapital, totalEquity)

		if err != nil {
			return nil, fmt.Errorf("创建今日反马丁仓位记录失败: %w", err)
		}

		id, _ := result.LastInsertId()
		newPos.ID = int(id)
		newPos.Date = today
		newPos.TraderID = m.traderID
		newPos.UserID = m.userID
		newPos.TotalEquity = totalEquity
		newPos.CreatedAt = time.Now()
		newPos.UpdatedAt = time.Now()

		log.Printf("✅ Trader %s 创建今日反马丁仓位: 反马丁仓位=%.2f USDT, 基础本金=%.2f USDT",
			m.traderID, newPos.AntiMartingalePosition, newPos.BaseCapital)

		return newPos, nil
	}

	if err != nil {
		return nil, fmt.Errorf("查询今日反马丁仓位失败: %w", err)
	}

	// 更新总资金（可能发生了充值/提现）
	if pos.TotalEquity != totalEquity {
		pos.TotalEquity = totalEquity
		pos.BaseCapital = totalEquity - pos.AntiMartingalePosition
		m.updatePosition(&pos)
	}

	return &pos, nil
}

// getYesterdayPosition 获取昨日反马丁仓位
func (m *AntiMartingaleManager) getYesterdayPosition() *AntiMartingalePosition {
	yesterday := time.Now().AddDate(0, 0, -1).Format("2006-01-02")

	var pos AntiMartingalePosition
	err := m.db.QueryRow(`
		SELECT anti_martingale_position, daily_profit, daily_loss
		FROM anti_martingale_positions
		WHERE trader_id = ? AND user_id = ? AND date = ?
	`, m.traderID, m.userID, yesterday).Scan(
		&pos.AntiMartingalePosition, &pos.DailyProfit, &pos.DailyLoss,
	)

	if err != nil {
		// 昨日没有记录，返回初始值
		return &AntiMartingalePosition{
			AntiMartingalePosition: 0,
			DailyProfit:            0,
			DailyLoss:              0,
		}
	}

	return &pos
}

// calculateNewPosition 计算新的反马丁仓位
// 公式: 反马丁仓位(今日) = 反马丁仓位(昨日) + B × 昨日盈利 - 昨日亏损
// B = 90% (盈利转化比例)
func (m *AntiMartingaleManager) calculateNewPosition(yesterdayPos *AntiMartingalePosition, totalEquity float64) *AntiMartingalePosition {
	const B = 0.90 // 盈利转化比例

	// 计算新的反马丁仓位
	newAMPosition := yesterdayPos.AntiMartingalePosition +
		B*yesterdayPos.DailyProfit -
		yesterdayPos.DailyLoss

	// 反马丁仓位不能为负
	if newAMPosition < 0 {
		newAMPosition = 0
	}

	// 反马丁仓位不能超过总资金的90%（保留至少10%作为基础本金）
	maxAMPosition := totalEquity * 0.90
	if newAMPosition > maxAMPosition {
		newAMPosition = maxAMPosition
	}

	// 计算基础本金
	baseCapital := totalEquity - newAMPosition

	return &AntiMartingalePosition{
		AntiMartingalePosition: newAMPosition,
		BaseCapital:            baseCapital,
		TotalEquity:            totalEquity,
		DailyProfit:            0,
		DailyLoss:              0,
		OpenCount:              0,
	}
}

// CalculatePositionSize 计算开仓大小
// 公式:
//   单笔保证金 = A × 基础本金 + C × 反马丁仓位
//   开仓倍数 = min(90 / 止损波幅(%), maxMultiplier)
//   开仓价值 = 单笔保证金 × 开仓倍数
//
// 参数:
//   A = 2% (基础本金比例)
//   C = 30% (反马丁仓位使用比例)
//   maxMultiplier: 开仓倍数上限 (BTC/ETH: 50, 其他币种: 20)
func (m *AntiMartingaleManager) CalculatePositionSize(currentPrice, stopLossPrice float64, totalEquity float64, maxMultiplier float64) (float64, float64, error) {
	const A = 0.02  // 基础本金比例 2%
	const C = 0.30  // 反马丁仓位使用比例 30%

	// 获取今日仓位信息
	pos, err := m.GetTodayPosition(totalEquity)
	if err != nil {
		return 0, 0, fmt.Errorf("获取反马丁仓位失败: %w", err)
	}

	// 计算止损波幅(百分比)
	stopLossRange := (abs(currentPrice - stopLossPrice) / currentPrice) * 100
	if stopLossRange == 0 {
		return 0, 0, fmt.Errorf("止损波幅为0，无法计算仓位")
	}

	// 计算单笔保证金
	margin := A*pos.BaseCapital + C*pos.AntiMartingalePosition

	// 计算开仓倍数（原始值）
	rawMultiplier := 90.0 / stopLossRange

	// 应用上限约束
	multiplier := rawMultiplier
	if multiplier > maxMultiplier {
		multiplier = maxMultiplier
		log.Printf("⚠️  Trader %s 开仓倍数受限: 原始值%.2fx > 上限%.0fx，使用上限值",
			m.traderID, rawMultiplier, maxMultiplier)
	}

	// 计算开仓价值(USDT)
	positionValue := margin * multiplier

	log.Printf("📊 Trader %s 仓位计算: 基础本金=%.2f, 反马丁仓位=%.2f, "+
		"单笔保证金=%.2f, 止损波幅=%.2f%%, 开仓倍数=%.2fx (原始%.2fx), 开仓价值=%.2f USDT",
		m.traderID, pos.BaseCapital, pos.AntiMartingalePosition,
		margin, stopLossRange, multiplier, rawMultiplier, positionValue)

	return positionValue, margin, nil
}

// UpdateDailyStats 更新今日统计数据
func (m *AntiMartingaleManager) UpdateDailyStats(profit, loss float64, openCount int) error {
	today := time.Now().Format("2006-01-02")

	_, err := m.db.Exec(`
		UPDATE anti_martingale_positions
		SET daily_profit = daily_profit + ?,
		    daily_loss = daily_loss + ?,
		    open_count = open_count + ?,
		    updated_at = CURRENT_TIMESTAMP
		WHERE trader_id = ? AND user_id = ? AND date = ?
	`, profit, loss, openCount, m.traderID, m.userID, today)

	if err != nil {
		return fmt.Errorf("更新每日统计失败: %w", err)
	}

	log.Printf("📈 Trader %s 更新今日统计: +盈利%.2f, +亏损%.2f, +开仓%d次",
		m.traderID, profit, loss, openCount)

	return nil
}

// updatePosition 更新仓位信息
func (m *AntiMartingaleManager) updatePosition(pos *AntiMartingalePosition) error {
	_, err := m.db.Exec(`
		UPDATE anti_martingale_positions
		SET anti_martingale_position = ?,
		    base_capital = ?,
		    total_equity = ?,
		    updated_at = CURRENT_TIMESTAMP
		WHERE id = ?
	`, pos.AntiMartingalePosition, pos.BaseCapital, pos.TotalEquity, pos.ID)

	return err
}

// CheckDailyLossLimit 检查是否达到当日止损限制（基础本金亏损6%）
func (m *AntiMartingaleManager) CheckDailyLossLimit(totalEquity float64) (bool, error) {
	pos, err := m.GetTodayPosition(totalEquity)
	if err != nil {
		return false, err
	}

	// 基础本金亏损百分比
	if pos.BaseCapital == 0 {
		return false, nil
	}

	lossPercentage := (pos.DailyLoss / pos.BaseCapital) * 100

	// 6%止损线
	if lossPercentage >= 6.0 {
		log.Printf("⚠️ Trader %s 达到当日止损限制: 基础本金亏损%.2f%% >= 6%%",
			m.traderID, lossPercentage)
		return true, nil
	}

	return false, nil
}

// CheckDailyOpenLimit 检查是否达到当日开仓上限（8单）
func (m *AntiMartingaleManager) CheckDailyOpenLimit(totalEquity float64) (bool, error) {
	pos, err := m.GetTodayPosition(totalEquity)
	if err != nil {
		return false, err
	}

	if pos.OpenCount >= 8 {
		log.Printf("⚠️ Trader %s 达到当日开仓上限: %d/8",
			m.traderID, pos.OpenCount)
		return true, nil
	}

	return false, nil
}

// GetPositionInfo 获取仓位信息摘要（用于AI提示词）
func (m *AntiMartingaleManager) GetPositionInfo(totalEquity float64) string {
	pos, err := m.GetTodayPosition(totalEquity)
	if err != nil {
		return fmt.Sprintf("反马丁仓位信息获取失败: %v", err)
	}

	lossPercentage := 0.0
	if pos.BaseCapital > 0 {
		lossPercentage = (pos.DailyLoss / pos.BaseCapital) * 100
	}

	return fmt.Sprintf(`
📊 反马丁仓位管理系统 (今日 %s)
- 总资金: %.2f USDT
- 反马丁仓位: %.2f USDT
- 基础本金: %.2f USDT (可用于计算开仓)
- 今日盈利: %.2f USDT
- 今日亏损: %.2f USDT (基础本金亏损: %.2f%%)
- 今日开仓次数: %d/8

⚠️ 风控状态:
- 当日开仓限制: %d/8 %s
- 基础本金止损: %.2f%% / 6%% %s
`,
		pos.Date,
		pos.TotalEquity,
		pos.AntiMartingalePosition,
		pos.BaseCapital,
		pos.DailyProfit,
		pos.DailyLoss,
		lossPercentage,
		pos.OpenCount,
		pos.OpenCount,
		getStatusEmoji(pos.OpenCount >= 8),
		lossPercentage,
		getStatusEmoji(lossPercentage >= 6.0),
	)
}

// abs 返回绝对值
func abs(x float64) float64 {
	if x < 0 {
		return -x
	}
	return x
}

// getStatusEmoji 获取状态表情
func getStatusEmoji(isLimit bool) string {
	if isLimit {
		return "❌ 已达上限"
	}
	return "✅ 正常"
}
# SuperTrend + FRVP 策略使用指南

## 快速开始

### 1. 启动系统

确保系统已经正确配置并启动：

```bash
# 构建项目
go build -o nofx

# 启动后端
./nofx

# 或使用Docker
docker compose up -d --build
```

### 2. 通过Web界面创建Trader

访问 `http://localhost:3000` 并按以下步骤操作：

1. **配置AI模型**
   - 进入"AI Models"页面
   - 选择DeepSeek或Qwen模型
   - 输入API Key并启用

2. **配置交易所**
   - 进入"Exchanges"页面
   - 选择Binance/Hyperliquid/Aster
   - 输入API凭证并启用

3. **创建Trader**
   - 进入"Traders"页面
   - 点击"Create Trader"
   - 填写以下信息：
     - **名称**: 例如 "SuperTrend BTC Trader"
     - **AI Model**: 选择已配置的模型
     - **Exchange**: 选择已配置的交易所
     - **Initial Balance**: 输入初始资金（USDT）
     - **System Prompt Template**: 选择 `supertrend_frvp`
     - **Trading Symbols**: 输入交易币种（如 BTCUSDT,ETHUSDT,SOLUSDT）
     - **BTC/ETH Leverage**: 建议30-50x
     - **Altcoin Leverage**: 建议15-20x

4. **启动Trader**
   - 点击"Start"按钮启动交易

### 3. 监控运行

- **实时状态**: 查看Trader运行状态、持仓、盈亏
- **决策日志**: 查看AI的详细推理过程和决策记录
- **反马丁仓位**: 系统自动管理，每日更新

## 策略核心要点

### 开仓逻辑

**做多**：
- 4H价格 > 4H Supertrend ✓
- 15M价格 > 15M Supertrend ✓
- 15M价格 > 15M VAH ✓

**做空**：
- 4H价格 < 4H Supertrend ✓
- 15M价格 < 15M Supertrend ✓
- 15M价格 < 15M VAL ✓

### 止损规则

- **动态止损**: 跟随15M Supertrend线移动
- **不设止盈**: 让利润奔跑
- **严格执行**: 价格触及止损线立即平仓

### 仓位管理

系统自动计算开仓价值：
```
单笔保证金 = 2% × 基础本金 + 30% × 反马丁仓位
开仓倍数 = min(90 / 止损波幅(%), 杠杆上限)
开仓价值 = 单笔保证金 × 开仓倍数
```

**开仓倍数上限**：
- BTC/ETH：最大 **50倍**
- 其他币种：最大 **20倍**
- 当止损波幅很小时，系统会自动限制开仓倍数，防止过度杠杆

**反马丁增长**：
- 盈利：90%转入反马丁仓位（次日）
- 亏损：从反马丁仓位中扣除（次日）

### 风控限制

| 规则 | 限制 | 说明 |
|------|------|------|
| 持仓上限 | 3单 | 同时最多3个持仓 |
| 单日开仓 | 8单 | 每天最多开8次新仓 |
| 单日止损 | 6% | 基础本金亏损6%后停止开仓 |
| 杠杆上限 | BTC/ETH: 50x<br>其他: 20x | 系统限制 |
| 开仓限制 | ≤130% | AI开仓不超过计算值的130% |

## 系统架构

### 数据流程

```
1. 获取市场数据
   ├─ 15M K线 (350根) → Supertrend + FRVP
   └─ 4H K线 (350根) → Supertrend + FRVP

2. 反马丁仓位计算
   ├─ 获取昨日数据
   ├─ 计算今日反马丁仓位
   └─ 确定基础本金

3. 候选币种分析
   ├─ 检查开仓条件
   ├─ 计算开仓价值
   └─ 排序推荐

4. AI决策
   ├─ 分析风控状态
   ├─ 管理现有持仓
   └─ 寻找新机会

5. 执行交易
   ├─ 验证决策合规性
   ├─ 调用交易所API
   └─ 更新数据库
```

### 关键文件

```
market/
├── supertrend_frvp.go      # SuperTrend+FRVP指标计算和条件检查
└── data.go                  # 基础市场数据获取

trader/
└── anti_martingale.go       # 反马丁仓位管理器

config/
└── database.go              # 数据库表定义(含anti_martingale_positions)

prompts/
└── supertrend_frvp.txt      # 策略提示词模板

decision/
└── engine.go                # 决策引擎（需集成）
```

## 高级配置

### 调整参数

在Trader配置中可以调整：

1. **扫描间隔**: `scan_interval_minutes` (默认3-5分钟)
2. **杠杆倍数**:
   - `btc_eth_leverage`: BTC/ETH杠杆 (建议30-50x)
   - `altcoin_leverage`: 其他币种杠杆 (建议15-20x)
3. **交易币种**: `trading_symbols` (逗号分隔，如 BTCUSDT,ETHUSDT)

### 反马丁参数

在 `trader/anti_martingale.go` 中定义：

```go
const A = 0.02  // 基础本金比例 2%
const B = 0.90  // 盈利转化比例 90%
const C = 0.30  // 反马丁仓位使用比例 30%
```

修改这些常量可调整仓位管理策略（不推荐新手修改）。

### Supertrend参数

在 `market/data.go` 中定义：

```go
const atrPeriod = 10    // ATR周期
const multiplier = 3.0  // ATR倍数
```

这些参数已与TradingView对齐，不建议修改。

## 常见问题

### Q1: 如何查看反马丁仓位？

A: 反马丁仓位信息会在AI决策日志中自动显示，包括：
- 总资金
- 反马丁仓位
- 基础本金
- 当日盈亏
- 开仓次数

### Q2: 为什么没有开仓？

A: 可能原因：
1. 未满足开仓条件（4H+15M+FRVP三重确认）
2. 达到持仓上限（3单）
3. 达到单日开仓上限（8单）
4. 达到单日止损限制（基础本金亏6%）

检查决策日志中的reasoning部分查看具体原因。

### Q3: 如何重置反马丁仓位？

A: 反马丁仓位每日自动计算，基于昨日盈亏更新。如需手动重置：

```sql
DELETE FROM anti_martingale_positions WHERE trader_id = 'your_trader_id';
```

重启Trader后会自动创建新记录（反马丁仓位从0开始）。

### Q4: 策略适合什么市场？

A:
- ✅ **适合**: 趋势明确的市场（单边上涨/下跌）
- ❌ **不适合**: 震荡行情（反复横盘）

SuperTrend是趋势跟踪指标，在震荡市会频繁止损。

### Q5: 如何优化策略表现？

A:
1. **选币**: 选择流动性好、波动适中的主流币种
2. **杠杆**: 根据风险承受能力调整杠杆（建议不超过30x）
3. **时段**: 避开流动性差的时段（如周末凌晨）
4. **监控**: 定期查看AI的历史决策，识别优化空间

## 性能监控

### 关键指标

在Web界面查看：
- **胜率**: 盈利交易占比
- **盈亏比**: 平均盈利/平均亏损
- **最大回撤**: 从峰值到谷底的最大跌幅
- **反马丁增长**: 反马丁仓位增长曲线

### 日志分析

决策日志包含：
- AI推理过程 (`<reasoning>`)
- 具体决策 (`<decision>`)
- 市场数据（SuperTrend+FRVP值）
- 仓位计算详情

## 风险警示

⚠️ **重要提醒**：

1. **高杠杆风险**: 50x杠杆下，2%波动即可爆仓
2. **市场风险**: 极端行情（如黑天鹅事件）可能导致重大损失
3. **API风险**: 交易所API故障可能影响策略执行
4. **策略风险**: 震荡市场会频繁止损，累积亏损

**建议**：
- 初始资金不超过总资产的10-20%
- 使用测试网(testnet)先运行1-2周
- 密切监控前期表现，及时调整参数
- 设置账户总止损（如最大回撤30%）

## 技术支持

- **文档**: 查看 `docs/SUPERTREND_FRVP_IMPLEMENTATION.md`
- **Issue**: GitHub Issues反馈问题
- **日志**: `decision_logs/{trader_id}/` 目录查看详细日志

## 更新日志

- **v1.0.0** (2025-01): 初始版本
  - 实现SuperTrend+FRVP指标计算
  - 反马丁仓位管理系统
  - 多时间周期共振确认
  - AI自主加仓/减仓权限
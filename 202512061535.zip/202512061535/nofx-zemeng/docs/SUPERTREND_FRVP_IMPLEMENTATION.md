# SuperTrend + FRVP 策略实施方案

## 概述

本文档详细说明SuperTrend + FRVP策略的完整实施方案,包括技术指标、仓位管理系统、风控规则和AI提示词设计。

## 1. 技术指标实现

### 1.1 Supertrend指标 (ATR=10, 倍数=3.0)

**状态**: ✅ 已完成

- 位置: `market/data.go::calculateSupertrend()`
- 参数: ATR周期=10, 倍数=3.0
- 输出: `SupertrendData{Value, Direction}`
- 与TradingView代码100%一致

### 1.2 FRVP指标 (338根K线)

**状态**: ✅ 已完成

- 位置: `market/data.go::calculateFRVP()`
- 参数: 338根K线, 24个价格档位
- 输出: `FRVPData{POC, VAH, VAL}`
- 与TradingView代码100%一致

### 1.3 多时间周期数据获取

**状态**: ⏸ 待实现

**方案A: REST API临时获取** (推荐)
```go
// 在Get函数中添加15M和4H K线获取
klines15m, err := fetchKlines(symbol, "15m", 500)  // 获取足够的15M数据用于338根FRVP
klines4h, err := fetchKlines(symbol, "4h", 400)    // 获取足够的4H数据用于338根FRVP
```

**方案B: 扩展WebSocket监控**
- 需要修改`market/monitor.go`以支持多时间框架
- 更复杂但实时性更好

## 2. 反马丁仓位管理系统

### 2.1 数据库表设计

```sql
CREATE TABLE anti_martingale_positions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trader_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    date DATE NOT NULL,  -- 日期(YYYY-MM-DD)
    anti_martingale_position REAL DEFAULT 0,  -- 反马丁仓位
    base_capital REAL NOT NULL,  -- 基础本金 = 全部资金 - 反马丁仓位
    total_equity REAL NOT NULL,  -- 全部资金
    daily_profit REAL DEFAULT 0,  -- 当日盈利
    daily_loss REAL DEFAULT 0,  -- 当日亏损
    open_count INTEGER DEFAULT 0,  -- 当日开仓次数
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (trader_id) REFERENCES traders(id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE(trader_id, date)
)
```

### 2.2 仓位计算公式

```
基础本金 = 全部资金 - 反马丁仓位
单笔保证金 = A × 基础本金 + C × 反马丁仓位
开仓倍数 = 90 / 止损波幅
开仓价值 = 单笔保证金 × 开仓倍数
反马丁仓位(次日) = 反马丁仓位(今日) + B × 今日盈利 - 今日亏损

其中:
A = 2% (基础本金比例)
B = 90% (盈利转化比例)
C = 30% (反马丁仓位使用比例)
```

### 2.3 实现位置

```go
// trader/anti_martingale.go (新文件)
type AntiMartingaleManager struct {
    db *config.Database
    traderID string
    userID string
}

func (m *AntiMartingaleManager) GetCurrentPosition() float64 {...}
func (m *AntiMartingaleManager) CalculatePositionSize(stopLoss float64) float64 {...}
func (m *AntiMartingaleManager) UpdateDailyStats(profit, loss float64) {...}
```

## 3. 开仓条件

### 3.1 做多条件
```
1. 4H价格 > 4H Supertrend
2. 15M价格 > 15M Supertrend
3. 15M价格 > 15M 338 VAH
4. 止损 = 15M Supertrend值
```

### 3.2 做空条件
```
1. 4H价格 < 4H Supertrend
2. 15M价格 < 15M Supertrend
3. 15M价格 < 15M 338 VAL
4. 止损 = 15M Supertrend值
```

## 4. 风控规则

### 4.1 硬性限制 (代码强制执行)
- **持仓上限**: 同时最多3单
- **开仓限制**: 平仓后才能开新单,达到持仓上限后仍需管理
- **单日开仓上限**: 最多8单
- **单日止损**: 基础本金亏损6%后停止开仓
- **杠杆上限**: BTC/ETH≤50倍, 其他≤20倍
- **AI开仓限制**: ≤计算价值的130%

### 4.2 AI自主权限
- **浮盈+50%**: 可加仓≤30%, 回落后可减去加仓部分, 加仓后成本线≤Supertrend
- **浮盈+100%回落**: 可减仓≤30%, 条件好时可加仓≤30%
- **选币优化**: 根据历史表现选择标的
- **条件识别**: 识别高胜率条件组合

### 4.3 止盈止损
- **移动止损**: 跟随Supertrend线移动
- **不设止盈**: 主要吃趋势滚仓行情
- **不主动平仓**: 未触及止损线时只允许减仓

## 5. 策略提示词设计

### 5.1 结构 (≤200行)

```
# SuperTrend + FRVP 趋势滚仓策略

## 核心理念
...

## 技术指标说明
### Supertrend (ATR=10, 倍数=3.0)
...

### FRVP 338 (POC/VAH/VAL)
...

## 开仓条件
### 做多
...

### 做空
...

## 仓位管理
反马丁仓位系统:
- 当前反马丁仓位: {anti_martingale_position} USDT
- 基础本金: {base_capital} USDT
- 单笔保证金计算: ...
...

## 风控规则
硬性限制:
- 持仓上限3单
- 单日8单
- 基础本金亏6%止损
...

AI自主权限:
- 浮盈+50%可加仓
...

## 输出格式
<reasoning>...</reasoning>
<decision>
```json
[
  {"symbol": "BTCUSDT", "action": "open_long", ...}
]
```
</decision>
```

## 6. 实施步骤

### Phase 1: 数据层 (1-2小时)
1. ✅ 实现Supertrend和FRVP指标计算
2. ⏸ 添加15M和4H K线数据获取(REST API)
3. ⏸ 更新market.Data结构以包含多时间周期数据
4. ⏸ 测试指标计算准确性

### Phase 2: 数据库层 (30分钟)
1. ⏸ 创建anti_martingale_positions表
2. ⏸ 实现AntiMartingaleManager
3. ⏸ 添加数据库迁移逻辑

### Phase 3: 决策层 (1小时)
1. ⏸ 在decision.Context中添加反马丁仓位信息
2. ⏸ 修改buildUserPrompt以包含SuperTrend+FRVP数据
3. ⏸ 实现仓位计算逻辑(开仓倍数、开仓价值)

### Phase 4: 策略层 (1-2小时)
1. ⏸ 创建prompts/supertrend_frvp.txt
2. ⏸ 实现风控规则验证(3单上限、单日8单、6%止损)
3. ⏸ 添加trader配置以启用该策略

### Phase 5: 测试与优化 (2-3小时)
1. ⏸ 单元测试指标计算
2. ⏸ 集成测试完整决策流程
3. ⏸ 回测历史数据验证策略逻辑
4. ⏸ 性能优化(缓存、并发)

## 7. 关键代码位置

```
market/types.go:49-73          # SupertrendData, FRVPData, MultiTimeframeData结构
market/data.go:552-772         # calculateSupertrend(), calculateFRVP()
config/database.go:100-240     # 数据库表创建逻辑
trader/anti_martingale.go      # (新文件) 反马丁仓位管理
decision/engine.go:76-88       # Context结构(需添加反马丁字段)
decision/engine.go:364-466     # buildUserPrompt(需添加SuperTrend+FRVP数据)
prompts/supertrend_frvp.txt    # (新文件) 策略提示词
```

## 8. 风险提示

1. **数据获取性能**: 获取15M和4H的500根K线可能增加延迟
   - **解决方案**: 使用缓存或异步预加载

2. **反马丁仓位持久化**: 重启后需正确恢复
   - **解决方案**: 数据库存储+每日自动同步

3. **止损计算精度**: Supertrend值可能在K线之间变化
   - **解决方案**: 使用最新K线的Supertrend值,每周期更新

4. **3单上限冲突**: 换仓时可能触发上限
   - **解决方案**: 决策排序确保先平仓后开仓

## 9. 后续优化方向

1. **实时止损追踪**: 在WebSocket监控中实时更新Supertrend止损
2. **回测系统**: 基于历史数据验证策略效果
3. **性能监控**: 记录反马丁仓位增长曲线
4. **多策略组合**: 支持SuperTrend+FRVP与其他策略共存

## 10. 参考资料

- TradingView Supertrend指标: https://www.tradingview.com/script/...
- FRVP (Fixed Range Volume Profile): Volume Profile技术文档
- 反马丁格尔策略: 盈利加仓、亏损减仓的资金管理方法
# 仓位管理系统集成指南

## 📋 概览

本指南说明如何将反马丁格尔仓位管理系统集成到 `trader/auto_trader.go` 的交易循环中。

## ✅ 已完成的模块

### 1. 数据库层 (config/database.go)
添加了以下方法用于反马丁仓位管理：
- `GetAntiMartingalePosition()` - 获取指定日期的反马丁仓位记录
- `GetPreviousDayAntiMartingalePosition()` - 获取前一天的记录
- `UpsertAntiMartingalePosition()` - 插入或更新记录
- `IncrementOpenCount()` - 增加今日开仓次数
- `UpdateDailyPnL()` - 更新当日盈亏

### 2. 仓位管理模块 (trader/position_manager.go)
实现了核心仓位计算逻辑：
- `PositionManager` - 仓位管理器
- `GetManagementData()` - 计算仓位管理数据和风控状态
- `CalculateOpenPosition()` - 计算开仓参数（基于SuperTrend止损波幅）
- `IncrementOpenCount()` - 增加开仓次数
- `UpdateDailyPnL()` - 更新盈亏
- `FormatManagementDataForPrompt()` - 格式化数据用于AI提示词

### 3. 决策引擎集成 (decision/engine.go)
- 添加了 `Context.PositionManagementDataFormatted` 字段
- 修改了 `buildSuperTrendFRVPPrompt()` 以注入仓位管理数据到提示词

## 🔧 需要集成的代码位置

### trader/auto_trader.go 修改点

#### 位置 1: 在交易循环开始时创建 PositionManager

找到 `Run()` 方法中的交易循环（通常是一个 `for` 循环），在获取账户信息后添加：

```go
// 1. 获取账户信息
accountInfo, err := t.GetAccountInfo()
if err != nil {
    log.Printf("❌ [%s] 获取账户信息失败: %v", t.ID, err)
    return
}

// 2. 创建仓位管理器（仅SuperTrend+FRVP策略使用）
var positionMgr *PositionManager
var managementData *PositionManagementData
if t.systemPromptTemplate == "supertrend_frvp" {
    positionMgr = NewPositionManager(t.database, t.ID, t.UserID)

    // 计算仓位管理数据
    managementData, err = positionMgr.GetManagementData(
        accountInfo.TotalEquity,
        len(accountInfo.Positions), // 当前持仓数量
    )
    if err != nil {
        log.Printf("⚠️  [%s] 获取仓位管理数据失败: %v", t.ID, err)
    } else {
        log.Printf("📊 [仓位管理] 基础本金=%.2f, 反马丁仓位=%.2f, 单笔保证金=%.2f, 可开仓=%v",
            managementData.BaseCapital,
            managementData.AntiMartingalePosition,
            managementData.SingleMargin,
            managementData.CanOpenPosition,
        )
    }
}
```

#### 位置 2: 在构建 Decision Context 时注入仓位管理数据

找到构建 `decision.Context` 的代码，添加仓位管理数据：

```go
ctx := &decision.Context{
    CurrentTime:    time.Now().Format("2006-01-02 15:04:05"),
    RuntimeMinutes: int(time.Since(startTime).Minutes()),
    CallCount:      callCount,
    Account:        /* ... */,
    Positions:      /* ... */,
    CandidateCoins: /* ... */,
    // ... 其他字段 ...

    // SuperTrend+FRVP 策略字段
    TraderID:     t.ID,
    UserID:       t.UserID,
    Database:     t.database,
    TemplateName: t.systemPromptTemplate,

    // 注入格式化的仓位管理数据
    PositionManagementDataFormatted: func() string {
        if managementData != nil {
            return FormatManagementDataForPrompt(managementData)
        }
        return ""
    }(),
}
```

#### 位置 3: 在执行开仓决策时使用系统计算的仓位

找到处理 `open_long` 和 `open_short` 决策的代码，修改为使用系统计算的仓位：

```go
case "open_long", "open_short":
    // ==================== SuperTrend+FRVP 策略的仓位管理 ====================
    if t.systemPromptTemplate == "supertrend_frvp" && positionMgr != nil && managementData != nil {
        // 1. 风控检查：是否可开仓
        if !managementData.CanOpenPosition {
            log.Printf("⚠️  [%s] 风控拒绝开仓: 持仓=%d/3, 今日开仓=%d/8, 基础本金亏损=%.2f%%",
                t.ID,
                managementData.CurrentPositionCount,
                managementData.TodayOpenCount,
                managementData.BaseCapitalLossPct,
            )
            continue // 跳过此决策
        }

        // 2. 强制验证止损（SuperTrend策略必须设置止损）
        if d.StopLoss <= 0 {
            log.Printf("❌ [%s] %s 开仓被拒绝: 未设置止损价格", t.ID, d.Symbol)
            continue
        }

        // 3. 获取当前价格（从市场数据或交易所）
        currentPrice, err := t.GetCurrentPrice(d.Symbol)
        if err != nil {
            log.Printf("❌ [%s] %s 获取当前价格失败: %v", t.ID, d.Symbol, err)
            continue
        }

        // 4. 使用系统计算的开仓参数
        isBTCETH := IsBTCETH(d.Symbol)
        openParams, err := positionMgr.CalculateOpenPosition(
            currentPrice,
            d.StopLoss,    // 15M SuperTrend值
            d.Symbol,
            isBTCETH,
            managementData,
        )
        if err != nil {
            log.Printf("❌ [%s] %s 计算开仓参数失败: %v", t.ID, d.Symbol, err)
            continue
        }

        // 5. 覆盖AI决策的仓位和杠杆（使用系统计算的值）
        originalPositionSize := d.PositionSizeUSD
        originalLeverage := d.Leverage

        d.PositionSizeUSD = openParams.PositionSizeUSD
        d.Leverage = openParams.ActualLeverage

        log.Printf("📊 [仓位管理] %s 开仓参数调整: 仓位 %.2f->%.2f USDT, 杠杆 %dx->%dx, 止损波幅=%.2f%%",
            d.Symbol,
            originalPositionSize, d.PositionSizeUSD,
            originalLeverage, d.Leverage,
            openParams.StopLossAmplitude,
        )

        // 6. 执行开仓（使用修改后的决策）
        err = t.ExecuteOpen(d)
        if err != nil {
            log.Printf("❌ [%s] %s 开仓失败: %v", t.ID, d.Symbol, err)
            continue
        }

        // 7. 开仓成功，增加今日开仓次数
        if err := positionMgr.IncrementOpenCount(); err != nil {
            log.Printf("⚠️  [%s] 增加开仓次数失败: %v", t.ID, err)
        }

        log.Printf("✅ [%s] %s %s 开仓成功: 仓位=%.2f USDT, 杠杆=%dx, 止损=%.4f",
            t.ID, d.Symbol, d.Action, d.PositionSizeUSD, d.Leverage, d.StopLoss)
    } else {
        // 默认策略：使用AI决策的仓位
        err = t.ExecuteOpen(d)
        if err != nil {
            log.Printf("❌ [%s] %s 开仓失败: %v", t.ID, d.Symbol, err)
            continue
        }
    }
```

#### 位置 4: 在交易循环结束时更新每日盈亏（可选）

在每个交易周期结束时，可以更新当日盈亏数据：

```go
// 交易循环结束，更新每日盈亏（可选，也可以在每次平仓时更新）
if t.systemPromptTemplate == "supertrend_frvp" && positionMgr != nil {
    // 计算今日盈亏（需要从数据库查询今日已平仓的交易）
    // 这里简化处理，实际实现需要根据业务逻辑调整
    // profit, loss := t.CalculateTodayPnL()
    // positionMgr.UpdateDailyPnL(profit, loss)
}
```

## 🎯 核心集成逻辑流程

```
1. 交易循环开始
   ↓
2. 获取账户信息
   ↓
3. 创建PositionManager并计算仓位管理数据
   ├─ 基础本金 = 总资金 - 反马丁仓位
   ├─ 单笔保证金 = 0.02×基础本金 + 0.3×反马丁仓位
   └─ 风控检查（持仓数、开仓次数、亏损率）
   ↓
4. 构建Decision Context
   └─ 注入格式化的仓位管理数据到PositionManagementDataFormatted字段
   ↓
5. 调用AI获取决策
   └─ AI看到仓位管理数据（提示词中显示）
   ↓
6. 执行决策
   ├─ 对于开仓决策：
   │   ├─ 检查风控状态（CanOpenPosition）
   │   ├─ 强制验证止损
   │   ├─ 调用CalculateOpenPosition()计算开仓参数
   │   │   ├─ 止损波幅 = |当前价格 - 止损价格| / 当前价格 × 100%
   │   │   ├─ 理论倍数 = 90 / 止损波幅
   │   │   ├─ 实际倍数 = min(理论倍数, 最大倍数限制)
   │   │   └─ 开仓价值 = 单笔保证金 × 实际倍数
   │   ├─ 覆盖AI决策的PositionSizeUSD和Leverage
   │   ├─ 执行开仓
   │   └─ 成功后增加开仓次数
   └─ 其他决策：正常执行
```

## ⚠️  重要注意事项

### 1. 策略判断
仓位管理系统仅适用于 `supertrend_frvp` 策略，需要在代码中判断：
```go
if t.systemPromptTemplate == "supertrend_frvp" {
    // 使用仓位管理系统
}
```

### 2. 止损必须设置
SuperTrend+FRVP策略要求**开仓时必须设置止损**，否则拒绝开仓：
```go
if d.StopLoss <= 0 {
    log.Printf("❌ 开仓被拒绝: 未设置止损价格")
    continue
}
```

### 3. 风控优先级
风控检查在AI决策之后、执行开仓之前进行，确保：
- 持仓数量 ≤ 3
- 今日开仓次数 ≤ 8
- 基础本金亏损 < 6%

任何一项不满足都会拒绝开仓。

### 4. 数据库字段
确保数据库表 `anti_martingale_positions` 已创建（在 config/database.go:198-214 已定义）。

### 5. 获取当前价格
需要实现 `GetCurrentPrice(symbol string)` 方法从交易所获取实时价格，或从市场数据缓存中获取。

### 6. 反马丁仓位更新时机
- **每日开始**: 根据昨日盈亏计算新的反马丁仓位
- **每次开仓**: 增加开仓次数
- **每次平仓**: 更新当日盈亏数据

## 📝 测试检查清单

集成完成后，请验证以下功能：

- [ ] 系统启动时正确初始化反马丁仓位（首次为0）
- [ ] 提示词中正确显示仓位管理数据
- [ ] 开仓时使用系统计算的仓位而非AI决策的仓位
- [ ] 开仓时正确计算止损波幅和开仓倍数
- [ ] 风控拒绝开仓时正确记录日志
- [ ] 开仓成功后正确增加开仓次数
- [ ] BTC/ETH和山寨币使用不同的最大倍数限制（50x vs 20x）
- [ ] 基础本金亏损超过6%时停止开仓
- [ ] 持仓数量达到3个时停止开仓
- [ ] 单日开仓次数达到8次时停止开仓

## 🔍 调试日志示例

正确集成后，日志应该显示：

```
📊 [仓位管理] 基础本金=980.50, 反马丁仓位=19.50, 单笔保证金=25.45, 可开仓=true
📊 [仓位管理] BTCUSDT 开仓计算: 止损波幅=2.15%, 理论倍数=41x, 实际倍数=41x, 开仓价值=1043.45 USDT
📊 [仓位管理] BTCUSDT 开仓参数调整: 仓位 1200.00->1043.45 USDT, 杠杆 50x->41x, 止损波幅=2.15%
✅ [trader_xxx] BTCUSDT open_long 开仓成功: 仓位=1043.45 USDT, 杠杆=41x, 止损=94250.00
✅ [仓位管理] 今日开仓次数已增加
```

风控拒绝时：
```
⚠️  [trader_xxx] 风控拒绝开仓: 持仓=3/3, 今日开仓=5/8, 基础本金亏损=2.30%
```

## 📞 集成支持

如果在集成过程中遇到问题，请检查：
1. 数据库表是否正确创建
2. trader结构体中是否有 `database` 和 `UserID` 字段
3. 是否正确判断了 `systemPromptTemplate == "supertrend_frvp"`
4. 日志输出是否包含上述调试信息

---

**注意**: 本指南假设你已经了解 `trader/auto_trader.go` 的基本结构。如果需要完整的代码示例，请参考现有的交易逻辑并结合本文档进行修改。